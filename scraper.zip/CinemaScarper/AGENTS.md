# AGENTS.md

## Project

CinemaScarper — Python scraper for 3 Perugia cinemas. Produces a static JSON (`output/movies.json`) consumed by a separate frontend app. Rolling 8-day window (today + 7 days forward).

Last full audit: 2026-06-17 — see `AuditReport.md`. All 7 fixes from `PlanAudit.md` applied; 32/33 tests pass (1 pre-existing skip unrelated to fixes).

## Commands

```bash
pip install -r requirements.txt           # one-time setup
python3 -m pytest tests/ -v                 # 32 unit tests + 1 skipped, no network required
python3 -m scraper.main --once              # single scrape run (30-60s, hits 3 APIs)
python3 -m scraper.main --schedule          # APScheduler, runs every 24h
```

Run from repo root. Tests work offline; `--once` requires network.

## Architecture

- `scraper/main.py` — entry point. Loads connectors, runs them sequentially, dedups, enriches with Wikidata, merges with previous `movies.json`, writes output atomically (`*.tmp` + `os.replace`).
- `scraper/config.py` — `get_week_dates()` returns **8 days starting today**, not Mon–Sun. Hardcoded regional config (UCI backend URL, TheSpace cinema ID 1027, PostMod homepage).
- `scraper/connectors/` — one file per cinema. Each implements `BaseConnector` (`base.py`). Add a new cinema = new file + register in `main.py:95-99`.
- `scraper/delta.py` — compare-vs-previous logic, history tracking, threshold for "rimosso" status (`REMOVAL_THRESHOLD_DAYS = 7` in `config.py`).
- `scraper/normalizer.py` — title normalization + `fuzzy_match()` for cross-cinema dedup. Also `normalize_duration()` for "X min" output.

## Output

- `output/movies.json` — final deduped JSON for frontend. Schema in `scraper/models.py:output_to_json()`.
- `output/cache/{slug}.json` — raw per-cinema results **before dedup** (one Film object per day per film for UCI). Dedup happens in `main.py:_deduplicate_films`.
- `output/history/movies_{date}.json` — daily snapshots written by `delta.save_snapshot()`.
- `output/errors.json` — accumulated errors per cinema.
- `scraper.log` at repo root.

Missing fields are `null` in JSON (not `[]` for `genres`). Never invent data — see PLAN.md "Cosa NON fare".

## Cinema-specific gotchas

- **Timezone rollover**: `scraper/config.py` provides `today_local()` which returns the date in `Europe/Rome` (configurable via `SCRAPER_TZ` env var). `run_scraper()` MUST use `today_local()` instead of `date.today()` so that the window rolls over at Italian midnight regardless of the server's TZ (Ubuntu hosts default to UTC). This was bug-reported on 2026-06-18 at 01:32 local.
- **PostModernissimo** (`scraper/connectors/postmodernissimo.py`): parses the React Server Components payload (`self.__next_f.push(...)`) embedded in the HTML. `/eventi/` permalinks = concerts/non-film events, **filtered out** at line ~197. Same film can appear **multiple times** in the payload with empty/sparse `shows` arrays — `_parse_rsc_payload` now **accumulates** `shows` from all occurrences of the same `permalink` (dedup by `(date, orario)`) so no showtime is lost (see FIX 1 in `PlanAudit.md`). Edit this parser with care: it's the most fragile part of the codebase.
- **The Space** (`scraper/connectors/thespace.py`): OAuth token auth, per-day API call (`showingDate=YYYY-MM-DD`). Returns the same 7-day data repeatedly for many past dates — empty results are expected for dates before today. Has CloakBrowser fallback if API fails.
- **UCI** (`scraper/connectors/uci.py`): Backend on Cloud Run, no auth. Per-day request. Returns catalog of ~20 films; only the requested date has populated `screens`. Does **not** provide director/duration — those come from Wikidata.

## Constraints (do not violate)

- Project is **commercial**. Do NOT add TMDB, OMDb, or any commercial-restricted data source.
- Do NOT use Puppeteer/headless browser for UCI (they block scraping). The `--disable-gpu` CloakBrowser arg is sufficient.
- Do NOT try to extract director/duration from UCI API — they don't exist there.
- Do NOT add complex Wikidata SPARQL queries — timeout on CONTAINS. `metadata.py` uses Search API + fuzzy fallback only.
- Do NOT re-add the lookup logic that overwrites scraper values with Wikidata. The guard in `metadata.py:enrich_film` only enriches fields that are missing in the Film (which was the FIX 6 of `PlanAudit.md`).

## Things that look broken but aren't

- A single Film appearing 4+ times in a UCI cache file is **normal** (one per day in the 8-day window). Dedup happens later.
- Films with empty `description`/`director`/`duration` — Wikidata rate-limit or no data, not a parser bug.
- `output/movies.json` "rating" field does **not** exist — removed per user request. README.md is stale on this.

## Deploy

`deploy/setup.sh` installs a systemd service + logrotate. Run from project root after `pip install -r requirements.txt`. Logs via `journalctl -u cinemascarper -f`. Manual: `cd /path && python3 -m scraper.main --once`.

There is also a `worker/` directory and `Cloudflare.md` — separate Cloudflare Worker frontend, not part of the scraper. Leave alone unless modifying frontend hosting.

## Audit (2026-06-17 / post-rollover 2026-06-18)

Tutti i 7 bug identificati dall'audit sono stati risolti (fixes 1-7 in `PlanAudit.md`). Per il report dettagliato vedi `AuditReport.md`:

| # | Cosa | Stato |
|---|---|---|
| FIX 1 | PostModernissimo merge RSC | ✅ mostra accumulate da tutte le occorrenze |
| FIX 2 | Director Wikidata come Q-id | ✅ lookup entità director per il nome reale |
| FIX 3 | `seen` come `[]` invece di `{}` in `main.py` | ✅ corretto |
| FIX 4 | TheSpace fallback date errato | ✅ rimosso, ora `continue` + warning |
| FIX 5 | Delta exclude film | ✅ (codice già corretto, non modificato) |
| FIX 6 | Metadata guard troppo aggressiva | ✅ guard su tutti i campi |
| FIX 7 | Director con spazi | ✅ `.strip()` in TheSpace |
| FIX 8 | TZ rollover Italy | ✅ `today_local()` Europe/Rome (2026-06-18 01:32 local) |

**Validazione visiva**: PostModernissimo 9/9 film match (MiniMax Vision), UCI 16/16 film match (API cross-check), TheSpace validato tramite API autenticata.
