# CinemaScarper — ARCHITECTURE

> Documento di riferimento per chiunque arrivi sul progetto senza averlo scritto.
> Stile: narrativo dove serve, reference dove serve. Ogni termine viene definito al primo uso.
> Citazioni `file:line` ovunque (come in `AGENTS.md`). Niente invenzioni: solo ciò che è nel codice o nei report.

---

## 0. TL;DR

CinemaScarper è uno **scraper Python** che, ogni 24 ore, raccoglie la programmazione cinematografica di **3 sale di Perugia** — PostModernissimo, The Space Cinema Corciano, UCI Cinemas Perugia — e produce un singolo file statico `output/movies.json` consumato da un frontend Cloudflare separato.

### Cosa fa, in 5 punti

1. **Per ogni giorno di oggi + i prossimi 7** (finestra rolling di 8 giorni, ancorata al fuso `Europe/Rome`), interroga 3 fonti diverse — `requests`+HTML, API autenticata OAuth, API Cloud Run — una per cinema.
2. **Normalizza, deduplica e unisce** i film visti su più cinema (un film in sala sia a UCI sia a The Space = un solo record, con `present_in[]` multi-cinema).
3. **Arricchisce** i record con metadati mancanti (regista, durata, descrizione, locandina) via **Wikidata Search API**, con cache persistente su `.wikidata_cache.json` e circuit-breaker.
4. **Esegue un delta** contro `output/movies.json` del run precedente per marcare `removed`/`updated`/`added`, mantenere uno storico `history` per film, e scrivere uno snapshot giornaliero in `output/history/`.
5. **Per PostModernissimo, riconcilia homepage vs dettaglio** (FIX 9): dopo l'estrazione dalla homepage, per ciascun Film PostMod fa una GET extra sulla pagina di dettaglio del film e — se gli show differiscono — usa quelli del dettaglio come fonte canonica sugli orari. Dettaglio irraggiungibile (404/timeout) → nessuna regressione, vince la homepage.
6. **Scrive atomicamente** `output/movies.json` (file `.tmp` + `os.replace`) per evitare letture a metà da parte del frontend.

### Come si avvia

```bash
pip install -r requirements.txt    # dipendenze una tantum
python3 -m pytest tests/ -v        # 36 test, offline
python3 -m scraper.main --once     # un singolo giro (30-60s, richiede rete)
python3 -m scraper.main --schedule # scheduler APScheduler, ogni 24h
```

In produzione gira come servizio `systemd` (`cinemascarper.service`) installato da `deploy/setup.sh`, con `journalctl -u cinemascarper -f` per i log.

### Numeri reali (al 2026-06-18, post-`AuditReport.md`)

- **23 film** totali nel run pulito più recente.
- Distribuzione per cinema nel `movies.json` finale: **The Space 14, PostModernissimo 5, UCI 4**. UCI e PostModernissimo hanno film portati avanti dalla history (Masters of the Universe, Tra amore e inganni) che il delta conserva finché non superano `REMOVAL_THRESHOLD_DAYS = 7` (config.py:62).
- **9 film** PostModernissimo verificati manualmente con doppio controllo (MiniMax Vision + parser RSC live) — match 9/9.
- **16 film** UCI cross-checked via replica della stessa API Cloud Run — match 16/16.
- TheSpace: validato solo via API autenticata (il sito visuale non rende la programmazione corrente).

### Vincoli non negoziabili (dal codice + `AGENTS.md`)

- **Progetto commerciale.** Niente TMDB, OMDb o altre fonti con restrizioni commerciali.
- **Niente Puppeteer per UCI.** Loro bloccano lo scraping, ma la `requests` su backend Cloud Run passa. Il fallback CloakBrowser esiste solo per The Space (config.py:57-59).
- **UCI API non restituisce direttore/durata** → arrivano solo da Wikidata (o restano `null`).
- **Niente SPARQL Wikidata con `CONTAINS`**: timeout sistematico. Solo Search API + fuzzy.
- **`metadata.enrich_film` NON sovrascrive valori del connector**: arricchisce solo i campi mancanti. Questo è il FIX 6 (`metadata.py:208`).
- **Timezone rollover = Europe/Rome**, configurabile via `SCRAPER_TZ` (config.py:20). `date.today()` non va MAI usato in produzione: va sostituito da `today_local()` (config.py:77-83). Bug-reported 2026-06-18 alle 01:32 locali.

### Disclaimer su discrepanze API vs sito live (2026-06-18/19)

Il **18 giugno 2026** è parso che lo scraper "saltasse" dei film che l'utente vedeva a mano sui siti (es. UCI non mostrava `Il bacio della donna ragno` 19:40 né `Ti auguro ogni bene` 19:20, TheSpace non mostrava `Toy Story 5` 19:20 e 20:00).

Verifica manuale via replica delle stesse API ha confermato: **lo scraper estrae fedelmente ciò che le API restituiscono**. Le discrepanze dipendono dalle fonti upstream, non dal codice:

- **UCI Cloud Run `/programming/{date}`** marca alcuni film con `"not_today": true, "first_performance_day": "YYYY-MM-DD"` (es. il 18/06 era `2026-06-19` per `Il bacio della donna ragno` e `Ti auguro ogni bene`). Lo scraper onora quel flag (uci.py:95-96) perché è il contratto API: se fosse "non oggi", non ci sarebbero performances associate. Rilanciando il 19/06 lo stesso film compare correttamente.
- **TheSpace microservice** per il 18/06 restituiva solo 5 orari di `Toy Story 5` invece di 6, e `Scary Movie` solo 22:25 invece di 20:10+22:25. Le API dei cinema pubblicano solo ciò che è disponibile a levelello di backend — il sito web renderer può mostrare di più attingendo ad altri endpoint/cached HTML.

**Implicazione**: lo scraper è la "source of truth" rispetto alle API. Se l'utente vede un film/orario sul sito live ma non in `movies.json`, la causa è upstream. Workaround possibile (non implementato per vincoli di Constraints in AGENTS.md): parsare il sito con CloakBrowser come fallback per UCI (oggi 403 da Cloudflare, ma aggirabile). Per TheSpace il fallback CloakBrowser esiste già (thespace.py:268) ma non viene attivato automaticamente quando l'API risponde con dati parziali.

### Chi consuma `movies.json`

Un **Cloudflare Worker** separato (in `worker/`) pubblica il JSON al frontend. Il Worker è descritto in dettaglio nella **sezione 11**. Il frontend vero e proprio non è nel repo.

### Cosa NON è questo progetto

- Non è un backend di biglietteria.
- Non è un frontend: solo backend + generatore di JSON statico.
- Non è un crawler generalista: scarica solo i 3 cinema di Perugia e dintorni.
- Non è un servizio real-time: l'aggiornamento è giornaliero.

---

*Fine sezione 0.*

---

## 1. Glossario

Termini usati nel codice, nei log, e in questo documento. Definisco ogni termine qui, una volta sola, in ordine alfabetico sotto tre categorie.

### 1.1 Concetti di dominio (cinema, programmazione)

- **Cinema.** Una sala fisica. Nel codice è rappresentata da un connector (`scraper/connectors/{postmodernissimo,thespace,uci}.py`) e identificata da `cinema_slug` (stringa kebab-case, es. `the-space-corciano`). Il `cinema_name` è il nome leggibile (es. `"The Space Cinema Corciano"`, config.py:29).
- **Programmazione.** L'insieme di film in sala in un dato cinema. Lo scraper la scarica giorno per giorno (`today` → `today + 7`).
- **Showing / Spettacolo.** Una singola proiezione: cinema + data + ora + sala + lingua. Nel codice è la dataclass `Showing` (models.py:13-21). Lista di `Showing` per un film = `Film.present_in`.
- **Film.** L'unità logica (in italiano "film", da non confondere con la pellicola). Nel codice è la dataclass `Film` (models.py:25-36). Un film può esistere in 1, 2 o 3 cinema contemporaneamente: in quel caso vive un solo oggetto `Film` con più `Showing` nel `present_in`.
- **Finestra 8-giorni.** Il range di date che lo scraper tratta ogni run: oggi (in Europe/Rome) + i prossimi 7 giorni. Implementato da `get_week_dates()` in config.py:72-74. Si chiama `week_dates` nel main loop (`main.py:89`), ma **non è** lunedì-domenica.
- **Status di un film.** `"in_programmazione"` (default) oppure `"rimosso"` (delta.py:132). I film `"rimosso"` vengono filtrati fuori da `merge_films()` (delta.py:147-151) e quindi non compaiono in `movies.json` — il frontend non li vede.
- **History.** Lista di `{"date": "...", "action": "added"|"updated"|"removed"}` dentro a `Film.history`. Indica la cronologia delle transizioni di stato. Solo i film persistiti tra run la hanno non vuota.

### 1.2 Concetti tecnici (Python, scraping, network)

- **Connector.** Classe che eredita `BaseConnector` (`scraper/connectors/base.py:9`) e sa come scaricare la programmazione di UN singolo cinema. Interfaccia: 2 property (`cinema_name`, `cinema_slug`) + 2 metodi (`scrape(today, dates) -> ScrapeResult`, `fetch_film_detail(film_url) -> Optional[dict]`).
- **ScrapeResult.** La dataclass restituita da `connector.scrape()` (models.py:60-62). Contiene `films: list[Film]` e `errors: list[CinemaError]`.
- **CinemaError.** Errore strutturato (models.py:40-56): cinema, timestamp ISO, exception class name, fase ("scrape" / "scrape_fallback" / "parse_programming_movie" / "parse_api_film"), url opzionale, detail. Viene accumulato in `output/errors.json` da `scraper/errors.py`.
- **Dedup / deduplica.** Fusione di più `Film` che rappresentano lo stesso titolo cinematografico in un unico `Film` con `present_in` multi-cinema. Fatto da `_deduplicate_films()` in main.py:209-235 usando `fuzzy_match()` (normalizer.py:77-86).
- **Fuzzy match.** Confronto tollerante di due titoli: chiavi identiche, oppure una contenuta nell'altra, oppure distanza di Levenshtein ≤ `max(2, len(k)//4)` (normalizer.py:84). Implementato in `scraper/normalizer.py`.
- **Levenshtein (edit distance).** Numero minimo di inserzioni/cancellazioni/sostituzioni per trasformare una stringa nell'altra. Implementazione O(n*m) iterativa in `normalizer.py:89-108`.
- **title_key.** Forma normalizzata di un titolo per il dedup: `normalize_title().lower()`, poi rimozione punteggiatura, poi collasso whitespace (normalizer.py:66-70). Esempio: `"Still Walking – Camminando..."` → `"stillwalkingcamminando..."`.
- **normalize_title.** Sequenza di regex per pulire suffissi di formato (`- 3D`, `IMAX`, anno `(2024)`, `C.A.`, `RIED.`, prefissi franchise, articoli) — vedi normalizer.py:32-63.
- **Enrichment.** Arricchimento dei `Film` con metadati mancanti da Wikidata. Fatto da `enrich_film()` (metadata.py:204-230). **Guard**: arricchisce SOLO i campi non ancora valorizzati dal connector.
- **Guard.** Il check all'inizio di `enrich_film` (metadata.py:208) che fa early-return se il Film ha già tutti i campi arricchibili. Serve a non sovrascrivere dati buoni dei connector.
- **Circuit breaker.** Meccanismo in `metadata.py` che dopo 3 fallimenti consecutivi di query Wikidata smette di interrogarle per quel run. Variabili globali `_consecutive_failures` (metadata.py:27) e `_rate_limited_until` (metadata.py:28).
- **Atomic write.** Pattern di scrittura file in 2 step: scrivi `path + ".tmp"`, poi `os.replace(tmp, real)`. Garantisce che chi legge veda o il vecchio file o il nuovo, mai un file a metà. Usato in `main.py:180-184` per `movies.json`.
- **Delta.** Confronto tra la situazione attuale (film appena scrape-ati) e la situazione precedente (film nel `output/movies.json` del run passato). Fatto da `merge_films()` in delta.py:42-151. Decide chi è nuovo, chi è aggiornato, chi è rimosso.
- **History snapshot.** Copia del `movies.json` finale, salvata come `output/history/movies_{YYYY-MM-DD}.json`. Fatto da `save_snapshot()` (delta.py:29-39).
- **Cache.** Due cache distinte:
  - `output/cache/{slug}.json`: il RAW per-cinema pre-dedup, scritto da `_save_cache` (main.py:23) prima della deduplicazione. Usato come fallback se la scrape di quel cinema fallisce (main.py:122-125).
  - `.wikidata_cache.json`: lookup Wikidata persistenti per titolo normalizzato (metadata.py:23, 31-50).
- **Rolling window.** Concetto generale: la finestra di date "scorre" in avanti ogni giorno. In CinemaScarper = finestra 8-giorni ancorata a `today`.
- **RSC (React Server Components).** Formato di streaming HTML usato da Next.js 13+: la pagina contiene molti `<script>self.__next_f.push([1,"..."])</script>` con JSON serializzato. PostModernissimo lo usa al posto di una vera API. Parser: `_parse_rsc_payload()` in postmodernissimo.py:207-260.
- **OAuth client_credentials.** Flusso OAuth2 in cui l'app si autentica con sole `client_id`+`client_secret`, senza utente umano, ottenendo un `access_token`. Usato da TheSpace (config.py:33, thespace.py:106-107).
- **CloakBrowser.** Browser anti-fingerprint basato su Chromium con stealth mode. Vedi `scraper/browser.py`. Usato come fallback se l'API TheSpace è giù (thespace.py:268-320).
- **Atomic-ish / fuzzy commit.** Vedi sopra "Atomic write".
- **Validate-before-write (deduplicazione consolidata).** Quando `_consolidate_showings()` (models.py:65-98) raggruppa `Showing` per chiave `(cinema, cinema_slug, date, language, screen, session_attributes)` e unisce le `times` deduplicandole e ordinandole. Fondamentale per il match nel delta.
- **API gap.** Differenza tra ciò che il sito live di un cinema mostra all'utente e ciò che l'API (o la fonte di scraping) effettivamente restituisce. Esempio: il backend UCI marca film come `not_today: true` quando il sito li sta già mostrando. Lo scraper onora il flag, quindi il film "manca" in `movies.json` nonostante sia visibile sul sito. Vedi "Disclaimer su discrepanze API vs sito live" in sezione 0.
- **Campi non estratti (gap inverso).** Le API forniscono più dati di quelli che lo scraper utilizza: TheSpace API ha `cast`, `originalTitle`, `certificate`, `trailers`, `releaseDate`, `distributor` — attualmente non vengono scritti nel `Film`. UCI API ha `rating` (classificazione età) e `room` per performance (es. "SALA 10") — lo scraper cattura solo il `screen.name` (= formato "2D"/"3D"). PostModernissimo non setta mai il campo `language` sul `Showing`. Estendere la copertura richiede modifiche al `Film` model e al delta.
- **Date / ISO date.** Tutte le date sono stringhe `"YYYY-MM-DD"`. Costruzione in `config.get_week_dates()` (config.py:72-74) e nel delta (delta.py:103-105).
- **JSON shape movies.json.** Schema concreto documentato in sezione 8.

### 1.3 Termini operativi (issue, workflow)

- **FIX N.** Riferimento a una delle 8 correzioni dell'audit (`PlanAudit.md`, applicate 2026-06-17 + 2026-06-18). In questo documento mappate in sezione 6.
- **Audit.** Sessione di validazione dello scraper contro i siti live + applicazione dei fix. Documentata in `AuditReport.md`.
- **Rollback / Revert.** Tornare indietro a `HEAD~1` su un singolo file dopo aver introdotto un bug. Mai fatto in modo esotico: solo `git checkout`.
- **Schema Film.** L'insieme dei campi canonici di `Film` (models.py:25-36). Qualsiasi aggiunta (es. "rating") rompe il contratto col frontend.
- **Schema movies.json.** L'output finale wrappato (`generated_at`, `city`, `films[]`, `errors[]`). Schema e esempio reale in sezione 8.

---

---

## 2. Mappa ad albero del repo

Albero con 1 riga di descrizione per ogni file. Non ridondante con la sezione 5 (reference per modulo): lì c'è il dettaglio, qui c'è l'orientamento. Lettura suggerita: in quest'ordine.

```
CinemaScarper/
├── scraper/                                # Package Python (entry point: main.py)
│   ├── __init__.py                         # File vuoto, marca il package
│   ├── config.py                           # 83 righe. Costanti + helper data (`today_local`, `get_week_dates`)
│   ├── main.py                             # 268 righe. CLI entry point, orchestrazione 3 connector, dedup, write atomico
│   ├── models.py                           # 133 righe. Dataclass: Showing, Film, CinemaError, ScrapeResult + serializzazione
│   ├── normalizer.py                       # 143 righe. Pulizia titoli, fuzzy_match (Levenshtein), normalize_duration
│   ├── delta.py                            # 199 righe. Merge_films vs movies.json precedente, snapshot history
│   ├── errors.py                           # 54 righe. Writer per output/errors.json (cumulo giornaliero)
│   ├── metadata.py                         # 230 righe. Wikidata Search API + cache + circuit breaker
│   ├── browser.py                          # 84 righe. Wrapper CloakBrowser singleton, fallback per The Space
│   └── connectors/
│       ├── __init__.py                     # File vuoto
│       ├── base.py                         # 26 righe. ABC BaseConnector (cinema_name, cinema_slug, scrape, fetch_film_detail)
│       ├── postmodernissimo.py             # 419 righe. Concatena film/mostre da payload RSC Next.js, fallback HTML cards
│       ├── thespace.py                     # 353 righe. OAuth client_credentials + API microservice, fallback CloakBrowser
│       └── uci.py                          # 227 righe. Backend Cloud Run programming/{date}, no auth, no director/duration
│
├── tests/                                  # pytest, offline (no network)
│   ├── __init__.py
│   ├── test_config.py                      # 51 righe. get_week_dates + today_local (rollover Italy + FIX 8)
│   ├── test_models.py                      # 80 righe. Showing/Film/CinemaError/output_to_json contract
│   ├── test_normalizer.py                  # 30 righe. normalize_title/title_key/normalize_duration
│   ├── test_delta.py                       # 120 righe. merge_films happy path + edge cases (rimosso, repeated)
│   ├── test_postmodernissimo.py            # 151 righe. Connector con HTML/RSC mockato via `responses`
│   ├── test_uci.py                         # 100 righe. Strip HTML + connector con API mockata
│   ├── test_fix_validation.py              # 305 righe. SPEC esplicita di ogni FIX audit (FIX 1..FIX 7)
│   └── test_postmod_detail_reconcile.py    # 158 righe. FIX 9: reconciliation homepage vs dettaglio (Palestina-style)
│
├── worker/                                 # Frontend-side (sezione 11 ha il dettaglio)
│   ├── Makefile                            # `make deploy` = `npx wrangler deploy`
│   ├── src/index.js                        # 202 righe. Worker principale, proxy UCI + parsing Nuxt `__NUXT__`
│   ├── functions/api/proxy.js              # 138 righe. Variante Cloudflare Pages Function della stessa idea
│   └── pages-public/
│       └── index.html                      # 2 righe. Pagina statica placeholder ("UCI Proxy")
│
├── deploy/                                 # Setup produzione (sezione 10)
│   ├── setup.sh                            # 36 righe. pip install + service systemd + output dir
│   ├── cinemascarper.service               # 19 righe. Unit systemd Type=simple, --schedule, RestartSec=60
│   └── cinemascarper-logrotate             # 9 righe. Logrotate daily, rotate 7
│
├── output/                                 # Generato a runtime (gitignored)
│   ├── movies.json                         # Output principale, scritto atomicamente da main.py
│   ├── errors.json                         # Accumulato da errors.py (attualmente assente = zero errori)
│   ├── cache/                              # RAW per-cinema pre-dedup (fallback se scrape fallisce)
│   │   ├── postmodernissimo.json
│   │   ├── the-space-corciano.json
│   │   └── uci-perugia.json
│   └── history/                            # Snapshot giornalieri di movies.json
│       └── movies_YYYY-MM-DD.json
│
├── scraper.log                             # Logger root, scritto da setup_logging() in main.py:76-84
├── .wikidata_cache.json                    # Cache lookup Wikidata, persistente (gitignored)
├── .gitignore                              # Esclude: __pycache__, .wikidata_cache.json, scraper.log, output/, worker/.wrangler/
│
├── requirements.txt                        # 5 righe. requests, beautifulsoup4, lxml, cloakbrowser, apscheduler
│
├── README.md                               # Quick-start marketing (147 righe, un po' stale: cita "rating")
├── PLAN.md                                 # 59 righe. Roadmap 4 fasi (Fase 4 lasciata aperta come reminder)
├── PRD.md                                  # 188 righe. Product Requirements Document originale (parla di TMDb, superato)
├── UCI_API_RESEARCH.md                     # 218 righe. Come è stata scoperta la via Cloud Run che bypassa Cloudflare
├── AGENTS.md                               # 76 righe. Note AI-oriented per assistente (FIX 1-8, gotchas)
├── AuditReport.md                          # 169 righe. Report audit 2026-06-17 + appendice FIX 8
├── PlanAudit.md                            # 292 righe. Piano audit + fix checklist
├── Cloudflare.md                           # 378 righe. Articolo blog su bypass Cloudflare (background only, non del progetto)
└── ARCHITECTURE.md                         # ← QUESTO FILE
```

### Lettura consigliata per un newcomer

1. `README.md` + questo file (sezione 0-3): orientamento in 20 minuti.
2. `scraper/main.py`: il loop centrale.
3. `scraper/connectors/base.py`: il contratto che ogni cinema deve rispettare.
4. Un connector per volta nell'ordine UCI → PostModernissimo → The Space (crescendo in complessità).
5. `scraper/delta.py` + `metadata.py`: la logica di cross-run.
6. `AuditReport.md` + `PlanAudit.md`: capire perché certe cose sono scritte così storta.
7. `worker/src/index.js`: solo per capire come il JSON arriva al frontend.

### File che sembrano importanti ma NON lo sono per il flusso scraper

- `worker/`: descritto in sezione 11, è un'altra app. Non viene toccata da `python3 -m scraper.main`.
- `Cloudflare.md`: è un articolo generico su "bypass Cloudflare con scraping" (browserless.io). Nessun impatto sul codice del progetto. Tenuto come background reading perché risolve la domanda "perché UCI restituisce 403 sul sito ma 200 sull'API Cloud Run".
- `PRD.md` / `PLAN.md`: documenti risalenti a prima della decisione Wikidata (parlano di TMDb). Storicamente utili, ma operativamente `AGENTS.md` è la fonte di verità corrente.

---

*Fine sezione 2.*

---

## 3. Concetti base prima del codice

Questa sezione spiega le 5 cose da capire PRIMA di leggere qualsiasi file. Saltala solo se hai già familiarità con progetti simili (scraper multi-fonte + arricchimento + delta merge).

### 3.1 Cos'è un connector — il "contratto" tra scraper e cinema

Tutto il codice del singolo cinema vive in **UN SOLO FILE** sotto `scraper/connectors/`. Quel file è una classe che eredita `BaseConnector` (`connectors/base.py:9-26`), definita come:

```python
class BaseConnector(abc.ABC):
    cinema_name  -> str           # nome leggibile, es. "The Space Cinema Corciano"
    cinema_slug  -> str           # kebab-case, es. "the-space-corciano"
    scrape(today, dates=None) -> ScrapeResult
    fetch_film_detail(film_url) -> Optional[dict]
```

Due cose importanti:

1. **`scrape()` lavora su una finestra di date**, non giorno-per-giorno: prende `dates: list[str]` (le 8 date ISO restituite da `get_week_dates()`). Ogni connector decide se fare una request HTTP per ogni data (UCI, TheSpace) o una sola request che le contiene tutte (PostModernissimo). Vedi sezione 5 per il dettaglio per cinema.
2. **`ScrapeResult` non è mai "tutto o niente"**: può tornare films=[] e errors=[CinemaError(...)]. Il main loop tollera errori per cinema e usa la cache come fallback (main.py:117-135).

Il `BaseConnector` è il punto in cui si vede l'**interfaccia comune**: 3 cinema, 3 fonti completamente diverse (HTML scraping per PostMod, API OAuth per TheSpace, API Google Cloud Run per UCI), esposti al main loop in modo uniforme.

### 3.2 Cos'è un Film — l'unità logica e perché alcuni campi sono `null`

`Film` è una `@dataclass` (models.py:25-36) con questi campi:

| Campo | Tipo | Default | Da dove arriva |
|---|---|---|---|
| `title` | str | required | connector |
| `title_normalized` | str | required | connector (lowercase.strip del title) |
| `present_in` | list[Showing] | [] | connector (uno o più Showing) |
| `poster` | Optional[str] | None | connector o Wikidata |
| `description` | Optional[str] | None | connector o Wikidata |
| `genres` | list[str] | [] | connector o Wikidata |
| `status` | str | `"in_programmazione"` | delta (`"in_programmazione" \| "rimosso"`) |
| `history` | list[dict] | [] | delta (`added`/`updated`/`removed` con date) |
| `source_poster` | Optional[str] | None | connector, usato come "originale" prima del merge |
| `duration` | Optional[str] | None | connector (TheSpace, PostMod) o Wikidata; mai UCI |
| `director` | Optional[str] | None | connector o Wikidata; mai UCI come fonte diretta |

Nota: **`title_normalized` è popolato dai connessi stessi** (es. `title.lower().strip()`, thespace.py:183), non calcolato dal normalizer. Il normalizer serve solo per la `title_key` usata in dedup e delta.

**Campi null sono first-class citizens.** Il connettore UCI non fornisce `director` né `duration` perché la sua API Cloud Run non li possiede (`UCI_API_RESEARCH.md` + `AuditReport.md` §2). Lo scraper si comporta così: lascia `null`, poi prova Wikidata; se Wikidata manca o fallisce, resta `null`. L'output `movies.json` finale espone allora `"director": null` (verificabile aprendo il file — UCI "Allora balliamo" ha `director: "Amélie Bonnin"` da Wikidata e `duration: null` confermando il pattern).

### 3.3 Finestra 8-giorni rolling e timezone Europe/Rome (FIX 8)

`get_week_dates()` (config.py:72-74) ritorna **esattamente 8 date ISO**, a partire da `today`:

```python
return [(d + timedelta(days=i)).isoformat() for i in range(8)]
```

Importante: **non** una settimana lunedì-domenica. **Sempre** `today → today+7`. Su due run consecutivi, la prima data della finestra cambierà (da `2026-06-18` a `2026-06-19`, ecc.).

`ref_date` è opzionale: se omesso, viene preso da `today_local()` (config.py:77-83):

```python
def today_local() -> date:
    return datetime.now(SCRAPER_TZ).date()
```

`SCRAPER_TZ` è letto da env, default `"Europe/Rome"` (config.py:20).

**FIX 8 (bug 2026-06-18 01:32 locali):** prima, `main.py:88` usava `date.today()`, che su un server Ubuntu con `TZ=UTC` ritorna la data UTC. Tra mezzanotte italiana e l'1:00 UTC (inverno) o le 2:00 UTC (estate), `date.today()` è ancora il giorno precedente → la finestra restava ancorata al giorno sbagliato. Sostituito con `today_local()`.

Test: `tests/test_config.py:38-46` simula Rome=01:30 e verifica che venga ritornato il giorno D+1 anche se UTC è ancora D.

### 3.4 Dedup fuzzy — perché non basta il match esatto

I 3 cinema etichettano lo stesso film in modo diverso:

- UCI: `"Ricchi da morire – Delitti in famiglia"`
- PostMod: `"Ricchi… da morire"` (apostrofo curvo, ellissi)
- The Space: `"Ricchi da morire – Delitti in famiglia"`

Se li mettessi insieme con `==`, otterresti 3 record separati. Per evitare questo, `_deduplicate_films()` (main.py:209-235) usa `fuzzy_match()` (normalizer.py:77-86):

```python
def fuzzy_match(a: str, b: str) -> bool:
    ka = title_key(a)
    kb = title_key(b)
    if ka == kb: return True
    if ka in kb or kb in ka: return True
    if _edit_distance(ka, kb) <= max(2, len(ka) // 4): return True
    return False
```

Funzionamento: `title_key` pulisce entrambi (suffissi formato, anno, punteggiatura, spazi) e poi decide con 3 regole in ordine:
1. **Identici** → merge.
2. **Uno è sottostringa dell'altro** → merge (caso "Ricchi da morire" ⊂ "Ricchi da morire – Delitti in famiglia").
3. **Edit distance ≤ max(2, len/4)** → merge (Levenshtein tollerante).

Complessità O(n²) su ~30 film: trascurabile.

Effetto osservabile in `movies.json`: il film "Ricchi… da morire" appare in **un solo record** con `present_in[]` contenente Showing sia di PostMod sia di UCI (verifica effettiva sui 16 film UCI cross-checked in `AuditReport.md` §2).

### 3.5 Output null vs [] — semantica JSON dei null mancanti

Regola, mantenuta coerentemente in `scraper/models.py:film_to_dict` (models.py:112-124):

- **Campi stringa mancanti** (`poster`, `description`, `director`, `duration`): `null` in JSON.
- **`genres` mancante**: serializzato come `null` (NON `[]`) da `film_to_dict` (models.py:118): `film.genres if film.genres else None`. Questo è il FIX parziale della Fase 4 in `PLAN.md` §D applicato in models.py, non documentato nel README.
- **Liste vuote legittime** (es. `session_attributes: []`): NON serializzate → chiave omessa dall'output (modello: `models.py:_consolidate_showings` rimuove entries `None/`/`""/[]`, models.py:96).
- **`present_in[]`**: array di oggetti; array vuoto solo se il film è in programming ma ha perso tutti gli show (caso "rimosso").

Conseguenza pratica per il frontend: distinguere `null` (=campo assente, "non so") da chiave assente (=caso impossibile nei record Film, sempre serializzata anche come `null`). Esempio reale in `output/movies.json` per un film UCI senza durata:

```json
{
  "title": "Allora balliamo",
  "director": "Amélie Bonnin",
  "duration": null,
  "genres": ["Commedia"]
}
```

### 3.6 Campi che non esistono (per evitare di cercarli)

- **NO `rating`** in `Film`, `Showing`, `ScrapeResult`. Era nel README (`README.md:53`), è stato rimosso. Cercare `rating` nel codice porta solo a ricerche in campo `rating` del JSON UCI API (campo descrizione/età, NON scalare). `AGENTS.md` §"Things that look broken but aren't" lo dichiara esplicitamente.
- **NO `rating_tmdb`** — il PRD.md lo cita (`PRD.md:62`), ma è un piano vecchio pre-Wikidata. Rimosso.
- **NO `price`** su `Showing` — i 3 cinema non pubblicano prezzi programmaticamente e il PRD lo prevedeva (PRD.md:79) ma non è mai stato implementato. Il frontend non lo usa.

---

*Fine sezione 3.*

---

## 4. Data flow end-to-end

Questa sezione descrive un singolo run del comando `python3 -m scraper.main --once`. Tempo tipico: 30-60 secondi (3 connector in sequenza, con un eventuale retry di 5 minuti se uno fallisce).

### 4.1 Entry point: cosa viene invocato

CLI → arg parser (main.py:256-268):
- `--once` (default): `run_scraper()` → termina.
- `--schedule`: `schedule()` → APScheduler blocking, ogni 24h (`SCHEDULE_INTERVAL_HOURS`, config.py:61).

`setup_logging()` (main.py:76-84): `basicConfig` con `StreamHandler(sys.stdout)` + `FileHandler("scraper.log", encoding="utf-8")`. Il livello è letto da `LOG_LEVEL` (env `SCRAPER_LOG_LEVEL`, default `INFO`).

### 4.2 Pipeline in 14 step

```
[1] main.run_scraper()                                          main.py:87
       │
       ├─ today      = today_local().isoformat()               config.py:77-83
       ├─ week_dates = get_week_dates()                        config.py:72-74
       │              (8 date ISO, today → today+7, Europe/Rome)
       │
[2] connectors = [                                             main.py:93-97
         PostModernissimoConnector(),
         TheSpaceConnector(),
         UCIConnector(),
       ]
       │ (ordine hardcoded — aggiungere un cinema = lista.append)
       ▼
[3] for each connector:                                        main.py:103-116
       ├─ try:
       │    result = connector.scrape(today, dates=week_dates)
       │    ├─ ok  → all_films.extend(result.films)
       │    │        _save_cache(connector.cinema_slug, result.films)  → output/cache/{slug}.json
       │    │        (per PostMod: dentro result.films sono già passati per
       │    │         _reconcile_with_detail(postmodernissimo.py:206-207) — FIX 9.
       │    │         Se la homepage sosteneva N show e il dettaglio ne ha M<N,
       │    │         vince il dettaglio, fonte canonica)
       │    └─ errors → all_errors.extend(result.errors)
       └─ except Exception:
              failed_connectors.append(connector)
              cached = _load_cache(connector.cinema_slug)      → può essere None
              if cached: all_films.extend(cached)
              all_errors.append(CinemaError(...))              with detail=str(exc)
                                                              (main.py:127-135)
       ▼
[4] RETRY (se failed_connectors non vuoto):                    main.py:137-158
       time.sleep(300)  # 5 minuti
       for each failed connector:
         try: result = connector.scrape(today, dates=week_dates)
         except: log "STILL FAILED" (nessun nuovo errore creato)
       ▼
[5] _deduplicate_films(all_films)                              main.py:161, 209-235
       usa fuzzy_match su title_normalized → un Film per titolo,
       con present_in[] che unisce Showing di cinema diversi
       ▼
[6] for each film: enrich_film(film)                           main.py:163-168 → metadata.py:204-230
       guarda se mancano (poster,description,director,duration,genres)
       se sì → cerca su Wikidata Search API → cache .wikidata_cache.json
       solo se la lookup restituisce i campi, li compila
       (la guard NON sovrascrive valori del connector)
       ▼
[7] previous_data = load_previous_movies()                     delta.py:17-26
       legge output/movies.json se esiste, ritorna data["films"] altrimenti []
       ▼
[8] merged_films = merge_films(all_films, previous_data, today) delta.py:42-151
       per ogni film nuovo:
         esiste nel precedente? confronta present_in via _showings_changed
         ├─ sì + cambiamenti → history += {"action":"updated", date:today}
         ├─ sì + stesso      → history invariata
         └─ no               → history = [{"action":"added", date:today}]
       per ogni film del precedente NON visto oggi:
         ├─ "rimosso" già, >2*REMOVAL_THRESHOLD_DAYS = purge
         ├─ "rimosso" da meno di 2*7 giorni → resta rimosso in output
         ├─ non visto da >REMOVAL_THRESHOLD_DAYS=7 → marca rimosso, history += removed
         └─ non visto da <7 giorni → resta in_programmazione con present_in=[]
       filtro finale (FIX 5): via solo film "rimosso" o senza orari ovunque
       ▼
[9] for each merged_film:                                     main.py:174-176
       if not film.poster and film.source_poster:
         film.poster = film.source_poster
       (retro-fix per cache che ha perso il poster tra source e output)
       ▼
[10] output = output_to_json(merged_films, all_errors, CITY)   models.py:127-133
       wrapper = {generated_at, city, films:[...], errors:[...]}
       ▼
[11] ATOMIC WRITE:                                             main.py:180-187
       scrivi output/movies.json.tmp → os.replace(.tmp, movies.json)
       (se exception: log + exc_info, NON sovrascrivi il file vero)
       ▼
[12] save_snapshot(today)                                      delta.py:29-39
       shutil.copy2(output/movies.json, output/history/movies_{today}.json)
       (no-op se movies.json non esiste)
       ▼
[13] write_errors(all_errors, today)                           errors.py:14-54
       se errors=[] → rimuove solo le entry con date=today da errors.json esistente
       se errors=[] → aggiunge le nuove, aggiorna last_error_date/timestamp
       (schema vedi sezione 8)
       ▼
[14] close_browser() (lazy, dentro try/except)                 main.py:192-197 → browser.py:59-66
       try: from scraper.browser import close_browser; close_browser()
       except: pass   # logging assorbito da browser.close_browser stesso
       ▼
[15] log finale                                                main.py:199-206
       "=== Scraper complete: N active, M removed, K errors ==="
```

Fine. Il worker `output/movies.json` è pronto per essere consumato dal Worker Cloudflare (sezione 11) e quindi dal frontend.

### 4.3 Per-cosa vive `scraper.log`

`scraper.log` è il file principale di LOG. Ci arriva tutto:
- INFO di inizio/fine di ogni fase (`=== Cinema Scraper started (...) ===`, `Week dates: ...`).
- INFO per connector: numero film/errori di ritorno.
- WARNING su fallback cache.
- ERROR su scrape failure (con traceback, `exc_info=True`).
- WARNING su Wikidata 429, fallimento di una enrichment specifica.
- INFO sul numero finale: attivi, rimossi, errori.

Più `journalctl -u cinemascarper -f` in produzione (vedi sezione 10).

### 4.4 Cosa NON accade in un run

- **Niente browser headless per UCI/PostMod.** TheSpace può usarlo come fallback API, ma in condizioni normali solo `requests`.
- **Niente persistenza intermedia oltre cache/history.** `merged_films` vive in memoria e poi esce solo come `movies.json`.
- **Niente update dei file di cache per dati già dedupati.** La cache è SEMPRE RAW per-cinema, pre-dedup.
- **Niente chiamate di rete se `--once` viene runnato offline con la cache piena.** I connector falliranno uno per uno, ma ognuno avrà il fallback cache (main.py:122-125). Lo scraper produrrà un `movies.json` corretto anche offline, **purché i connector NON degradino diversamente da "fail + cache fallback"**.

### 4.5 Caso limite critico: tutti i connector falliscono in un nuovo deploy

Se è il PRIMO run (no `movies.json` precedente, no cache), e tutti e 3 i connector falliscono:
- `all_films = []`, `all_errors` popolato.
- `_deduplicate_films([])` → `[]`.
- Loop enrichment → no-op.
- `merge_films([], [], today)` → `[]`.
- `output_to_json([], [...], CITY)` → `{"films": [], "errors": [...], ...}`.
- Atomic write scrive un `movies.json` vuoto (valido, ma con `films=[]`).
- Snapshot comunque scritto.
- `write_errors` accumula.

Conseguenza pratica: **il frontend si rompe** in visualizzazione (`movies.json.films[]` vuoto). Il log recrimina 3 "SCRAPE FAILED". È un failure mode noto, gestito a livello alerting (vedi sezione 10) — non è uno stato "corretto".

---

*Fine sezione 4.*

---

## 5. Riferimento per modulo

Un modulo = un file Python di primo livello (più i sub-modulo `connectors/`). Per ogni modulo: scopo, contract I/O, invarianti, citazioni chiave dal codice. I moduli sono in ordine di esecuzione (entry → connectors → arricchimento → delta → output).

### 5.1 `scraper/config.py` — costanti e helper data

**Path:** `scraper/config.py` · **83 righe** · **Nessuna dipendenza interna.** Foglia del grafo.

#### Cosa contiene

- **Path** (8) derivati da `BASE_DIR = Path(__file__).resolve().parent.parent`:
  - `OUTPUT_DIR`, `HISTORY_DIR`, `CACHE_DIR` (linee 9-11)
  - `MOVIES_JSON`, `ERRORS_JSON` (12-13) → output finale + errori.
  - `SCRAPER_LOG` = `BASE_DIR / "scraper.log"` (14) → log principale.
  - `WIKIDATA_CACHE` = `BASE_DIR / ".wikidata_cache.json"` (15) → cache lookup Wikidata persistente.

- **Side effect all'import**: `OUTPUT_DIR.mkdir(...)`, `HISTORY_DIR.mkdir(...)`, `CACHE_DIR.mkdir(...)` (config.py:22-24). Importare `scraper.config` garantisce le directory esistano. Non è un problema, è una feature.

- **Costanti città (1):** `CITY = "Perugia"` (26).

- **Costanti TheSpace (10, linee 28-37):** cinema ID, nome, slug, base URL, API base, auth URL, films URL, showingDates URL, film detail URL, cinema URL. L'API è una "microservice" proprietaria con OAuth2 client_credentials.
  - `THE_SPACE_CINEMA_ID = 1027` (28) — ID fisso del cinema.
  - `THE_SPACE_AUTH_URL = "https://www.thespacecinema.it/api/microservice/auth/token"` (33) — endpoint OAuth2.
  - `THE_SPACE_FILMS_URL = f"{THE_SPACE_API_BASE}/showings/cinemas/1027/films"` (34) — endpoint films+showings.

- **Costanti UCI (6, linee 39-45):** nome, slug, base URL, cinema URL, film detail URL, API base su Cloud Run `https://myuci---uci-backend-production-nfluwp7wga-oc.a.run.app`, programming URL templated `/api/theatres/uci-cinemas-perugia/programming/{date}`.

- **Costanti PostMod (4, linee 47-51):** nome, slug, base URL, film detail URL. Niente API esposta: si fa scraping HTML della homepage.

- **Network/retry (3):** `REQUEST_TIMEOUT = 30` (53), `REQUEST_RETRY = 3` (54), `RETRY_BACKOFF = 2` (55). Backoff esponenziale → sleep tra tentativi = `RETRY_BACKOFF ** attempt` → 2s, 4s.

- **CloakBrowser (3, linee 57-59):** fingerprint seed (letto da env `CLOAKBROWSER_FINGERPRINT_SEED`, default `"42069"`), `CLOAKBROWSER_HEADLESS` (env, default `"true"`), `CLOAKBROWSER_PAGE_TIMEOUT = 30000ms`.

- **Scheduling/Delta (2):** `SCHEDULE_INTERVAL_HOURS = 24` (61), `REMOVAL_THRESHOLD_DAYS = 7` (62) — soglia per marcare un film come `rimosso`.

- **Wikidata (3, linee 64-66):** endpoint SPARQL (URL), User-Agent personalizzato `CinemaScarper/1.0 (https://github.com/cinemascarper; contact@cinemascarper.it)`, timeout 15s.

- **Logging (2, linee 68-69):** `LOG_FORMAT`, `LOG_LEVEL` (env `SCRAPER_LOG_LEVEL`, default `INFO`).

#### Funzioni pubbliche

| Riga | Firma | Note |
|------|-------|------|
| 72 | `def get_week_dates(ref_date: date \| None = None) -> list[str]` | 8 date ISO a partire da `ref_date` (o `today_local()`). NON Mon–Sun, NON lunedì-domenica. |
| 77 | `def today_local() -> date` | `datetime.now(SCRAPER_TZ).date()` — FIX 8. |

#### Env lette

- `SCRAPER_TZ` → `SCRAPER_TZ` (20)
- `CLOAKBROWSER_FINGERPRINT_SEED` → seed CloakBrowser (57)
- `CLOAKBROWSER_HEADLESS` → headless bool (58)
- `SCRAPER_LOG_LEVEL` → livello logging (69)

#### Cross-reference

Importato da: `main.py`, `delta.py`, `errors.py`, `metadata.py`, `browser.py`, `connectors/{postmodernissimo,thespace,uci}.py`, `tests/test_config.py`.

---

### 5.2 `scraper/models.py` — dataclass e serializzazione JSON

**Path:** `scraper/models.py` · **133 righe** · Importa `scraper.normalizer.normalize_duration` (9).

#### Dataclass

**`Showing`** (models.py:13-21). Una singola proiezione con cinema/date/times/sala/lingua/attributi.

```python
@dataclass
class Showing:
    cinema: str
    cinema_slug: str
    date: str                              # ISO "YYYY-MM-DD"
    times: list[str] = []                  # es. ["18:00","20:30"]
    screen: Optional[str] = None           # es. "Sala 1", "2D"
    source_url: Optional[str] = None       # link al dettaglio del film sul sito del cinema
    language: Optional[str] = None         # "ITA", "ITALIANO", "VOST"
    session_attributes: list[str] = []     # es. ["3D","IMAX"] o ["ITALIANO","2D"]
```

**`Film`** (models.py:25-36). L'unità logica. Campi decisionali:
- `status: str = "in_programmazione"` (32) — l'unica alternativa è `"rimosso"`, applicata dal delta.
- `history: list[dict] = []` (33) — valori dict: `{"date": "YYYY-MM-DD", "action": "added"|"updated"|"removed"}`.
- `source_poster` (34) — popolato dai connector, usato come fallback in main.py:174-176.

**`CinemaError`** (models.py:40-56). 6 campi: cinema, timestamp ISO, exception class, phase, url, detail. Metodo `to_dict()` (48-56) per serializzazione.

**`ScrapeResult`** (models.py:60-62). Container: `films: list[Film]`, `errors: list[CinemaError]`.

#### Funzioni

| Riga | Firma | Note |
|------|-------|------|
| 65 | `_consolidate_showings(showings) -> list[dict]` | Raggruppa per chiave `(cinema, cinema_slug, date, lang, screen, attrs_sorted)`, unisce `times` deduplicati+ordinati. Rimuove entries con valori vuoti (None/`""`/`[]`). Fondamentale per la matching in delta. |
| 101 | `_clean_poster(url) -> str \| None` | Se il poster è un URL di proxy Next.js (`/_next/image?url=...`), estrae l'`url` reale. Vedi `_next/image` in PostModernissimo. |
| 112 | `film_to_dict(film) -> dict` | Serializzazione Film: `html.unescape` su title/normalized/description; `_clean_poster` su poster; `normalize_duration(film.duration)`; `genres=None` se vuoto (FIX parziale Fase 4 di PLAN.md); `_consolidate_showings` su present_in. |
| 127 | `output_to_json(films, errors, city="Perugia") -> dict` | Wrapper: `{"generated_at": datetime.now().isoformat(), "city": city, "films": [...], "errors": [...]}`. |

#### Cross-reference

Importato da: `main.py`, `delta.py`, `tests/test_models.py`.

---

### 5.3 `scraper/normalizer.py` — pulizia titoli, fuzzy, durata

**Path:** `scraper/normalizer.py` · **143 righe** · Solo `re` come dipendenza esterna. Foglia del grafo (eccetto per `Film.duration` via models.py).

#### Regex compilate (verbatim, linee 5-29)

```python
_TITLE_SUFFIXES   # suffissi formato: 3D IMAX HFR 4DX ScreenX EPIC Dolby Atmos Dolby Cinema
                  # VIP Gold OV VOST VO VF Versione Originale Sottotitolato Sub ITA Live
                  # Event F&S F&S Family Kids Matinée Sera Notte
_YEAR_SUFFIX      # (2024) o ( 2024 ) alla fine del titolo
_ROMAN_NUM_SUFFIX # I II III IV V VI VII VIII IX X XI finale
_RIEDITION_SUFFIX # " 4K (RIED. 2020)" o " 4K (RIED.2020) C.A."
_C_A_SUFFIX       # " C.A." o " CA" finale
_AND_WORD          # " AND " standalone
_FRANCHISE_PREFIXES # STAR WARS:, MARVEL['S], DC, PIXAR, Disney, THE, IL, LA
_ARTICLES = {"il","la","lo","le","gli","i","un","uno","una","di","del","della","dei","degli"}
```

#### Funzioni

| Riga | Firma | Logica |
|------|-------|--------|
| 32 | `normalize_title(title: str) -> str` | 1) Strip, 2) smart quotes → ASCII, 3) fino a 3 passate di `_TITLE_SUFFIXES.sub("", t)`, 4) RIEDITION, YEAR, C.A., AND_WORD, FRANCHISE_PREFIXES in sequenza, 5) `re.sub(r"\s+", " ", t)`, 6) strip leading/trailing ` .,;:!?-–—`, 7) se l'ultimo char NON è `)/]`, strip trailing digits. |
| 66 | `title_key(title: str) -> str` | `normalize_title(t).lower()`, poi `re.sub(r"[^\w\s]", "", ...)`, poi `re.sub(r"\s+", "", ...)`. Esempio: `"Still Walking – Camminando..."` → `"stillwalkingcamminando"`. |
| 73 | `titles_match(a, b) -> bool` | `title_key(a) == title_key(b)`. Definita ma **NON usata** da main.py, che usa `fuzzy_match`. |
| 77 | `fuzzy_match(a, b) -> bool` | (vedi sezione 3.4): identiche, una ⊂ l'altra, oppure Levenshtein ≤ max(2, len/4). |
| 89 | `_edit_distance(s1, s2) -> int` | Levenshtein iterativo O(n*m) riga-su-riga, ottimizzato (lavoro sempre sulla più corta). |
| 116 | `normalize_duration(d) -> str \| None` | Parsing robusto di vari formati: |

**`normalize_duration` — ordine di tentativi:**

1. Regex `_HMS_RE = re.compile(r"^(\d{1,2}):(\d{2})(?::(\d{2}))?$")` (111). Per `"01:45"` → 105 min. `"1:45:30"` → 106 min (round half-up sui secondi, 129).
2. Regex `_HOURS_MIN_RE = re.compile(r"(\d+)\s*h\s*(\d+)?\s*m?", IGNORECASE)` (113). Per `"1h 30m"` → 90 min. `"2h"` → 120 min.
3. Fallback: `re.findall(r"\d+", s)`, primo intero → `"X min"`. Per `"120"` → `"120 min"`. Per `" 100 minuti"` → `"100 min"`.
4. `None` se input `None`/`""`/no digits.

#### Cross-reference

Importato da: `main.py`, `models.py`, `delta.py`, `metadata.py`, `tests/test_normalizer.py`.

---

*Fine 5.1-5.3. Dimmi se procedo con 5.4-5.10 (resto dei moduli, incluso OAuth TheSpace) o se ritocchi qualcosa.*





### 5.4 `scraper/connectors/base.py` — l'ABC che tutti i cinema rispettano

**Path:** `scraper/connectors/base.py` · **26 righe** · Una sola dipendenza: `scraper.models.ScrapeResult` (6). File-foglia a parte per quel singolo import.

#### Il contratto (verbatim, linee 9-26)

```python
class BaseConnector(abc.ABC):
    @property
    @abc.abstractmethod
    def cinema_name(self) -> str: ...

    @property
    @abc.abstractmethod
    def cinema_slug(self) -> str: ...

    @abc.abstractmethod
    def scrape(self, today: str, dates: list[str] | None = None) -> ScrapeResult: ...

    @abc.abstractmethod
    def fetch_film_detail(self, film_url: str) -> Optional[dict]: ...
```

#### Vincoli impliciti del contratto

- `cinema_name`/`cinema_slug` sono **property astratte**, non campi dataclass. Ogni implementazione le legge dalle costanti di `scraper/config.py` (es. `UCI_CINEMA_NAME`, `THE_SPACE_CINEMA_SLUG`). Mai hard-codate nei connector.
- `scrape(today, dates)` riceve la data "ufficiale di oggi" (`today_local().isoformat()`) e la lista di 8 date ISO della finestra. Deve ritornare `ScrapeResult` in tutti i casi, anche se la chiamata HTTP è fallita: in quel caso `films=[]` ed `errors=[CinemaError(...)]`.
- `dates=None` deve essere tollerato: in quel caso il connector opera come se `dates=[today]`. Implementato in tutti e 3 i connector (es. thespace.py:71, uci.py:70, postmodernissimo.py — quest'ultimo ha `dates` più vincolato per via del parser RSC).
- `fetch_film_detail(film_url)` ritorna opzionalmente un dict con campi arricchiti (es. `description`). Usato dal main flow solo da PostModernissimo quando manca `movie.content`. Ritorna `{}` o `None` se non implementato / non disponibile (UCI ritorna `{}` letteralmente, uci.py:226-227).

#### Perché ABC e non Protocol/dataclass

Scelte di typing:
- `abc.ABC` + `@abstractmethod` → istanziare un connector senza i 4 metodi lancia `TypeError` all'istanziazione, non al primo scrape. Errore più vicino al bug.
- 三 metodi implementati concretamente in un mock per test: ciò che `tests/test_postmodernissimo.py` e `tests/test_uci.py` fanno con `responses` library.

#### Cross-reference

Importato da: `connectors/postmodernissimo.py`, `connectors/thespace.py`, `connectors/uci.py`.

### 5.5 `scraper/connectors/uci.py` — backend Cloud Run

**Path:** `scraper/connectors/uci.py` · **227 righe** · Più semplice dei 3 connector. Singola fonte canonica = API pubblica Google Cloud Run che bypassa Cloudflare.

#### Perché funziona senza autenticazione

Da `UCI_API_RESEARCH.md` §§1-2: **tutto il sito `ucicinemas.it` (Nuxt.js SPA) è dietro Cloudflare** (HTTP 403 ovunque, anche con `User-Agent` mobile). Ma **il backend Cloud Run `myuci---uci-backend-production-nfluwp7wga-oc.a.run.app` NON è protetto**: ritorna 200 senza auth. La chiamata che usiamo è:

```
GET https://myuci---uci-backend-production-nfluwp7wpga-oc.a.run.app/api/theatres/uci-cinemas-perugia/programming/{date}
(templates: UCI_PROGRAMMING_URL, config.py:45)
```

`User-Agent` impostato a Chrome 126 (uci.py:80) per evitare di essere identificati come noti bot Python senza essere troppo dettagliati (423 caratteri).

#### Costanti e helper

- Importa da `scraper.config`: `REQUEST_RETRY`, `REQUEST_TIMEOUT`, `RETRY_BACKOFF`, `UCI_BASE_URL`, `UCI_CINEMA_NAME`, `UCI_CINEMA_SLUG`, `UCI_PROGRAMMING_URL`.
- `_retry_request(method, url, session, **kwargs)` (uci.py:27-53): tentativi `REQUEST_RETRY=3`, backoff `RETRY_BACKOFF**attempt = 2,4 secondi`. **403 non ritenta — è blocco permanente**.
- `_strip_html(text)` (uci.py:56-57): `re.sub(r"<[^>]+>", "", html.unescape(text)).strip()`. Usato su `description`.

#### `UCIConnector.scrape()` — flusso (linee 69-130)

1. `target_dates = dates or [today]` → 8 date.
2. Per ogni `target_date`:
   - costruisce `url = UCI_PROGRAMMING_URL.format(date=target_date)`.
   - `_retry_request("get", url, session)` → JSON.
   - `data = resp.json()`, `api_movies = data.get("data", [])`.
   - Per ogni `movie_data`: scarta se `not_today is True`. Aggiunge il Film a `seen_titles` (dict per merge intra-day delle performances sulla stessa data).
   - Su exception durante il parsing di un singolo movie, log warning + aggiunge `CinemaError(phase="parse_programming_movie")`.
3. Eccezione a livello di request HTTP per una data → `CinemaError(phase="scrape", url=url)`. Il loop prosegue con la prossima data.
4. Ritorna `ScrapeResult(films, errors)`.

#### `_parse_programming_movie(data, today)` (uci.py:132-172)

Costruisce un Film:
- `title = data.get("title") or ""`. Vero `None` → skip.
- `slug = data.get("slug") or ""` → `detail_url = f"{UCI_BASE_URL}/film/{slug}/"` (o homepage UCI se vuoto).
- `poster = data.get("poster") or data.get("top_image") or ""`. Se non inizia con `http` → `""`. Final → `None` se vuoto (da models.py).
- `genres`: parsing tollerante:
  - se dict: `name = g.get("name")`, append.
  - se str: append.
- `description = _strip_html(data.get("description") or "")`. Se vuoto → `None`.
- `showings = self._build_showings_from_screens(data.get("screens", []), today, detail_url)`. Se lista vuota → return `None`.
- **`duration=None`, `director=None`** (uci.py:169-170). Sono le righe che rendono UCI "metadati-povero". Qui non c'è fallback a Wikidata — verrà in step 6 del main flow.

#### `_build_showings_from_screens(screens, today, detail_url)` (uci.py:174-224) — **FIX 1 FIX 8 frainteso**

Punto cruciale: l'API ritorna TUTTE le performances per il film nel catalogo (anche di altre date non richieste!). Il connector filtra per `perf_day == today` (uci.py:202-204):

```python
for perf in performances:
    if not isinstance(perf, dict): continue
    perf_day = perf.get("day", "")
    if perf_day and perf_day != today: continue   # ← FIX spettri
    start = perf.get("actual_start_at") or ""
    if start: times.append(start)
times.sort()
```

Conseguenza: nessun times "16:00 fantasma" di un'altra data. Vedi `tests/test_fix_validation.py:test_fix_uci_filters_performances_by_day` (37-74) per la spec del fix.

Per ogni `screen_group`, itera `screen_group.items()` (formato `{ "2D": [variants] }`), per ogni variant estrae `language`, `screen_name`, performances. Crea un `Showing` con `date=today`, `times=times ordinati`, `screen=screen_name`, `source_url=detail_url`, `language=language`, `session_attributes=[fmt]` se `fmt != screen_name`.

#### `fetch_film_detail()` (uci.py:226-227)

Ritorna `{}` letteralmente. UCI non ha flusso dettaglio: tutto è già nel response del programming.

#### Output tipico per un film UCI

Verificato in `output/cache/uci-perugia.json` (16 film): un singolo Film possiede **più Showing** (1 per sala/lingua/giorno × 8 giorni). Es. "Toy Story 5" UCI ha 2 Showing al 2026-06-18 (Sala 3D e Sala 2D con 15 orari). Dopo `_consolidate_showings` in models.py vengono uniti per `(cinema_slug,date,screen,lang,attrs)`.

#### Cross-reference

Importato da: `main.py` (linea 14 della `import` list).
Importa: `scraper.config`, `scraper.models`, `scraper.connectors.base`.

### 5.6 `scraper/connectors/thespace.py` — OAuth + microservice API + CloakBrowser fallback

**Path:** `scraper/connectors/thespace.py` · **353 righe** · Più lungo di UCI perché ha due modalità operative: API (primaria) e CloakBrowser (fallback). Include l'OAuth2 `client_credentials`.

#### Costanti e helper

- Importa da `scraper.config`: `REQUEST_RETRY`, `REQUEST_TIMEOUT`, `RETRY_BACKOFF`, `THE_SPACE_*` (12-25).
- `_retry_request(method, url, session, **kwargs)` (linee 32-58): identico a quello di UCI, con tag `THESPACE` nei log. 403 non ritenta.

#### `TheSpaceConnector.scrape()` — flusso top-level (linee 70-91)

```python
def scrape(self, today, dates=None):
    target_dates = dates or [today]
    try:
        return self._scrape_via_api(today, target_dates)
    except Exception as exc:
        # fallback CloakBrowser
        try:
            return self._scrape_via_browser(today)
        except Exception as browser_exc:
            return ScrapeResult(errors=[CinemaError(
                phase="scrape_fallback",
                url=THE_SPACE_CINEMA_URL,
                detail=f"API failed: {exc}; Browser failed: {browser_exc}",
            )])
```

Due caratteristiche:
- L'API auth ha effetto "tutto o niente": se la POST `/auth/token` fallisce, salta TUTTA la window, NON solo la data corrente. Per questo l'eccezione sale dal blocco `for target_date in dates`, e `_scrape_via_api` viene ri-rinnovato.
- Il fallback CloakBrowser (`_scrape_via_browser`) lavora per **singolo `today`** (non `dates`): naviga la pagina `THE_SPACE_CINEMA_URL` e aspetta il selettore `.showing-listing`, poi parsa le card con BeautifulSoup.

#### 5.6.1 Flusso OAuth (vedi verbatim)

**Endpoint:** `https://www.thespacecinema.it/api/microservice/auth/token` (THE_SPACE_AUTH_URL, config.py:33)
**Method:** `POST` con body JSON vuoto `{}` (thespace.py:106):
```python
auth_resp = _retry_request("post", THE_SPACE_AUTH_URL, session, json={})
```

**Headers della sessione** (thespace.py:97-103):
```
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36
Accept: application/json
Referer: https://www.thespacecinema.it/cinema/corciano/al-cinema
```

**Note sul body:** Non serve `Authorization: Basic ...`, né form-encoded. Sembra che il backend accetti `json={}` e gestisca auth tramite cookie/sessione + IP, oppure usi una policy "trusted referrer". Inducato da `referer` impostato sul dominio del cinema Corciano. Il connector NON scrive loggetto auth_response: dopo `auth_resp.status_code` viene subito usato il session shared per le request successive, che porteranno il token via cookie di sessione lato server.

**Caching del token:** Non esplicito nel codice. Ogni `scrape()` riottiene il token via POST. Se la POST fallisce con rate-limit, il fallback `_scrape_via_browser` viene attivato.

**Auth response handling:** Status code loggato (`logger.info("The Space auth status: %s", auth_resp.status_code)`), ma il body non viene letto. Il session conserva il cookie `Set-Cookie` se il server lo fornisce, e le GET successive lo usano.

#### Per-day calls (linee 105-141)

Per ogni `target_date`:
```python
films_url = f"{THE_SPACE_FILMS_URL}?showingDate={target_date}&includesSession=true&includeSessionAttributes=true"
resp = _retry_request("get", films_url, session)
data = resp.json()
api_films = data.get("result") or data.get("films") or []
```

Parametri chiave:
- `showingDate=YYYY-MM-DD` — filtro server-side per data.
- `includesSession=true` — include gli showings (altrimenti solo film metadata).
- `includeSessionAttributes=true` — arricchisce con attributi sessione (lingua, formato).

L'API può tornare `{"result": [...]}` o `{"films": [...]}` o perfino un dict `{films: ...}` o `{items: ...}` — il connector prova in ordine (linee 117-118).

#### `_parse_api_film(data, today)` (linee 149-191)

Parsing di un item dall'API:
- `title = data.get("filmTitle") or data.get("title") or ""`. Se vuoto → skip.
- `detail_url = data.get("filmUrl") or ""`. Se path relativo (`/film/xxx`), prependo `THE_SPACE_BASE_URL`. Se completamente vuoto, fallback su `{BASE}/film/{slug}` o `filmId`.
- `poster = data.get("posterImageSrc") or data.get("panelImageUrl")`. Path relativi → `urljoin(THE_SPACE_BASE_URL, ...)`.
- `description = data.get("synopsisShort") or data.get("synopsis")`.
- `running_time = data.get("runningTime")`. `duration = f"{running_time} min"` **solo se `running_time` esiste E `isDurationUnknown` non è true**.
- `genres`: lista di dict/stringhe. Parsing tollerante (linee 170-174).
- `director = (data.get("director") or "").strip() or None`. Il `.strip()` è il **FIX 7**: alcuni record dell'API tornavano `" Travis Knight"` con spazio iniziale.

#### `_parse_api_showing_groups(film_data, today, detail_url)` (linee 193-266) — **FIX 4**

Ogni `showingGroup` ha `date` (ISO8601 con `Z`) e `sessions` (array).
- Parsing date (linee 201-208): `datetime.fromisoformat(...)` con `Z` swap manuale a `+00:00`. Se fallisce, log warning e `continue` (NON fallback su `today` — questo è **FIX 4**, che ha rimosso il `date_str = today` precedente che aveva creato orari fantasma su date sbagliate).
- Per ogni session: `startTime` o `showTime` parsato, poi `time.strftime("%H:%M")`. Se `startTime` manca o `re.match(r"\d{1,2}:\d{2}", t[:5])` non matcha → skip.
- `attributes`: lista di dict. Estrae `name` e `attributeType`. Se `attributeType == "Language"` → imposta `language = name` (con priority "prima che vince" se più record Language).
- Crea un `Showing` per session con `language`, `attrs`, `screen=session.get("screenName")`.

**Caso speciale:** film con `hasSessions=True` ma array vuoto → crea Showing "placeholder" con `times=[]` (linee 255-264). Questo permette al film di esistere in memoria ma NON in output (verrà filtrato da delta ultima riga: `any(s.times for s in f.present_in)`, delta.py:150).

#### `_scrape_via_browser(today)` — fallback CloakBrowser (linee 268-320)

Usato solo se l'API è giù. Flusso:
```python
html = fetch_page_html(THE_SPACE_CINEMA_URL, wait_for=".showing-listing")
soup = BeautifulSoup(html, "lxml")
```
`fetch_page_html` (browser.py:69-83): apre browser singleton via `cloakbrowser.launch(headless=CLOAKBROWSER_HEADLESS, humanize=True, args=["--fingerprint=42069", "--disable-gpu", "--disable-software-rasterizer"])`. Aspetta il selettore `wait_for`. 1 secondo di sleep. Poi `page.content()`.

Parsing (linee 276-316): selettori multipli `.showing-listing__list > li, .film-card, [data-test*='film']`. Per ogni card estrae:
- `title`: `h2, h3, .film-title, [data-test*='title']`.
- `detail_url`: `a[href*='/film/']`.
- `poster`: `img` con `src`.
- `times`: `[data-test*='time'], .session-time, .showtime` con regex `\d{1,2}:\d{2}`.

**Restituisce solo Showing per `today`** (non l'intera finestra 8-giorni) — degradazione nota del fallback.

#### `fetch_film_detail(film_url)` (linee 322-354)

Per il dettaglio di un singolo film (non usato dal main flow diretto, ma disponibile per fetch on-demand):
- Session con UA Chrome.
- `_retry_request("get", film_url, session)` → BeautifulSoup.
- Estrae descrizione da `[data-test*='synopsis'], .synopsis, .film-description`.
- Se fallisce, fallback CloakBrowser sulla stessa pagina.

#### Output tipico

In `output/cache/the-space-corciano.json`: 16 film, con struttura `present_in` ricca (es. Toy Story 5 ha 51 Showing — uno per (sala, lingua, giorno)). Ogni Film ha già `director`, `duration`, `genres` valorizzati dal connector stesso. Dopo `_consolidate_showings`, le 51 diventano un numero più piccolo in `movies.json` (le `times` fuse per stessa `(sala, lingua, giorno)`).

#### Cross-reference

Importato da: `main.py` (linea 13).
Importa: `scraper.config`, `scraper.models`, `scraper.connectors.base`, lazy `scraper.browser`.

### 5.7 `scraper/connectors/postmodernissimo.py` — RSC Next.js + HTML fallback + reconciliation

**Path:** `scraper/connectors/postmodernissimo.py` · **528 righe** · Il connector più complesso e più fragile: parsa una pagina Next.js 13+ che trasmette i dati in **React Server Components** invece che in una vera API. Include inoltre (FIX 9) il riconciliatore homepage-vs-dettaglio che rende la pagina di dettaglio del film la "fonte canonica" sugli orari.

#### Costanti e helper

- Import da `scraper.config`: `POSTMOD_*`, `REQUEST_RETRY`, `REQUEST_TIMEOUT`, `RETRY_BACKOFF` (linee 14-22).
- `_decode_html_entities(text)` (29-32): doppio escape — prima `re.sub(r'\\u([0-9a-fA-F]{4})', lambda m: chr(int(m.group(1), 16)), text)` (decodifica JSON Unicode-escape), poi `html.unescape(text)`. Necessario perché i titoli RSC possono contenere sia `\u0026` sia `&#8217;`.
- `_normalize(label)` (35-44): se l'URL è un proxy Next.js `/_next/image?url=...`, estrae l'`url` reale. Esattamente come `_clean_poster` in models.py, ma con default "non far nulla" (passthrough).
- `_retry_get(url, session, **kwargs)` (47-82): identico a quello UCI/TheSpace per semantica, ma **solo GET** (PostMod fa una sola HTML request, non per-day). 403 non ritenta.

#### `PostModernissimoConnector.scrape()` — flusso (linee 94-209)

1. Crea `self._homepage_session` con UA Chrome + `Accept-Language: it-IT,it;q=0.9` (97-103). Riusato poi da `_fetch_detail_shows` per fare le GET di dettaglio senza riaprire connessioni (FIX 9).
2. `_retry_get(POSTMOD_CINEMA_URL, self._homepage_session)` → HTML della homepage (106-107).
3. `target_dates = set(dates) if dates else {today}`, convertito in interi senza dash: `target_date_ints = {d.replace("-", "")}` (109-110) — PostMod usa date in formato compatto `20260618`.
4. `_parse_rsc_payload(page_html)` (112) → lista di film dict arricchiti.
5. `_parse_film_cards(BeautifulSoup(page_html, "lxml"))` (113) → "card" minime da HTML `<ul.movie-container>`, usata come fallback.
6. Se RSC vuoto ma HTML popolato: `_fallback_from_html(html_cards, today)` e ritorna (115-117, log warning "POSTMOD RSC parsing returned 0 movies").
7. Altrimenti per ogni film RSC:
   - Skip se `self._is_event_stub(movie)`.
   - Filtra `week_shows = [s for s in movie.get("shows", []) if s.get("date", "") in target_date_ints and s.get("orario") and s.get("opzioni") != "noprog"]` (130-136). `opzioni == "noprog"` = slot non in programmazione = scarta.
   - Skip se `week_shows` vuoto.
   - Raggruppa per `d[:4]-d[4:6]-d[6:8]` (ISO date). Per ogni data, `times = sorted(date_groups[iso_date])`, deduplica su `(date, orario)`.
   - Crea `Showing` per data (con `source_url=movie["permalink"]`).
   - Estrae `details.genere`, `details.regia`, `details.durata`, `details.youtube_cover.url` come poster.
   - Se `description` mancante E `permalink` esiste: `self.fetch_film_detail(permalink)` per `description`.
   - `director_raw = details.get("regia")`. Pulisce: `director_raw.strip().strip("()").strip() or None` (linee 178-180). Questo pulisce casi come `" (John Doe) "` → `"John Doe"`. Test `tests/test_postmodernissimo.py:test_postmodernissimo_director_cleaned` (124-151) verifica.
   - Costruisce `Film(title=titolo_decode, ...)` con `title_normalized=title.lower().strip()`.
8. **FIX 9 — reconciliation pass** (206-207): dopo aver popolato `films`, per ogni Film PostMod chiama `self._reconcile_with_detail(film)`. La homepage a volte mostra più date del dettaglio canonico (caso storico "Palestina Anima Mundi": 4 show homepage, 1 solo in dettaglio). Questo pass fa una GET extra per-film sulla pagina di dettaglio, parsa lo stesso payload RSC e, se gli show del dettaglio differiscono da quelli della homepage, **sostituisce `present_in`** con gli show del dettaglio. Se il dettaglio non è raggiungibile (404/timeout), fallback immediato agli show homepage (no regressione). Dettaglio nei metodi nuovi sotto.

#### `_parse_rsc_payload(page_html)` — il cuore fragile (linee 211-264)

**Step 1.** Regex sui blocchi RSC: `pattern = r'self\.__next_f\.push\(\[1,"(.*?)"\])'` (212). Estrae TUTTI i `__next_f.push(...)`. Nei siti Next.js 13+ reali, possono esserci decine di push — alcuni sono piccoli, uno è "il più grande" e contiene i dati di pagina.

**Step 2.** `biggest = max(matches, key=len)` (217). Seleziona il payload più lungo.

**Step 3.** Unescape: `biggest.replace('\\"', '"').replace("\\\\", "\\")` (218).

**Step 4.** Regex sui "movie record": `r'\{"id":(\d+),"title":"([^"]+)","slug":"([^"]+)","permalink":"([^"]+)"'` (220-222). Itera con `re.finditer`. Per ogni match:
- Skip se `"/eventi/" in permalink` (linee 228-229) — concerti/eventi con permalink `/eventi/`. Il filtro principale.
- `shows = self._extract_shows(unescaped, m.start())` (231) — array dagli show.
- `details = self._extract_details(unescaped, m.start())` (232) — oggetto dettagli film.

**Step 5 — FIX 1 (il fix critico).** Accumula per permalink (224-258):
```python
candidates_by_permalink: dict[str, dict] = {}
for m in movie_re.finditer(unescaped):
    ...
    existing = candidates_by_permalink.get(permalink)
    if existing is None:
        # prima occorrenza: crea entry
        ...
    else:
        # occurrence successiva dello stesso permalink
        existing_shows = existing.setdefault("shows", [])
        existing_keys = {(s.get("date"), s.get("orario")) for s in existing_shows}
        for s in shows:
            key = (s.get("date"), s.get("orario"))
            if key not in existing_keys:
                existing_shows.append(s)
                existing_keys.add(key)
        if details and not existing.get("details"):
            existing["details"] = details
        if m.start() > existing.get("_stream_pos", 0):
            existing["_stream_pos"] = m.start()   # aggiornato FIX 9: tiene l'ultima occorrenza
```

Cosa faceva il BUG originale (PlanAudit FIX 1): `if len(shows) > len(existing["shows"]): candidates_by_permalink[permalink] = {...nuovo...}`. Perdeva show di occorrenze secondarie di film duplicati nel payload RSC.

Cosa fa il FIX 1: **accumula TUTTI gli show di TUTTE le occorrenze**, deduplicati su `(date, orario)`.

**Step 6 (260-264):** `return [{k:v for k,v in m.items() if k != "_stream_pos"} for m in candidates_by_permalink.values() if m["shows"]]`. Filtra film senza show (impossibile, ma defensive). Rimuove `_stream_pos` interno.

#### `_is_event_stub(movie)` (linee 277-282)

Skip eventi:
- Se `"/eventi/" in permalink.lower()` → True (ALREADY filtered, double-check).
- Se title contiene una di: `"presentano"`, `"ospiti"`, `"rassegna"`, `"ospite"`, `"dal vivo"`, `"live"`, `"in concerto"`, `"concerto"` → True.

Liste verbatim, definite `_EVENT_HINTS = (...)` (linee 266-275).

#### `_extract_details(text, start)` (linee 284-304)

Cerca `"details":{` entro 3000 caratteri dallo start del match del film. Trova la `{` di apertura, poi bilanciamento di profondità fino al `}` di chiusura (entro 5000 char di safety). `json.loads(...)` sullo slice. Su `JSONDecodeError` → `{}`.

#### `_extract_shows(text, start)` (linee 306-326)

Idem ma per `["shows":[`. Bilanciamento `[]` entro 20000 char di safety.

#### `fetch_film_detail(film_url)` (linee 328-353)

Chiamato da `scrape` solo se `description` del RSC è vuota. Due fallback:
1. `meta[name="description"]` → primissimo tentativo.
2. Primo paragrafo significativo `article p, .film-content p, .description p`.

Ritorna `{"description": "..."}` o `None` se nessuno dei due. Anche questo metodo può essere invocato esternamente dal main flow (campo `fetch_film_detail` esposto dal connector base).

#### `_fetch_detail_shows(permalink)` — FIX 9 (linee 355-380)

Nuovo metodo introdotto da FIX 9. Per un permalink di un singolo film, fa una GET extra sulla pagina di dettaglio, riusando la sessione cache homepage (`self._homepage_session` popolata in `scrape()`), parsa il payload RSC con lo stesso `_parse_rsc_payload`, identifica il record del film cercando per `permalink == permalink` oppure `slug == target_slug (= permalink ultimo segmento)`, e ritorna la lista di `shows` con `orario`. Ritorna `[]` se:
- il permalink non inizia con `http` (safety)
- il permalink è `/eventi/` (evento, niente show)
- la pagina dettaglio non è raggiungibile (eccezione rete, 404, ecc.)
- il payload RSC non contiene il film richiesto.

#### `_extract_poster_url(details)` (linee 460-466)

Estrae poster dall'oggetto details se esiste `youtube_cover = {"url": "..."}`.

#### `_parse_film_cards(soup)` (linee 468-505)

Parser HTML fallback (usato solo se RSC torna 0 film). Selettori:
- `ul.movie-container > li.movie-item`
- `a[href*='/films/']` per detail URL (FONDAMENTALE: solo `/films/` path, NON `/eventi/`)
- `img` per poster (via `_normalize`)
- `h2` per titolo
- `p` per director (parsing grezzo, ma poi non viene ripulito come il RSC).

Restituisce dict minimi: `slug, poster_url, title, director, detail_url`. Deduplica su slug intra-pagina.

#### `_fallback_from_html(html_cards, today)` (linee 507-528)

Crea un `ScrapeResult` con Film "vuoti" (no showings, solo director/poster) dai card HTML. Serve solo come "abbiamo trovato qualcosa" — non ha dettaglio orari.

#### `_reconcile_with_detail(film)` — FIX 9 (linee 382-458)

Per ogni Film PostMod estratto dalla homepage:

1. Se `film.present_in` vuoto, no-op.
2. Estrae `permalink` dal primo `present_in[0].source_url`. Se vuoto, no-op.
3. Chiama `self._fetch_detail_shows(permalink)` per ottenere gli show del dettaglio.
4. Se dettaglio vuoto/non raggiungibile → no-op (tieni show homepage, no regressione).
5. Calcola `target_date_ints` dalle date in `film.present_in` (formato compatto `YYYYMMDD`).
6. Per ogni show del dettaglio: se `date in target_date_ints` AND `opzioni != "noprog"` AND `orario` valorizzato → raggruppa per ISO date, deduplica su `orario`.
7. Se `date_groups` vuoto → no-op (dettaglio non ha show nella finestra).
8. Calcola `homepage_sig = {(s.date, tuple(s.times)) for s in film.present_in}` e `detail_sig = {(iso, tuple(sorted(times)))}`.
9. Se uguali → no-op (homepage e dettaglio concordano).
10. Altrimenti ricostruisce i `Showing` con i `date_groups` del dettaglio e fa `film.present_in = new_showings`. Log INFO `"POSTMOD reconciliation: {titolo} homepage!=detail, using detail ({n} show)"`.

**Comportamento chiave:** vince sempre il **dettaglio** se è raggiungibile e ha show. La homepage è solo fallback per casi di dettaglio non disponibile.

**Validazione:** `tests/test_postmod_detail_reconcile.py::test_postmod_reconciles_homepage_with_detail_when_disagree` (replica del bug "Palestina Anima Mundi"): homepage=4 show, dettaglio=1 show → film finale ha solo l'1 del dettaglio. `tests/test_postmod_detail_reconcile.py::test_postmod_keeps_homepage_shows_when_detail_unreachable`: dettaglio 500 → tieni gli show homepage (no regressione).

**Costo:** una GET extra per ogni Film PostMod (~5 film, ~200ms per GET → ~1s per run completo).

#### Perché questo connector è il più fragile

Il payload RSC è un dettaglio interno di Next.js: il sito può cambiarlo in qualsiasi release senza preavviso (anche un `: "${...}"` template literal). Il fallback HTML esiste per robustezza, ma perde `shows` (orari). In `AuditReport.md` §2, la validazione 9/9 con Vision ha richiesto **13 chiamate Vision** perché alcune discrepanze iniziali erano artefatti di Vision, non del connector.

#### Cross-reference

Importato da: `main.py` (linea 12).
Importa: `scraper.config`, `scraper.models`, `scraper.connectors.base`.

### 5.8 `scraper/metadata.py` — Wikidata Search API + cache + circuit breaker

**Path:** `scraper/metadata.py` · **230 righe** · Unico scopo: arricchire i `Film` con metadati mancanti presi da Wikidata. NON sovrascrive mai i valori già presenti (guard = FIX 6).

#### Import e dipendenze

- `requests`, `json`, `time`, `pathlib.Path`, `typing.Optional`, `urllib.parse.quote` (1-9). `quote` importato ma mai usato.
- `scraper.config`: `WIKIDATA_CACHE`, `WIKIDATA_ENDPOINT`, `WIKIDATA_TIMEOUT`, `WIKIDATA_USER_AGENT` (12-17).
- `scraper.models.Film`, `scraper.normalizer.normalize_title`.

#### State globale (linee 23-28)

```python
_cache: dict[str, dict] = {}
_last_query_time: float = 0.0
_MIN_QUERY_INTERVAL = 5.0
_consecutive_failures: int = 0
_MAX_CONSECUTIVE_FAILURES = 3
_rate_limited_until: float = 0.0
```

Significato di ciascuno:
- `_cache`: cache in-memory dei lookup Wikidata, con chiave = `normalize_title(title).lower()`. Persistente su `.wikidata_cache.json`.
- `_last_query_time` + `_MIN_QUERY_INTERVAL=5.0`: throttling minimo di 5s tra due query consecutive (rispetta i rate-limit non-ufficiali di Wikidata).
- `_consecutive_failures` + `_MAX_CONSECUTIVE_FAILURES=3`: dopo 3 fallimenti consecutivi, skippa TUTTE le query per quel run. Si resetta a 0 su un success (`metadata.py:87`).
- `_rate_limited_until`: timestamp epoch fino al quale attendere se il server ha risposto 429 con `Retry-After`.

#### Costanti citate verbatim

- `WIKIDATA_USER_AGENT = "CinemaScarper/1.0 (https://github.com/cinemascarper; contact@cinemascarper.it)"` (config.py:65) — User-Agent obbligatorio per non essere bloccati.
- `WIKIDATA_TIMEOUT = 15` (config.py:66).

#### Funzioni private

| Riga | Firma | Note |
|------|-------|------|
| 31 | `_load_cache()` | Lazy-load `.wikidata_cache.json` in `_cache`. Se file mancante o eccezione → `{}`. Idempotente (cached). |
| 44 | `_save_cache()` | Persist `_cache` su `.wikidata_cache.json` con `json.dump(ensure_ascii=False, indent=2)`. Try/except. |
| 52 | `_sparql_query(query) -> Optional[list[dict]]` | Esegue una query SPARQL verso `WIKIDATA_ENDPOINT` (config.py:64, URL SPARQL Wikidata). Implementa completamente throttling, 429, raise_for_status. **NON È MAI INVOCATA IN PRODUZIONE**: rimane nel file per future implementazioni, ma `enrich_film` usa solo la Search API. Vincolo del `AGENTS.md`: "Do NOT add complex Wikidata SPARQL queries — timeout on CONTAINS". |
| 96 | `_search_wikidata(title) -> Optional[dict]` | Cache-first. Chiave `normalize_title(title).lower()`. Se miss → `_search_fuzzy(title)`, salva in cache su hit. Sleep 2s su hit, 1s su miss (per non bruciare rate-limit). |
| 114 | `_search_fuzzy(title) -> Optional[dict]` | GET `https://www.wikidata.org/w/api.php?action=wbsearchentities&search={title}&language=it&limit=5&type=item&format=json`. Filtra descrizioni che contengono `"film"` o `"movie"`. Per ciascun match → `_fetch_entity_details(entity_id)`. |
| 143 | `_fetch_entity_details(entity_id) -> Optional[dict]` | GET `https://www.wikidata.org/wiki/Special:EntityData/{entity_id}.json`. Estrae claim: |

**Claims estratte da Wikidata (FIX 2 incluso):**

- **P18** (immagine): `claims["P18"][0]["mainsnak"]["datavalue"]["value"]` → URL Wikimedia. Il connector restituisce `f"https://commons.wikimedia.org/wiki/Special:FilePath/{pic}"` (linea 159).
- **P57** (regista): `claims["P57"]` è una lista di claim. Per ogni claim, `value.get("id")` è il **Q-id del regista** (es. `Q25258`). Senza FIX 2 il connector restituiva `"Q25258"`. Con FIX 2 (linee 161-175): fa una lookup ricorsiva `_fetch_entity_details(director_id)` per ottenere il nome reale, poi usa quel nome.

```python
if "P57" in claims:
    for claim in claims["P57"]:
        val = claim.get("mainsnak", {}).get("datavalue", {}).get("value", {})
        if isinstance(val, dict):
            director_id = val.get("id", "")
            if director_id:
                try:
                    director_details = _fetch_entity_details(director_id)
                    if director_details and "title" in director_details:
                        result["director"] = director_details["title"]
                except Exception: pass
            break
```

`break` dopo il primo: usa il PRIMO regista (non composito). Casi multi-regista (es. "Andrew Stanton, McKenna Harris" su TheSpace / Toy Story 5) NON passano da Wikidata — sono solo dal connector TheSpace.

- **P2047** (durata in minuti): da `claims["P2047"][0]["mainsnak"]["datavalue"]["value"]`. Convertito a `int(float(val))` e formato `f"{int(float(val))} min"` (linee 176-182). Su ValueError/TypeError → skip.

- **labels** (prima `it`, poi `en` come fallback): `result["title"] = langs[lang].get("value", "")`.
- **descriptions** (stesso fallback): `result["description"] = desc_langs[lang].get("value", "")`.

#### `enrich_film(film) -> None` — la funzione principale (linee 204-230)

Tre fasi:
1. **Guard FIX 6** (linee 207-209):
   ```python
   if all(getattr(film, attr, None) for attr in ("poster", "description", "director", "duration", "genres")):
       return
   ```
   Se TUTTI i 5 campi arricchibili sono già valorizzati (truthy), early return. Questo è il cuore del "non sovrascrivo":
   - Singolo campo mancante → Wikidata parte.
   - Più campi mancanti → Wikidata parte una volta sola per film (la lookup è one-shot, poi si applica il dict result ai campi mancanti).
   - Tutti presenti → skip completamente.

2. **Lookup Wikidata** (linee 211-215):
   ```python
   wiki_data = _search_wikidata(film.title)
   if not wiki_data:
       wiki_data = _search_wikidata(film.title_normalized)
   if not wiki_data:
       return
   ```
   Doppio tentativo: prima il titolo originale, poi il normalizzato. Se entrambi falliscono → no-op.

3. **Applicazione selettiva** (linee 217-230):
   ```python
   if not film.poster      and "poster"      in wiki_data: film.poster = wiki_data["poster"]
   if not film.description and "description" in wiki_data: film.description = wiki_data["description"]
   if not film.genres      and "genres"      in wiki_data: film.genres = wiki_data["genres"]
   if not film.director    and "director"    in wiki_data: film.director = wiki_data["director"]
   if not film.duration    and "duration"    in wiki_data: film.duration = wiki_data["duration"]
   ```
   Ogni campo viene applicato SOLO se il Film non lo ha già valorizzato. È la garanzia "connector-first, Wikidata-repair", che ha sostituito un vecchio comportamento che sovrascriveva tutto.

#### Schema della cache `.wikidata_cache.json`

Esempio reale (estratto dal file su disco post audit):

```json
{
  "amarga navidad": {
    "poster": "http://commons.wikimedia.org/wiki/Special:FilePath/Pedro%20Almodóvar%20for%20Autofiction%20at%20the%202026%20Cannes%20Film%20Festival.jpg 02.jpg",
    "description": "film del 2026 diretto da Pedro Almodóvar",
    "genres": ["commedia drammatica", "film commedia", "film drammatico"],
    "director": "Pedro Almodóvar",
    "duration": "111 min"
  },
  "disclosure day": {...},
  "don chisciotte": {...}
}
```

Chiavi = `normalize_title(title).lower()`. Valori = subset di `{poster, description, genres, director, duration, title}`.

**Curiosità osservata**: la voce `don chisciotte` cache ha `"director": "Georg Wilhelm Pabst"` e `"duration": "73 min"` — è la scheda di un film del 1957 di Don Chisciotte, NON del Don Chisciotte di Segatori del 2026 in programmazione. Il fuzzy su Wikidata ha confuso due film omonimi. Il connector PostMod fornisce già director ("Fabio Segatori") e duration ("112") correttamente per il film vero, quindi la guard FIX 6 impedisce la sovrascrittura — l'output ha i valori corretti del connector.

#### Comportamento atteso con/senza cache

- **Primo run** (cache vuota): ogni film che ha connector-source-povero riceve UNA query SPARQL→Search. Per 23 film e `_MIN_QUERY_INTERVAL=5s` → ~2 minuti extra solo per Wikidata. Con _MAX_FAILURES=3 circuit breaker attivo, se Wikidata va in 429, lo scraper smette di interrogare.
- **Run successivi** (cache calda): `enrich_film` ritorna quasi sempre dalla cache. Velocissimo.

#### Cross-reference

Importato da: `main.py` (linea 17).
Importa: `scraper.config`, `scraper.models`, `scraper.normalizer`.

### 5.9 `scraper/delta.py` — merge cross-run + snapshot history

**Path:** `scraper/delta.py` · **199 righe** · La logica che fa passare da "snapshot puntuale" a "storia".

#### Import e dipendenze

- `copy`, `json`, `logging`, `datetime.{date,datetime,timedelta}`, `pathlib.Path`, `typing.Optional`. Di questi: `copy`, `date`, `timedelta`, `Path` sono importati ma NON usati (residuo storico).
- `scraper.config`: `HISTORY_DIR`, `MOVIES_JSON`, `REMOVAL_THRESHOLD_DAYS`.

#### Costanti citate verbatim

- `REMOVAL_THRESHOLD_DAYS = 7` (config.py:62). **Soglia entro la quale un film non visto viene marcato `rimosso`. Dopo 7 giorni senza riapparire = ufficialmente fuori programmazione.** `*2` (=14) è la soglia di purge dalla history stessa.

#### Funzioni pubbliche

| Riga | Firma | Note |
|------|-------|------|
| 17 | `load_previous_movies() -> list[dict]` | Se `MOVIES_JSON` esiste, carica e ritorna `data["films"]`. Altrimenti `[]`. Try/except warning. |
| 29 | `save_snapshot(today)` | No-op se `MOVIES_JSON` non esiste. Altrimenti `shutil.copy2(MOVIES_JSON, HISTORY_DIR/f"movies_{today}.json")`. (Vedi sezione 8 per la retention.) Lazy import `shutil` dentro la funzione. |
| 42 | `merge_films(new_films, previous_data, today) -> list[Film]` | **Algoritmo centrale**, vedi sotto. |

#### `merge_films()` — algoritmo dettagliato (righe 42-151)

**Fase 0 — Costruzione `prev_map` (43-47):** indicizza i film del run precedente per `title_key(title_normalized or title)`. O(1) lookup.

**Fase 1 — Loop sui `new_films` (52-91):** per ogni film del run corrente:
- `key = title_key(film.title_normalized)`, aggiunto a `seen_keys` (set).
- Se esiste in `prev_map`:
  - `_showings_changed(old, new)` confronta liste di `showing_key`. Se True → `film.history = existing_history + [{"date": today, "action": "updated"}]`. Altrimenti history invariata.
  - Se `film.status != "rimosso"` → forzato a `"in_programmazione"` (non può tornare indietro da rimosso durante un run attivo).
  - Eredita `poster/description` se assenti. (FIX implicito: evita di perdere dati dopo una mancata enrich.)
- Altrimenti (film nuovo): `film.history = [{"date": today, "action": "added"}]`, `status = "in_programmazione"`.
- Append a `merged`.

**Fase 2 — Loop sui `prev_map` non più visti (93-145):** per ogni film che era nel precedente ma NON in `seen_keys`:
- Calcola `days_since_removal` (dalla history: ultima data con `action="removed"`).
- Calcola `days_since` (dalla data più recente in `present_in`).
- Se `prev_status == "rimosso"` (già):
  - Se `days_since_removal > REMOVAL_THRESHOLD_DAYS * 2` (=14) → purge (skip, log "Purging old removed film"). Il film sparisce completamente.
  - Altrimenti → ri-aggiunge come `rimosso` nella merged.
- Altrimenti (non era rimosso prima):
  - Se `days_since > REMOVAL_THRESHOLD_DAYS` (=7) → marca `rimosso`, `film.history += [{"action":"removed", "date": today}]`, append.
  - Altrimenti (<7 giorni) → resta `in_programmazione` con `present_in=[]` (vuoto). Aggiunge `"removed"` in history SOLO se non già presente.

**Fase 3 — Filtro finale — FIX 5 (147-151):** `return [f for f in merged if f.status != "rimosso" and any(s.times for s in f.present_in)]`.

**FIX 5 esplicito:** `any(...)` mantiene un film che ha ALMENO UN giorno con orari. Vecchia logica `all(...)` escludeva film anche se solo 1 giorno su 8 era vuoto. Ora se un cinema ha aggiunto 3 giorni su 8 e un altro cinema ha gli altri 5, il film sopravvive. Verifica in `tests/test_delta.py`.

#### Schema `history[]`

Ogni elemento: `{"date": "YYYY-MM-DD", "action": "added"|"updated"|"removed"}`. Ordine cronologico ascendente.

Esempio reale tratto da `output/movies.json`:
```json
"history": [
  {"date": "2026-06-18", "action": "added"}
]
```

Un film rimosso e poi ri-aggiunto avrebbe:
```json
"history": [
  {"date": "2026-06-10", "action": "added"},
  {"date": "2026-06-19", "action": "removed"},
  {"date": "2026-06-25", "action": "added"}
]
```

#### Helper privati

| Riga | Firma | Note |
|------|-------|------|
| 154 | `_showings_changed(old, new) -> bool` | Confronta liste di `showing_key`. Chiave: `f"{cinema_slug}:{date}:{','.join(times)}"`. Sort + differenza. |
| 163 | `_last_removal_date(history) -> Optional[str]` | Itera history reversed, ritorna la `date` del primo `action="removed"`. |
| 170 | `_dict_to_film(data) -> Film` | Reconstruct Film da dict movies.json-shaped. Crea `Showing` per ogni `present_in` entry. Gestisce campi null. |

#### Cosa succede se l'algoritmo bugga

Caso reale visto: se `merge_films` dovesse per qualsiasi ragione ritornare un Film con `present_in=[]` e `status="in_programmazione"`, la fase 3 lo mantiene in output ma **senza orari visibili** (frontend vedrebbe un film "in programmazione" senza poter cliccarlo per orari). Casi di bug osservati e risolti sono i FIX 1-8.

#### Cross-reference

Importato da: `main.py` (linea 15).
Importa: `scraper.config`, `scraper.models`, `scraper.normalizer`.

### 5.10 `scraper/main.py` — entry point CLI e orchestrazione

**Path:** `scraper/main.py` · **268 righe** · Il file più importante dopo i connector. È il punto in cui si vede l'intero flusso in 200 righe di logica lineare.

#### Import e dipendenze

- `__future__.annotations` (1) — abilita type hints lazy.
- Stdlib: `json`, `logging`, `os`, `sys`, `time`, `datetime.datetime`, argparse (lazy).
- `scraper.config`: `CACHE_DIR, CITY, LOG_FORMAT, LOG_LEVEL, MOVIES_JSON, SCHEDULE_INTERVAL_HOURS, get_week_dates, today_local`.
- `scraper.models`: `CinemaError, Film, ScrapeResult, Showing, film_to_dict, output_to_json`.
- I 3 connector: `PostModernissimoConnector`, `TheSpaceConnector`, `UCIConnector`.
- `scraper.delta`: `load_previous_movies, merge_films, save_snapshot`.
- `scraper.errors.write_errors`.
- `scraper.metadata.enrich_film`.
- `scraper.normalizer.fuzzy_match, title_key`.
- Lazy: `scraper.browser.close_browser` (dentro try/except in run_scraper).

#### Costanti citate verbatim

Nessuna costante locale. Tutto importato.

`logger = logging.getLogger("cinema_scraper")` (20). Nome del logger root usato da `setup_logging` e da tutti i log in `run_scraper`.

#### Funzioni

| Riga | Firma | Note |
|------|-------|------|
| 23 | `_save_cache(cinema_slug, films)` | Scrive `CACHE_DIR/{slug}.json` con `film_to_dict(f)` per ogni Film. Try/except wrapper (warnings). |
| 34 | `_load_cache(cinema_slug) -> list[Film] \| None` | Carica cache, ricostruisce `Showing` + `Film`. Se file mancante → `None`. Su eccezione → `None` + warning. |
| 76 | `setup_logging()` | `basicConfig` con due handler: `StreamHandler(sys.stdout)` + `FileHandler("scraper.log", encoding="utf-8")`. Livello da `LOG_LEVEL`. |
| 87 | `run_scraper()` | Orchestratore completo. Vedi sezione 4 per il flow. |
| 209 | `_deduplicate_films(films) -> list[Film]` | Dedup con `fuzzy_match` (FIX 3: `seen: dict[str, Film] = {}`). |
| 238 | `schedule()` | APScheduler `BlockingScheduler`, `interval/hours=24`, `next_run_time=datetime.now()`. Ctrl+C → log + esce pulito. |
| 256-268 | blocco `__main__` | argparse con `--once` / `--schedule`. Default `--once`. |

#### `_save_cache` (23-31) — pattern di scrittura

```python
def _save_cache(cinema_slug: str, films: list[Film]) -> None:
    try:
        cache_file = CACHE_DIR / f"{cinema_slug}.json"
        data = [film_to_dict(f) for f in films]
        with open(cache_file, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        logger.info("  Cache saved for %s (%d films)", cinema_slug, len(films))
    except Exception as exc:
        logger.warning("  Failed to save cache for %s: %s", cinema_slug, exc)
```

**NON** è atomic write (no `.tmp` + `os.replace`). Differenza: la cache è RAW pre-dedup, viene riscritta ogni run. Se il processo muore durante write, il file può essere corrotto, ma `_load_cache` ritorna `None` su eccezione → fallback catena di caching precedente.

#### `_load_cache` (34-73) — ricostruzione del Film da dict

```python
films = []
for d in data:
    showings_data = d.pop("present_in", [])
    showings = [
        Showing(...campi da d...) for s in showings_data
    ]
    films.append(Film(
        title=d.get("title", ""),
        title_normalized=d.get("title_normalized", ""),
        present_in=showings,
        ...
        source_poster=d.get("poster"),   # ← usato come fallback in step 9
    ))
```

Nota su `source_poster`: popolato dal dict `poster` del cache. Questo perché il connector salva il `poster` originale come `source_poster`, ma `film_to_dict` non lo serializza (campo interno del Film, vedi models.py:34). Quindi al reload `source_poster = d.get("poster")` ricostruisce quel fallback.

#### `_deduplicate_films` (209-235) — dedup fuzzy

Body completo (verbatim):

```python
def _deduplicate_films(films: list[Film]) -> list[Film]:
    seen: dict[str, Film] = {}
    result: list[Film] = []

    for film in films:
        key = title_key(film.title_normalized)
        found = False
        for i, existing in enumerate(result):
            if fuzzy_match(existing.title_normalized, film.title_normalized):
                existing.present_in.extend(film.present_in)
                if not existing.poster and film.poster: existing.poster = film.poster
                if not existing.description and film.description: existing.description = film.description
                if not existing.genres and film.genres: existing.genres = film.genres
                if not existing.director and film.director: existing.director = film.director
                if not existing.duration and film.duration: existing.duration = film.duration
                found = True; break
        if not found: result.append(film)
    return result
```

**FIX 3** = `seen: dict[str, Film] = {}` (210). Era bug-originale `= []` (lista vuota, ma il codice usa `seen` come dict `key → Film` e lo fa girare su `result` linearmente). Il `seen` importato resta unused; la deduplicazione vera è la scansione lineare su `result` con `fuzzy_match`.

Comportamento:
- Primo Film di un titolo mai visto → appendi a `result`.
- Film successivo con titolo fuzzy-match → estendi `present_in`, copia i campi arricchibili mancanti (pattern "first non-empty wins"), `break`.

**Nessun overlapping di campi dopo dedup**: il primo Film che arriva (nell'ordine di esecuzione dei connector) "fissa" `poster/description/genres/director/duration`. Definito in `tests/test_fix_validation.py:test_fix_dedup_unescapes_html_before_match` (286-305).

#### `schedule()` (238-253)

```python
def schedule() -> None:
    from apscheduler.schedulers.blocking import BlockingScheduler
    scheduler = BlockingScheduler()
    scheduler.add_job(run_scraper, "interval",
                      hours=SCHEDULE_INTERVAL_HOURS,
                      id="daily_scrape",
                      next_run_time=datetime.now())
    logger.info("Scheduler started: runs every %d hours", SCHEDULE_INTERVAL_HOURS)
    try: scheduler.start()
    except (KeyboardInterrupt, SystemExit): logger.info("Scheduler stopped")
```

Loop infinito bloccante (`BlockingScheduler.start()`). Esegue `run_scraper` immediatamente (`next_run_time=datetime.now()`) e poi ogni 24h. Ctrl+C pulito.

In systemd (`cinemascarper.service`), l'execstart è esattamente `python3 -m scraper.main --schedule`. Il servizio rimane in foreground e il restart automatico di systemd gestisce i crash.

#### Blocco CLI `__main__` (256-268)

```python
if __name__ == "__main__":
    setup_logging()
    import argparse
    parser = argparse.ArgumentParser(...)
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--schedule", action="store_true")
    args = parser.parse_args()
    if args.once or not args.schedule: run_scraper()
    else: schedule()
```

`--schedule` deve essere esplicito. Default: `--once`.

#### Cross-reference

È il fan-in assoluto: importa tutti i moduli del package. Importato da: nessuno (è entry point).

---

## 6. Gotchas & decisioni non ovvie

Questa sezione raccoglie tutti i bug-fix storici (FIX 1-8 da `PlanAudit.md` e `AuditReport.md`) e altri comportamenti del codice che sembrano strani a prima vista ma sono intenzionali. Ogni FIX è descritto con: **sintomo**, **root cause**, **fix**, **validazione** (dove applicabile).

L'elenco è canonico: `AuditReport.md` §3 e `PlanAudit.md` §§FIX 1-8 sono la fonte unica. Niente inventato qui dentro.

### 6.1 FIX 1 — PostModernissimo merge RSC mostra

**File:** `scraper/connectors/postmodernissimo.py:220-254` (`_parse_rsc_payload`).

**Sintomo:** PostMod `_parse_rsc_payload` riteneva un numero minore di film rispetto ai siti live. `AuditReport.md` §1: PostMod aveva 7 film pre-fix, **9 post-fix** (+Palestina Anima Mundi, +Diaz).

**Root cause:** nel payload RSC, lo stesso film può apparire **più volte** (occorrenze multiple dello stesso `permalink`), spesso con `shows` arrays parziali/sparsi. Il vecchio codice sceglieva l'occorrenza con la lista `shows` più lunga, scartando le altre e perdendo showtime.

**Fix:** accumulare le `shows` di TUTTE le occorrenze dello stesso `permalink`, deduplicando per `(date, orario)`:

```python
existing_shows = existing.setdefault("shows", [])
existing_keys = {(s.get("date"), s.get("orario")) for s in existing_shows}
for s in shows:
    key = (s.get("date"), s.get("orario"))
    if key not in existing_keys:
        existing_shows.append(s)
        existing_keys.add(key)
```

Verbatim da postmodernissimo.py:244-250. Il pattern museale del fix è testato in `tests/test_fix_validation.py:test_fix_postmod_duplicati_stream_order` (194-221).

**Validazione:** Doppio check in `AuditReport.md` §4: Film PostMod da 7 → 9, *Diaz* con 8 giorni su 8, *Disclosure Day* orari match con sito.

**Come NON romperlo:** chi tocca `_parse_rsc_payload` deve ricordarsi che il payload RSC può essere MOLTO lungo e che più film con stesso permalink sono la norma, non l'eccezione. Aggiungere nuovi campi al dict film è ok (`_stream_pos` viene filtrato esplicitamente alla fine, postmodernissimo.py:256-259).

### 6.2 FIX 2 — Director Wikidata come Q-id invece di nome

**File:** `scraper/metadata.py:161-175` (`_fetch_entity_details`, claim `P57`).

**Sintomo:** dopo un audit, diversi film avevano `director = "Q25258"` (o altri Q-id) invece del nome del regista. Visibile in `movies.json` per qualsiasi film il cui director arrivava da Wikidata.

**Root cause:** quando la claim `P57` di un film puntava al regista, il vecchio codice salvava il Q-id del regista (es. `"Q25258"`) invece di risolvere il nome testuale.

**Fix:** lookup ricorsivo. Dopo aver trovato `director_id` da `claims["P57"]`, si chiama `_fetch_entity_details(director_id)` per ottenere un dict che ha `title` (label) e quindi `director_details["title"]`:

```python
if "P57" in claims:
    for claim in claims["P57"]:
        val = claim.get("mainsnak", {}).get("datavalue", {}).get("value", {})
        if isinstance(val, dict):
            director_id = val.get("id", "")
            if director_id:
                try:
                    director_details = _fetch_entity_details(director_id)
                    if director_details and "title" in director_details:
                        result["director"] = director_details["title"]
                except Exception: pass
            break
```

Verbatim da metadata.py:161-175. L'eccezione `except Exception` è intenzionale: la lookup ricorsiva può fallire per rate-limit, non vogliamo che blocchi l'enrichimento del Film principale.

**Validazione:** `AuditReport.md` §1: "Nessun director nel formato `Q#####`". `AuditReport.md` §4: "Nessun director sporco".

**Come NON romperlo:** la chain di lookup è delicata — se `_fetch_entity_details` viene cambiata per richiedere parametri diversi, anche la chiamata ricorsiva deve essere aggiornata. NON wrappare la lookup ricorsiva in un circuit breaker separato che azzeri i counter (sennò un fail isolato sul regista fa abortire TUTTE le altre enrich). Il `except Exception: pass` è la protezione corretta.

### 6.3 FIX 3 — `seen` come `[]` invece di `{}` in main.py

**File:** `scraper/main.py:210` (riga di `_deduplicate_films`).

**Sintomo:** type inconsistency latente nel codice di dedup.

**Root cause:** dichiarazione `seen: dict[str, Film] = []` — annotazione `dict` ma inizializzazione lista. Nella versione corrente (post-fix), `seen` non è effettivamente usato per il tracking del dedup (la dedup lineare scorre `result` linearmente con `fuzzy_match`), ma l'incoerenza era visibile e criptica.

**Fix:** riga attuale:
```python
def _deduplicate_films(films: list[Film]) -> list[Film]:
    seen: dict[str, Film] = {}
    result: list[Film] = []
```

La lista `[]` sostituita da `{}` per coerenza con l'annotazione. `seen` resta unused nel body, ma la type consistency è mantenuta.

**Validazione:** test `tests/test_delta.py` copre la logica di dedup. Il fix è di purezza del codice, non un fix di bug comportamentale.

### 6.4 FIX 4 — TheSpace fallback date errato (orari fantasma)

**File:** `scraper/connectors/thespace.py:201-207` (`_parse_api_showing_groups`).

**Sintomo:** SCARY MOVIE per la data 2026-06-16 aveva `16:10` che era in realtà del 2026-06-17. Stesso pattern per altri film dove l'API ritornava `showingGroups` con date multiple.

**Root cause:** vecchio codice:
```python
except Exception:
    date_str = today            # ← fallback sbagliato
```
Se il parsing della data del group falliva, veniva usato `today` come fallback. Un `showingGroup` con `group_date` malformato veniva associato a `today` anche se il vero orario era di un altro giorno.

**Fix:** rimosso il fallback. Su parse failure ora `continue` + `logger.warning(...)`:

```python
group_date = group.get("date", "")
try:
    from datetime import datetime as dt
    parsed_date = dt.fromisoformat(str(group_date).replace("Z", "+00:00"))
    date_str = parsed_date.strftime("%Y-%m-%d")
except Exception:
    logger.warning("TheSpace failed to parse date %s, skipping group", group_date)
    continue
```

Verbatim da thespace.py:201-207. Resultato: il group viene scartato invece di essere misclassificato.

**Validazione:** test `tests/test_fix_validation.py:test_fix_thespace_filters_showing_groups_by_date` (248-281) verifica con un dataset che il 16:10 del 17/06 NON leakka sul 16/06 dopo il fix.

**Come NON romperlo:** se l'API modifica il formato data, il try/except deve continuare a `continue` loggando. NON reintrodurre un fallback di default.

*(Continua nella prossima tranche: 6.5 FIX 5 — delta exclude film; 6.6 FIX 6 — Metadata guard troppo aggressiva; 6.7 FIX 7 — Director con spazi; 6.8 FIX 8 — TZ rollover Italy; 6.9 Extra.)*

### 6.5 FIX 5 — Delta exclude film (any, non all)

**File:** `scraper/delta.py:147-151` (filtro finale in `merge_films`).

**Sintomo:** un film che per 7 giorni su 8 aveva orari e per 1 giorno no veniva escluso dall'output finale.

**Root cause:** il filtro usava `all` invece di `any` — `all(s.times for s in f.present_in)` richiede che TUTTI i showing abbiano almeno un orario. Un solo showing con `times=[]` (normale per i film in giorni in cui non sono in programmazione) buttava fuori l'intero film.

**Fix:** `any(...)` mantiene film che hanno ALMENO un giorno con orari:

```python
return [
    f
    for f in merged
    if f.status != "rimosso" and any(s.times for s in f.present_in)
]
```

Verbatim da delta.py:147-151.

**Validazione:** `AuditReport.md` §3: "FIX 5: codice già corretto (usa `any` che mantiene film con ≥1 giorno valido) — non modificato". Non è stato necessario toccare il codice, ma è stato esplicitamente verificato.

**Come NON romperlo:** cambiare `any` in `all` (anche "per pulizia") reintroduce il bug. Verificare la logica guardando l'output `movies.json`: deve includere film che hanno showing misti pieni/vuoti.

### 6.6 FIX 6 — Metadata guard troppo aggressiva

**File:** `scraper/metadata.py:208` (prima riga di `enrich_film`).

**Sintomo:** dopo che un Film aveva `poster` e `description` valorizzati dal connector, l'enrich Wikidata non partiva più, lasciando `director`/`duration`/`genres` vuoti anche quando Wikidata li aveva.

**Root cause:** vecchia guard:
```python
if film.poster and film.description:
    return
```

Restrizione solo su 2 campi. Tutti gli altri (director, duration, genres) non venivano più cercati.

**Fix:** guard su TUTTI i 5 campi arricchibili:

```python
if all(getattr(film, attr, None) for attr in ("poster", "description", "director", "duration", "genres")):
    return
```

Verbatim da metadata.py:208. Risultato: se ALMENO UNO dei 5 è mancante, Wikidata viene interrogato. La lookup è one-shot per Film (la cache `_search_wikidata` viene chiamata una volta sola e il result dict viene applicato ai campi mancanti).

**Validazione:** `AuditReport.md` §3 + §4: "Conferma stabilità". Combinato con FIX 2 (director come nome, non Q-id), i director vengono ora risolti correttamente.

**Come NON romperlo:** se aggiungi un nuovo campo arricchibile (es. `cast`), deve essere aggiunto alla tupla. AGENTS.md è chiaro: "Do NOT re-add the lookup logic that overwrites scraper values with Wikidata. The guard in `metadata.py:enrich_film` only enriches fields that are missing in the Film".

### 6.7 FIX 7 — Director con spazi iniziali

**File:** `scraper/connectors/thespace.py:176`.

**Sintomo:** alcuni record del connector TheSpace avevano `director = " Travis Knight"` (spazio iniziale) o peggio, con spazi interni anomali.

**Root cause:** il campo `director` dall'API ritornava occasionalmente stringhe con whitespace ai bordi. Il connector salvava direttamente senza strip.

**Fix:** riga attuale in `_parse_api_film`:

```python
director = (data.get("director") or "").strip() or None
```

Il `.strip()` rimuove ai bordi. Il costrutto `... or None` garantisce che stringa vuota dopo strip diventi `None` (non stringa vuota).

**Validazione:** `AuditReport.md` §1: "Nessun director nel formato `Q#####` né con spazi iniziali. ✅"

**Come NON romperlo:** altri connector con campi stringa potenzialmente sporchi devono essere passati allo stesso pattern `(data.get("x") or "").strip() or None`. Vedi PostModernissimo già fixato (`director_raw = details.get("regia") or None; director_raw.strip().strip("()").strip() or None` in postmodernissimo.py:176-178). Per UCI: la sua API non ritorna director, quindi non applicabile.

### 6.8 FIX 8 — Timezone rollover Italy

**File:** `scraper/config.py:20` + 77-83, `scraper/main.py:88`.

**Sintomo (bug report 2026-06-18 01:32 locali):** lo scraper runnato poco dopo la mezzanotte italiana (es. 01:32) segnalava `today = 2026-06-17` invece di `2026-06-18`. La finestra 8-giorni rimaneva ancorata al giorno precedente.

**Root cause:** `main.py:88` usava `date.today().isoformat()`. Su server Ubuntu (TZ=UTC di default), `date.today()` ritorna la data UTC. Tra le 00:00 e le 01:00/02:00 italiane (UTC+1/UTC+2), per 1 o 2 ore la data del sistema "resta" al giorno precedente.

**Fix:**
- `config.py:20`: `SCRAPER_TZ = ZoneInfo(os.environ.get("SCRAPER_TZ", "Europe/Rome"))`.
- `config.py:77-83`: nuova funzione `today_local() -> date` che fa `datetime.now(SCRAPER_TZ).date()`.
- `main.py:88`: `today = today_local().isoformat()` (sostituzione di `date.today()`).
- `get_week_dates()` (config.py:72-74) ora delega a `today_local()` quando `ref_date=None`.

```python
# config.py
SCRAPER_TZ = ZoneInfo(os.environ.get("SCRAPER_TZ", "Europe/Rome"))

def today_local() -> date:
    """Return today's date in the scraper's local timezone.

    Uses `SCRAPER_TZ` (default `Europe/Rome`) so that the scraper rolls over
    to the new "today" at Italian midnight, regardless of the server timezone.
    """
    return datetime.now(SCRAPER_TZ).date()
```

**Validazione (`AuditReport.md` §"Appendice A — FIX 8"):**
- 2 nuovi test in `tests/test_config.py:test_today_local_rollover_at_italian_midnight` e `test_today_local_returns_object_of_type_date`.
- `test_get_week_dates_no_arg` aggiornato per usare `today_local()` come riferimento.
- 34 test passano (32 originali + 2 nuovi sul TZ rollover). 1 skip residuo.
  Aggiornamento 2026-06-18 (FIX 9): altri 2 test in `tests/test_postmod_detail_reconcile.py`,
  totale **36 passed, 1 skipped**. La soglia "32 originali + 2 TZ" è storica: la baseline attuale è 36 attivi.
- Validazione manuale: `python3 -c "from scraper.config import today_local; print(today_local())"` → `2026-06-18`. `date.today()` rimane `2026-06-17`.
- Dopo `rm -f output/cache/*.json output/movies.json output/history/*.json output/errors.json && python3 -m scraper.main --once` → log mostra `=== Cinema Scraper started (2026-06-18) ===`, Week dates `['2026-06-18', ..., '2026-06-25']`, 23 film.

**Vincoli rispettati:**
- `SCRAPER_TZ` rimane env var configurabile per deployment in altre timezone (`SCRAPER_TZ=Europe/London`).
- Nessuna regressione: tutti i 32 test preesistenti continuano a passare (confermato al 2026-06-18).

**Come NON romperlo:** in qualsiasi punto del codice, **NON** reintroducete `date.today()` o `datetime.now().date()` (Senza TZ esplicita). `today_local()` è l'unica fonte canonica per la data di "oggi" intesa come data italiana. Per test con mock datetime, ricordarsi che `mock.patch("scraper.config.datetime")` deve patchare TUTTO il modulo: `from datetime import datetime` in `config.py` è leading namespace.

### 6.9 Gotchas extra — pattern ricorrenti che sembrano bug ma NON lo sono

Sono pattern osservati in output/cache/history che possono trarre in inganno. Tutti documentati anche in `AGENTS.md` §"Things that look broken but aren't". Qui sono esplicitati e motivati.

#### 6.9.1 UCI: stesso Film 4+ volte nel cache file (normale)

In `output/cache/uci-perugia.json` ci sono 16 record, ma il catalogo UCI live è 20. È normale che un singolo Film UCI (es. "Toy Story 5") abbia più `Showing` (1 per sala, 1 per lingua, 1 per data × 8 giorni = fino a 30 Showing). Il dedup `_deduplicate_films` successivo li fonde in UN SOLO Film con `present_in[]` ricco.

**Test diagnostico:** se vuoi contare i "veri film unici" UCI, conta per `film.title_normalized`, non per entry nel cache.

Vedi `AuditReport.md` §2: "I 4 film 'manc in API' sono correttamente esclusi dallo scraper (tutti hanno `not_today=True` per tutte le 8 date successive)".

#### 6.9.2 PostMod: `/eventi/` ≠ film

Tutti i record con `permalink` contentente `/eventi/` sono **eventi/concerti/rassegne**, non film. Vengono filtrati da due livelli:

1. `_parse_rsc_payload`: `if "/eventi/" in permalink: continue` (postmodernissimo.py:224-225).
2. `_is_event_stub`: ulteriore detection su hint testuali (`presentano`, `ospiti`, `rassegna`, `live`, `concerto`, ecc.) in `_EVENT_HINTS` (postmodernissimo.py:262-271).

**Test diagnostico:** se un evento culturale appare nell'output, è un bug dell'uno o dell'altro filtro. Aprire il payload RSC live e verificare.

Esempio reale filtrato: "Fabio Segatori e il Gruppo Micrologus presentano Don Chisciotte" (PlanAudit.md §FIX 1 background + test_fix_postmod_filters_event_stub_by_title_hint).

#### 6.9.3 UCI: director/duration NON esistono lato API

L'backend Cloud Run UCI (`UCI_API_RESEARCH.md`) ritorna per ogni film un dict con `genres`, `description`, `poster`, `screens`, ma NON `director` né `duration`. La funzione `_parse_programming_movie` (uci.py:169-170) hardcoda:
```python
duration=None,
director=None,
```

L'arricchimento arriva via **Wikidata** (se il Film ha titolo matchabile) o resta `null`. Non è un bug: è la fonte.

Test diagnostico:
```bash
python3 -c "
import json
d = json.load(open('output/movies.json'))
noprom = [f for f in d['films'] if f['present_in'] and 'UCI' in f['present_in'][0]['cinema']]
print('UCI films:', len(noprom))
print('with director:', sum(1 for f in noprom if f['director']))
print('with duration:', sum(1 for f in noprom if f['duration']))
"
```

Output attuale (cache calda): da 4 film UCI, `director` spesso valorizzato da Wikidata, `duration` quasi sempre `null`.

**Vincolo AGENTS.md:** `Do NOT try to extract director/duration from UCI API — they don't exist there.`

#### 6.9.4 Output null vs []

Definito in sezione 3.5 ma ribadito qui come gotcha operativa:

- ❌ NON aggiungere campi "default" tipo `genres: []` (è stato il comportamento pre-fix Fase 4 PLAN.md).
- ✅ Campi stringa mancanti → `null`.
- ✅ `genres` mancante → `null` (vedi models.py:118 `film.genres if film.genres else None`).
- ✅ Liste vuote legittime (es. `session_attributes`) → chiave omessa dall'output via `_consolidate_showings`.

Se il frontend si lamenta di `genres` mancante, NON tentare di defaultare a `[]`. Il frontend deve gestire `null`.

#### 6.9.5 Schema Film — niente campi fantasma

**NON esistono**:
- `rating` (rimosso, era nel README §"Struttura movies.json" storico).
- `price` (campo menzionato nel PRD.md ma mai implementato).
- `rating_tmdb` (PRD.md §3 lo cita, è pre-Wikidata — deprecato).
- `cast` (campi `cast` compaiono solo nei JSON di alcuni connector come `data.get("cast")` ignorato, NON propagato a `Film`).

Se ti serve uno di questi per il frontend, **discutine prima**: aggiungere un campo rompe il contratto col Worker Cloudflare (sezione 11) e col frontend esistente.

### 6.10 Riepilogo visivo dei FIX

Mappa "cosa cambia, dove, perché" in formato tabellare (sintesi delle §§6.1-6.8).

| # | File:riga | Cambia cosa | Bug risolto |
|---|---|---|---|
| FIX 1 | `postmodernissimo.py:220-254` | `_parse_rsc_payload` accumula show | show time persi da occorrenze multiple RSC |
| FIX 2 | `metadata.py:161-175` | lookup ricorsivo director_id | director era Q-id invece del nome |
| FIX 3 | `main.py:210` | `seen = {}` (era `[]`) | type-inconsistency di puro stile |
| FIX 4 | `thespace.py:201-207` | fallback date rimosso | orari fantasma su date sbagliate |
| FIX 5 | `delta.py:147-151` | `any(...)` (era `all(...)`) | film esclusi se 1/8 giorni vuoto |
| FIX 6 | `metadata.py:208` | guard su 5 campi (era 2) | director/duration mancanti quando poster+desc presenti |
| FIX 7 | `thespace.py:176` | `.strip()` su director | director con spazio iniziale |
| FIX 8 | `config.py:20,77-83` + `main.py:88` | `SCRAPER_TZ` + `today_local()` | date sbagliata tra mezzanotte IT e le 1-2 UTC |

Tutti i fix sono stati validati da test automatici (in `tests/test_fix_validation.py` e `tests/test_config.py`) più cross-check manuale (`AuditReport.md`).

### 6.11 Anti-pattern vietati (cristallizzati nelle decisioni di design)

Questi sono pattern che, se reintrodotti, **rompono il comportamento corretto**. Ognuno è il negativo di un FIX.

| ❌ Vietato | Motivo |
|---|---|
| Aggiungere campi al `Film` (rating, price, casting) | rompe contratto col Worker/frontend |
| `date.today()` invece di `today_local()` | reintroduce FIX 8 |
| `all(...)` invece di `any(...)` in `merge_films` filter | reintroduce FIX 5 |
| `if "/eventi/" in permalink: pass` o rimozione del filtro | reintroduce eventi fake |
| `data.get("director")` senza `.strip()` in qualsiasi connector | reintroduce FIX 7 |
| `(P57_value.id)` senza lookup ricorsiva in `metadata.py` | reintroduce FIX 2 |
| `if film.poster and film.description: return` in `metadata.py` | reintroduce FIX 6 |
| `except Exception: date_str = today` in qualsiasi connector | reintroduce FIX 4 |
| Aggiungere TMDB/OMDb come fonte | viola `AGENTS.md` "Project is commercial" |
| Puppeteer/headless per UCI | viola `AGENTS.md` "UCI blocks scraping" |
| Query SPARQL Wikidata con `CONTAINS` | timeout sistematico |
| Hardcoded `datetime.now(SCRAPER_TZ)` invece di `today_local()` | TZ drift |
| Bypass dedup scrivendo diretto in `movies.json` | film duplicati |

---

*Fine sezione 6 (completa: 6.1-6.11). Dimmi se procedo con la sezione 7 (Estendibilità guidata) o se ritocchi prima.*

---

## 7. Estendibilità — esercitazione guidata

Le 4 modifiche più probabili che qualcuno vorrà fare su questo progetto, spiegate passo-passo. Ogni sezione include il file da creare/modificare, il codice da inserire, le dipendenze da considerare, e i test da scrivere. Le sezioni sono cumulabili: se vuoi cambiare la timezone E aggiungere un cinema, fai entrambe le sottosezioni.

### 7.1 Aggiungere un 4° cinema

**Caso d'uso:** CinemaX apre a Perugia e vuoi aggiungerlo ai 3 esistenti.

#### Step 1 — In `scraper/config.py`

Aggiungi un blocco di costanti. Segui lo stile dei 3 esistenti (PostMod, TheSpace, UCI).

```python
CINEMA_X_NAME          = "CinemaX Perugia"
CINEMA_X_SLUG          = "cinema-x-perugia"
CINEMA_X_BASE_URL      = "https://www.cinema-x.it"
CINEMA_X_CINEMA_URL    = f"{CINEMA_X_BASE_URL}/perugia"
CINEMA_X_FILM_DETAIL_URL = f"{CINEMA_X_BASE_URL}/film/{{film_slug}}"
# eventuali URL API se CinemaX espone un endpoint
```

Il `SLUG` deve essere: tutto minuscolo, separato da `-`, univoco tra tutti i connector. Viene usato come nome file in `output/cache/{slug}.json`.

#### Step 2 — Crea `scraper/connectors/cinema_x.py`

```python
from __future__ import annotations
import html
import logging
import re
import time
from datetime import datetime
from typing import Optional

import requests
from bs4 import BeautifulSoup

from scraper.config import (
    CINEMA_X_NAME, CINEMA_X_SLUG, CINEMA_X_CINEMA_URL,
    CINEMA_X_FILM_DETAIL_URL,
    REQUEST_RETRY, REQUEST_TIMEOUT, RETRY_BACKOFF,
)
from scraper.models import CinemaError, Film, ScrapeResult, Showing
from scraper.connectors.base import BaseConnector

logger = logging.getLogger(__name__)


def _retry_request(method, url, session, **kwargs):
    last_exc = None
    for attempt in range(1, REQUEST_RETRY + 1):
        try:
            resp = getattr(session, method)(url, timeout=REQUEST_TIMEOUT, **kwargs)
            if resp.status_code == 403:
                logger.error("CINEMAX 403 Forbidden for %s", url)
                resp.raise_for_status()
            resp.raise_for_status()
            return resp
        except (requests.HTTPError, requests.RequestException) as exc:
            last_exc = exc
            if attempt < REQUEST_RETRY:
                time.sleep(RETRY_BACKOFF ** attempt)
    raise last_exc


class CinemaXConnector(BaseConnector):
    @property
    def cinema_name(self) -> str: return CINEMA_X_NAME

    @property
    def cinema_slug(self) -> str: return CINEMA_X_SLUG

    def scrape(self, today, dates=None) -> ScrapeResult:
        target_dates = dates or [today]
        films = []
        errors = []
        session = requests.Session()
        session.headers.update({"User-Agent": "Mozilla/5.0 (Windows...)"})

        for target_date in target_dates:
            url = f"{CINEMA_X_CINEMA_URL}/programmazione/{target_date}"
            try:
                resp = _retry_request("get", url, session)
                soup = BeautifulSoup(resp.text, "lxml")
                # ... parsing specifico di CinemaX ...
                # costruisci Showing(...) e Film(...) come da contratto
            except Exception as exc:
                errors.append(CinemaError(
                    cinema=self.cinema_name,
                    timestamp=datetime.now().isoformat(),
                    exception=type(exc).__name__,
                    phase="scrape",
                    url=url,
                    detail=str(exc),
                ))
        return ScrapeResult(films=films, errors=errors)

    def fetch_film_detail(self, film_url) -> Optional[dict]:
        return None  # se non hai pagina dettaglio ricca
```

**Punti critici del template:**
- Rispetta il contract di `BaseConnector` (sezione 5.4).
- `_retry_request` come helper locale se la libreria non lo espone.
- `ScrapeResult` ritornato in TUTTI i casi (anche 0 film).
- `fetch_film_detail` ritorna almeno `None` o `{}`.

#### Step 3 — Registra in `scraper/main.py:93-97`

```python
connectors = [
    PostModernissimoConnector(),
    TheSpaceConnector(),
    UCIConnector(),
    CinemaXConnector(),   # ← aggiunto qui
]
```

**Ordine importante:** primo = priorità per la dedup (primo vince sui campi arricchibili, vedi §6.13.5 / main.py dedup). Se vuoi che CinemaX "fornisca il poster canonico", mettilo primo. Altrimenti, ordinalo in base a completezza metadata (UCI è il peggiore perché manca director/duration).

#### Step 4 — Test in `tests/test_cinema_x.py`

Pattern canonico da `tests/test_postmodernissimo.py` o `tests/test_uci.py`:

```python
from responses import RequestsMock
import responses

from scraper.connectors.cinema_x import CinemaXConnector
from scraper.config import CINEMA_X_CINEMA_URL


@responses.activate
def test_cinema_x_basic_scrape():
    responses.add(
        responses.GET,
        f"{CINEMA_X_CINEMA_URL}/programmazione/2026-06-18",
        body="<html>...</html>",
        status=200,
    )
    result = CinemaXConnector().scrape("2026-06-18", dates=["2026-06-18"])
    assert len(result.films) >= 1
    film = result.films[0]
    assert film.title == "..."
```

Aggiungi anche test per:
- Caso errore HTTP 500 → result.films==[] e result.errors non vuoto.
- Caso film con `present_in=[]` (placeholder come in thespace.py:255-264) → capire se viene filtrato da delta ultima riga.

#### Step 5 — Validazione

```bash
python3 -m pytest tests/test_cinema_x.py -v
python3 -m scraper.main --once
cat output/movies.json | jq '.films | map(.present_in | map(.cinema_slug) | flatten | unique)'
```

Atteso: vedi il nuovo slug `cinema-x-perugia` tra i cinema presenti.

### 7.2 Cambiare la finestra (es. 14 giorni)

**Caso d'uso:** vuoi 14 giorni di programmazione invece di 8.

#### Step 1 — `scraper/config.py:72-74`

Rinomina `get_week_dates` → `get_dates(days=N)` con default 8, ma **mantieni `get_week_dates` come wrapper** per i test esistenti:

```python
def get_dates(days: int = 8, ref_date: date | None = None) -> list[str]:
    d = ref_date or today_local()
    return [(d + timedelta(days=i)).isoformat() for i in range(days)]


def get_week_dates(ref_date: date | None = None) -> list[str]:
    """Backwards compat wrapper. Returns 8 days. Prefer get_dates(days=N)."""
    return get_dates(days=8, ref_date=ref_date)
```

**NON** modellare "settimana Mon-Sun": il rollover sui 14 giorni è indipendente dal giorno della settimana. Lascia rolling.

#### Step 2 — Aggiungi env var in `config.py`

```python
SCRAPER_DAYS_WINDOW = int(os.environ.get("SCRAPER_DAYS_WINDOW", "8"))
```

Default 8 (preserva comportamento attuale). Se vuoi 14:

```
SCRAPER_DAYS_WINDOW=14 python3 -m scraper.main --once
```

#### Step 3 — `scraper/main.py:89`

```python
from scraper.config import (
    ...,
    SCRAPER_DAYS_WINDOW, get_dates,
)
...
week_dates = get_dates(days=SCRAPER_DAYS_WINDOW)  # era get_week_dates()
```

#### Step 4 — Test in `tests/test_config.py`

Aggiungi test che asseriscono:
- `get_dates(days=14)` ritorna 14 date.
- `get_dates(days=0)` ritorna `[]`.
- `get_dates(days=8)` ≡ `get_week_dates()` (retrocompat).

#### Step 5 — Impatto collaterale

Da verificare:
- **Cache:** la cache per-cinema è RAW pre-dedup. Con finestra più lunga, ogni cache file `output/cache/{slug}.json` cresce proporzionalmente. Cohere con `REMOVAL_THRESHOLD_DAYS` (config.py:62): se la finestra è 14 giorni e il delta conserva un film per `REMOVAL_THRESHOLD_DAYS=7` giorni, il film scompare dalla history mentre è ancora nella window attuale. Incoerenza.
- **Fix proposto:** `REMOVAL_THRESHOLD_DAYS` dovrebbe essere almeno `days_window + 1`. Aggiorna la sogliatura in `config.py` e nella doc. Esempio: `REMOVAL_THRESHOLD_DAYS = max(7, SCRAPER_DAYS_WINDOW + 1)`.
- **Test miss:** il `tests/test_delta.py:test_merge_missing_film_beyond_threshold` usa soglie assolute (presuppone 7 giorni). Va aggiornato se cambi la soglia. Vedi riga 92: `merged = merge_films([], previous[...], "2026-06-12")` — non usa `today` come data "reale", è solo unit test.

### 7.3 Sostituire Wikidata con un'altra fonte (es. Wikipedia IT)

**Caso d'uso:** Wikidata diventa troppo lento o cambia politiche; vuoi usare Wikipedia IT come fallback (`it.wikipedia.org` API pubblica).

#### Vincoli (verificare PRIMA di iniziare)

- **Progetto commerciale**: AGENTS.md vieta fonti con restrizioni commerciali. Wikipedia IT è OK (CC BY-SA). Wikipedia inglese anche.
- Le API Wikimedia pubbliche hanno rate limit (~200 req/sec globali, ma con throttling ragionevole).
- Lo schema restituito è DIVERSO da Wikidata: serve adapter.

#### Step 1 — `scraper/metadata.py`: introduci un nuovo modulo `wikipedia_it.py`

Path: `scraper/metadata_wikipedia_it.py` (mantieni `metadata.py` come wrapper compatibile o sostituiscilo).

Skeleton:

```python
from __future__ import annotations
import json
import logging
import requests
from typing import Optional
from urllib.parse import quote

from scraper.config import (
    WIKIPEDIA_IT_ENDPOINT,   # aggiungi in config.py
    WIKIPEDIA_IT_USER_AGENT, # stesso UA identity
)
from scraper.models import Film
from scraper.normalizer import normalize_title

logger = logging.getLogger(__name__)


def _search_wikipedia_it(title: str) -> Optional[dict]:
    """Cerca una pagina Wikipedia IT per titolo del film."""
    try:
        resp = requests.get(
            WIKIPEDIA_IT_ENDPOINT,
            params={"action": "query", "list": "search",
                    "srsearch": title, "format": "json", "srlimit": 5},
            headers={"User-Agent": WIKIPEDIA_IT_USER_AGENT},
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
        for hit in data.get("query", {}).get("search", []):
            page_id = hit.get("pageid")
            if page_id:
                return _fetch_page_extract(page_id)
    except Exception as exc:
        logger.warning("Wikipedia IT search failed: %s", exc)
    return None


def _fetch_page_extract(page_id: int) -> Optional[dict]:
    """Dato un pageid, estrai description + director + duration dal summary API."""
    try:
        resp = requests.get(
            f"{WIKIPEDIA_IT_ENDPOINT}",
            params={"action": "query", "pageids": page_id,
                    "prop": "extracts|pageimages", "explaintext": 1,
                    "exintro": 1, "piprop": "thumbnail",
                    "pithumbsize": 300, "format": "json"},
            headers={"User-Agent": WIKIPEDIA_IT_USER_AGENT},
            timeout=15,
        )
        resp.raise_for_status()
        pages = resp.json().get("query", {}).get("pages", {})
        if not pages: return None
        page = next(iter(pages.values()))
        result = {}
        if page.get("extract"):
            # Primi 500 caratteri sono tipicamente sufficienti per la sinossi
            result["description"] = page["extract"][:500]
        # Director/duration: parsing dal wikitext non è banale;
        # Wikipedia API non li espone strutturati. Richiede template scraping.
        # Lascia director/duration a un altro modulo se serve.
        return result if result else None
    except Exception as exc:
        logger.warning("Wikipedia IT page fetch failed: %s", exc)
        return None


def enrich_film_wikpedia(film) -> None:
    """Stessa signature e stessa guard semantic di enrich_film in metadata.py.
    Non sovrascrive mai."""
    if not isinstance(film, Film): return
    if all(getattr(film, attr, None) for attr in
           ("poster", "description", "director", "duration", "genres")):
        return
    result = _search_wikipedia_it(film.title)
    if result:
        for field in ("description", "director", "duration"):
            if not getattr(film, field) and field in result:
                setattr(film, field, result[field])
```

**Punti critici:**
- Stessa **guard** del `metadata.py` originale (FIX 6 pattern: solo campi mancanti).
- `_search_*` + `_fetch_*` mantengono la stessa shape del dict result (`{poster,description,director,duration,genres}` con chiavi mancanti se assenti).
- Throttling: aggiungi `_MIN_QUERY_INTERVAL=2.0` per Wikipedia (meno restrittiva di Wikidata).

#### Step 2 — `scraper/config.py`: aggiungi

```python
WIKIPEDIA_IT_ENDPOINT = "https://it.wikipedia.org/w/api.php"
WIKIPEDIA_IT_USER_AGENT = "CinemaScarper/1.0 (https://github.com/cinemascarper; contact@cinemascarper.it)"
```

#### Step 3 — `scraper/main.py` (step 6 del flow, dopo `_deduplicate_films`)

```python
from scraper.metadata_wikipedia_it import enrich_film_wikpedia

# Dopo enrich_film(film):
enrich_film_wikpedia(film)
```

Oppure fai una catena configurabile:

```python
ENRICH_PIPELINE = [enrich_film, enrich_film_wikpedia]
for fn in ENRICH_PIPELINE:
    try: fn(film)
    except Exception as exc: logger.warning(...)
```

#### Step 4 — Test in `tests/test_metadata_wikipedia_it.py`

Mock le risposte API Wikipedia IT con `responses` (vedi pattern in `tests/test_fix_validation.py`). Test case:
- Film con `description=None`: lo arricchisce.
- Film con `director="X"`: NON sovrascrive.
- Film con tutti i campi pieni: skip totale (early return).

#### Step 5 — Documentare in AGENTS.md e PLAN.md

Aggiungi la nuova fonte nella whitelist "fonti metadati accettabili", motivando perché Wikipedia IT è OK commerciale.

#### Caveat importante

Wikipedia IT API è più lenta di Wikidata per film non popolari, e spesso ritorna solo `description`. Per director/duration reali serve template scraping o IMDb/Wikidata comunque come fallback.

In produzione probabilmente vorrai **entrambi**: Wikidata per le properties strutturate (P57 director, P2047 duration), Wikipedia IT per le description estese. Catena: prima Wikidata → cerca → se fallisce, Wikipedia IT.

### 7.4 Cambiare la timezone di rollover

**Caso d'uso:** il progetto viene deployato in un altro paese (es. Londra) e vuoi che "oggi" segua l'Europa/London, non più Europe/Rome.

#### Soluzione one-liner (no code change)

```bash
SCRAPER_TZ=Europe/London python3 -m scraper.main --once
```

L'env var `SCRAPER_TZ` è già letta in `config.py:20`:
```python
SCRAPER_TZ = ZoneInfo(os.environ.get("SCRAPER_TZ", "Europe/Rome"))
```

Zero modifiche al codice. Per renderlo permanente:

Modifica `deploy/cinemascarper.service` aggiungendo alla sezione `[Service]`:
```
Environment=SCRAPER_TZ=Europe/London
```

Oppure in systemd:
```bash
sudo systemctl edit cinemascarper
# aggiungi:
# [Service]
# Environment=SCRAPER_TZ=Europe/London
```

Poi:
```bash
sudo systemctl restart cinemascarper
```

#### Casi speciali che richiedono fix al codice

**Cambio definitivo del default (es. progetto ora Londra-only):**

`scraper/config.py:20`, cambia il default:
```python
SCRAPER_TZ = ZoneInfo(os.environ.get("SCRAPER_TZ", "Europe/London"))  # ← default nuovo
```

**More than one timezone per finestra**:
Non è supportato nel design attuale. Se serve (es. città a cavallo di due fusi), ridefinisci `today_local()` perché accetti un parametro:
```python
def today_local(tz_name: str | None = None) -> date:
    tz = ZoneInfo(tz_name) if tz_name else SCRAPER_TZ
    return datetime.now(tz).date()
```

E propaga. È un rework di bassa entità.

#### Test

`tests/test_config.py:test_today_local_rollover_at_italian_midnight` (38-46) verifica il pattern del rollover. Se cambi la timezone di test, aggiorna il `tzinfo=ZoneInfo(...)` nella fixture `fake_now`.

```python
def test_today_local_rollover_at_london_midnight():
    fake_now = datetime(2026, 6, 18, 0, 30, 0, tzinfo=ZoneInfo("Europe/London"))
    with mock.patch("scraper.config.datetime") as fake_dt:
        fake_dt.now.return_value = fake_now
        d = today_local()
        assert d == date(2026, 6, 18)
```

#### Impatto operativo

- `get_week_dates()` (config.py:72-74): rolling window su `today_local()`. Cambia automaticamente.
- Tutti i connector ricevono la data ISO `today` come stringa. Se passi il boundary di timezone, potresti vedere un film del "giorno precedente" perché il connector riceve `today=2026-06-17` mentre localmente era già il 18. Questo è **volatile** durante il primo minuto dopo il cambio timezone — è il `today_local()` stesso che è la fonte di verità.
- `audit-check_report.md` (output) usa i timestamp del log, non `today_local()`. Nessun impatto.

### 7.5 Checklist finale per estensioni riuscite

Sequenza di validazione dopo QUALUNQUE modifica di una delle §§7.1-7.4.

#### 1. Static checks

```bash
# Solo import e syntax, no run.
python3 -m py_compile scraper/{config,main,models,normalizer,delta,errors,metadata,browser}.py
python3 -m py_compile scraper/connectors/{base,postmodernissimo,thespace,uci}.py
```

#### 2. Test offline

```bash
python3 -m pytest tests/ -v
```

Atteso: 36+ test passano, 1 skip. Se hai aggiunto un nuovo connector (7.1), aggiungi almeno 2-3 test.

#### 3. Pulizia cache e rerun pulito

```bash
rm -f output/cache/*.json output/movies.json output/errors.json
rm -f output/history/movies_*.json
python3 -m scraper.main --once
```

Atteso: log contiene `=== Cinema Scraper started (YYYY-MM-DD) ===`, Week dates lunghe 8 (o il nuovo `days_window`), Film count > 0, errori = 0.

Se errori > 0: leggi `output/errors.json` per il detail. Tipicamente connector fuori rotazione.

#### 4. Output check

```bash
python3 -c "
import json
d = json.load(open('output/movies.json'))
print('generated_at:', d['generated_at'])
print('films:', len(d['films']))
print('errors:', len(d['errors']))
cinemas = sorted({s.cinema_slug for f in d['films'] for s in f['present_in']})
print('cinemas:', cinemas)
# Verify TZ behavior
print('film_date range:', min(min(s.date for s in f['present_in']) for f in d['films']),
      '→', max(max(s.date for s in f['present_in']) for f in d['films']))
"
```

Atteso:
- `generated_at` recente (data run).
- `films` count tra 20-35 in base ai giorni.
- `cinemas` contiene TUTTI gli slug attesi (es. se hai aggiunto CinemaX, `cinema-x-perugia` deve essere presente).
- `film_date range` corretto rispetto a `today_local()`.

#### 5. Static invariants

Verifica nessun campo "rating" / "rating_tmdb" / "price" in output (vedi §6.9.5):

```bash
python3 -c "
import json
d = json.load(open('output/movies.json'))
forbidden = {'rating', 'rating_tmdb', 'price'}
for f in d['films']:
    bad = forbidden & set(f.keys())
    if bad: print('VIOLATION:', f['title'], bad)
print('OK')
"
```

Atteso: `OK`.

#### 6. Snapshot test

```bash
ls -la output/history/
# deve esserci un movies_{today}.json
diff -q output/history/movies_$(date -d "-0 day" +%Y-%m-%d).json output/movies.json
# atteso: 0 difference (i file sono gemelli)
```

Se differiscono: `save_snapshot` in `delta.py:29-39` ha fallito o `output_to_json` non è idempotente — ma in pratica non capita se il flow è pulito.

#### 7. Final sanity

```bash
# Re-run dopo 1 ora (per stabilità):
python3 -m scraper.main --once
diff <(jq -S '.films | sort_by(.title)' output/movies.json) \
     <(jq -S '.films | sort_by(.title)' output/history/movies_2026-06-18.json)
```

Se ci sono film aggiunti/rimossi tra i due run, è cambiata la programmazione reale dei cinema. Se NULL: i run sono stabili.

---

## 8. Output e artefatti

Tutto ciò che il run lascia su disco. Sono 5 categorie: l'output principale (`movies.json`), la cache per-cinema (`output/cache/`), lo snapshot giornaliero (`output/history/`), l'accumulatore errori (`errors.json`), e i log (`scraper.log` + journalctl). Più il cache persistente per Wikidata (`.wikidata_cache.json`) che non è in `output/` ma è comunque output.

### 8.1 `output/movies.json` — l'output principale

#### Scrittura

Effettuata atomicamente in 2 step (main.py:180-187):
```python
tmp_path = str(MOVIES_JSON) + ".tmp"
with open(tmp_path, "w", encoding="utf-8") as f:
    json.dump(output, f, ensure_ascii=False, indent=2)
os.replace(tmp_path, str(MOVIES_JSON))
```

Il pattern garantisce che chi legge veda o il vecchio file o il nuovo, mai un file a metà. **Critico** perché il file è letto dal Worker Cloudflare (sezione 11) e quindi dal frontend live in produzione.

#### Schema (wrapper esterno)

```json
{
  "generated_at": "2026-06-18T00:18:42.827592",
  "city": "Perugia",
  "films": [ ... ],
  "errors": [ ... ]
}
```

Costruito da `output_to_json()` in `scraper/models.py:127-133` con default `city="Perugia"` (config.py:26).

#### Schema per film

Output di `film_to_dict(film)` (models.py:112-124):

```json
{
  "title": "Palestina Anima Mundi",
  "title_normalized": "palestina anima mundi",
  "poster": "https://...jpg",
  "description": "Palestina Anima Mundi. Francesca Albanese dialogando...",
  "genres": ["Presentazione libro"],
  "status": "in_programmazione",
  "director": "Francesca Albanese",
  "duration": "60 min",
  "present_in": [
    {
      "cinema": "PostModernissimo",
      "cinema_slug": "postmodernissimo",
      "date": "2026-06-18",
      "times": ["18:30"],
      "source_url": "https://www.postmodernissimo.com/films/palestina-anima-mundi"
    }
  ],
  "history": [
    {"date": "2026-06-18", "action": "added"}
  ]
}
```

#### Regole di serializzazione (regole di produzione)

| Campo sorgente (Film) | Output | Motivo |
|---|---|---|
| `title`, `title_normalized` | stringa o `null` | `html.unescape` su non-empty |
| `poster` | URL o `null` | se `_next/image` nel path, estrae `?url=` reale |
| `description` | stringa o `null` | `html.unescape` su non-empty |
| `genres` | array di stringhe o `null` | se Film.genres vuoto → `None` (FIX PLAN §D) |
| `status` | stringa `"in_programmazione"` o `"rimosso"` | delta imposta |
| `director`, `duration` | stringa o `null` | from connector o Wikidata |
| `present_in` | array di oggetti Showing consolidati | vedi regole sotto |
| `history` | array di `{"date","action"}` | delta popola |

#### Regole per `present_in` entries

`_consolidate_showings` (models.py:65-98) raggruppa per chiave `(cinema, cinema_slug, date, language, screen, attrs_sorted)`. Per ogni gruppo:
- `times` viene fuso unendo e deduplicando, poi ordinato.
- `source_url` prende il primo valorizzato.
- `session_attributes` vengono listate una volta per nome (no dup).
- La dict finale rimuove le chiavi con valore `None`/`""`/`[]` (models.py:96).

Effetto: un Film con 51 Showing su UCI Sala 1+Sala 2 × 8 giorni (Toy Story 5 nel cache attuale) viene consolidato in ~2-4 entries (una per (sala, lingua) per data).

Esempio reale dal `movies.json` attuale (Toy Story 5 TheSpace):
```json
{
  "cinema": "The Space Cinema Corciano",
  "cinema_slug": "the-space-corciano",
  "date": "2026-06-18",
  "times": ["16:00", "18:50", "21:30"],
  "screen": "Sala 1",
  "source_url": "https://www.thespacecinema.it/film/toy-story-5",
  "language": "ITALIANO",
  "session_attributes": ["ITALIANO", "2D"]
}
```

`session_attributes` è presente perché ha `[ITALIANO, 2D]`. Se fosse vuoto verrebbe omesso.
### 8.2 `output/cache/{slug}.json` — RAW per-cinema pre-dedup

Tre file, uno per cinema (uguale al `cinema_slug` del connector).

| File | Contenuto | Aggiornato da |
|---|---|---|
| `output/cache/postmodernissimo.json` | 5-9 Film PostMod RAW | `_save_cache("postmodernissimo", result.films)` quando PostMod ha success |
| `output/cache/the-space-corciano.json` | 16 Film TheSpace RAW (oggi) | idem TheSpace |
| `output/cache/uci-perugia.json` | 16 Film UCI RAW | idem UCI |

#### Schema (stesso di un Film ma in JSON)

Stesso shape di `film_to_dict(Film)`. Esempio reale (PostMod "Palestina Anima Mundi"):

```json
{
  "title": "Palestina Anima Mundi",
  "title_normalized": "palestina anima mundi",
  "poster": null,
  "description": "Palestina Anima Mundi. Francesca Albanese ...",
  "genres": ["Presentazione libro"],
  "status": "in_programmazione",
  "director": "Francesca Albanese",
  "duration": "60 min",
  "present_in": [
    {"cinema": "PostModernissimo", "cinema_slug": "postmodernissimo",
     "date": "2026-06-18", "times": ["18:30"], ...},
    ...
  ],
  "history": []
}
```

#### Quando viene scritto e letto

**Scrittura** (main.py:113-114):
```python
result: ScrapeResult = connector.scrape(today, dates=week_dates)
if result.films:
    _save_cache(connector.cinema_slug, result.films)
```
Solo se `result.films` non vuoto. Se il connector ritorna 0 film (perché tutti i film sono stati filtrati o perché non c'è programmazione), la cache NON viene toccata.

**Lettura come fallback** (main.py:117-135): se il connector solleva eccezione, `_load_cache(connector.cinema_slug)` viene chiamata come fallback. Se il file esiste, viene usato. È read-tolerant: `None` su eccezione di parsing.

#### Cosa contiene di "vero" l'output rispetto al cache

La cache ha **più Film** del `movies.json` finale se la dedup ne ha fusi alcuni. Esempio (post-audit Film-fix 1): un Film PostMod può apparire MULTIPLY nel cache (più record per più occorrenze del payload RSC), ma un solo Film nel `movies.json` dopo dedup. La cache è un RAW asset, non un output pulito.

#### Retention

**Nessuna policy automatica.** Il cache cresce monotonicamente se il connector inizia a ritornare più Film. In pratica:
- PostMod post-fix1: ~9 film × ~30 righe JSON circa ~5 KB.
- TheSpace: 16 film × ~50 righe = ~80 KB.
- UCI: 16 film × ~30 righe = ~50 KB.

Totale cache: ~150 KB. Triviale.

Se uno vuole pulire manualmente: `rm -f output/cache/*.json`. Il prossimo run le riscrive.

#### Quando NON fidarsi del cache come fallback

- Il cache è RAW del connector, non post-dedup. Se un film è stato rinominato lato connector e tuoi `movies.json` esistenti hanno il vecchio titolo, dopo un Fallimento di scrape userai titolo vecchio nel merge, generando doppia entry.
- Soluzione: in caso di alert su fallback cache, guardare `scraper.log` per quale connector è fallback.

### 8.3 `output/history/movies_{date}.json` — snapshot giornaliero

Una copia completa di `movies.json` per ogni giorno di run. Salva tutto: anche se un film viene rimosso dall'output corrente (`status="rimosso"`), resta storicamente presente al giorno in cui era in programmazione.

#### Quando viene scritto

Dopo l'atomic write di `movies.json`, in `main.py:189`:
```python
save_snapshot(today)
```

Cioè a fine di ogni step del flow (dopo errori o successi). Vedi sezione 4.2 step 12.

#### Implementazione

`scraper/delta.py:29-39`:
```python
def save_snapshot(today: str) -> None:
    if not MOVIES_JSON.exists():
        return
    try:
        snapshot_path = HISTORY_DIR / f"movies_{today}.json"
        import shutil
        shutil.copy2(MOVIES_JSON, snapshot_path)
        logger.info("Saved snapshot: %s", snapshot_path)
    except Exception as exc:
        logger.warning("Failed to save snapshot: %s", exc)
```

- No-op se `output/movies.json` non esiste (impossibile al momento della chiamata, perché arriva dopo l'atomic write).
- Usa `shutil.copy2` per preservare i metadata (timestamp di modifica, permessi).
- Lazy import `shutil` (evita overhead al module-load se non usato).

#### Schema del filename

`movies_{YYYY-MM-DD}.json` dove `{YYYY-MM-DD}` è `today_local().isoformat()`. Esempio concreto presente su disco al momento della stesura di questo documento: `movies_2026-06-18.json` (138403 byte, byte-identico al `movies.json` attuale).

#### Retention (NESSUNA)

**Non c'è alcuna rotazione automatica.** Il directory cresce monotonamente: 1 file/giorno = 365 file/anno = ~50 MB/anno (a 138 KB/snapshot a crescita zero).

A lungo termine serve una rotazione manuale. Pattern consigliati:

```bash
# Mantieni solo gli ultimi 90 giorni
find output/history -name "movies_*.json" -mtime +90 -delete

# Oppure comprimi i più vecchi di 30 giorni
find output/history -name "movies_*.json" -mtime +30 -exec gzip {} \;
```

Cron-friendly. Aggiungi come systemd timer se vuoi.

#### A cosa serve in pratica

- **Diagnosi post-mortem**: "perché ieri vedevo il film X e oggi no?" → apri lo snapshot di ieri.
- **Audit trail**: il Worker Cloudflare può opzionalmente servire snapshot storici se il frontend li richiede.
- **Replay del delta**: se vuoi testare come `merge_films` si comporta con `previous_data` simulati, hai dati reali a disposizione.

#### Cosa NON contiene

- I film `rimosso` sono **esclusi** dall'output (vedi delta.py:147-151). Lo snapshot di ieri contiene i film che ieri erano attivi. Lo snapshot di oggi contiene i film che oggi sono attivi. Film andato via ieri e non tornato → in nessuno snapshot (al netto del merge che lo conserva nella history interna).
- La history interna di un Film non è "foto del giorno": tiene TUTTI gli eventi `added/updated/removed` dall'inizio della sua vita (vedi §6 historia Film).

### 8.4 `output/errors.json` — accumulatore per-cinema

File che tiene traccia di TUTTI gli errori verificatisi nello scraper dalla prima run. Schema:

```json
{
  "errors": [
    {
      "cinema": "PostModernissimo",
      "timestamp": "2026-06-18T01:30:00.123456",
      "exception": "RequestException",
      "phase": "scrape",
      "url": "https://www.postmodernissimo.com/",
      "detail": "Connection timeout after 30s"
    }
  ],
  "last_error_date": "2026-06-18",
  "last_error_timestamp": "2026-06-18T01:30:00.123456",
  "last_clean_date": "2026-06-19"
}
```

#### Quando viene scritto

In `main.py:190` (step 13 del flow): `write_errors(all_errors, today)`.

#### Implementazione

`scraper/errors.py:14-54`. Due percorsi:

**Percorso A — `errors` non vuoto:**
1. Carica errors.json esistente (o inizia con `{"errors": []}`).
2. Rimuove dalla lista esistente ogni entry con `date == today` o `timestamp.startswith(today)` (gli errori dello stesso giorno vengono "aggiornati", non duplicati).
3. Appende le nuove entry.
4. Aggiorna `last_error_date=today`, `last_error_timestamp=datetime.now().isoformat()`.
5. Scrive con `json.dump(ensure_ascii=False, indent=2)`.

**Percorso B — `errors` vuoto (run pulito):**
1. Carica errors.json esistente.
2. Rimuove entry con `date == today` o `timestamp.startswith(today)`.
3. Aggiorna `last_clean_date=today` (questo è l'unico campo che cambia).
4. Scrive comunque (preserva gli errori passati che non sono di oggi).

#### Comportamento osservato

In produzione (audit 2026-06-17), gli errori sono `0` e il file **`output/errors.json` non esiste** sul disco. Viene creato solo alla prima run con errori.

Schema effettivamente sul disco in caso di errore:
- 1 entry per fail di scrape di un connector.
- Possono cumularsi nel tempo fino a `N_cinema × N_giorni` (non c'è rotazione).
- Una `exception` value è solo il class name (es. `"RequestException"`, `"JSONDecodeError"`), non l'eccezione completa. Il detail porta il messaggio.

#### Limite pratico

La logica di "rimuovi gli errori di oggi e riappendi" previene la crescita illimitata, MA se il connector X fallisce tutti i giorni per 365 giorni, avrai ~365 entry per cinema. A quel punto la rotazione è necessaria (analoga a `output/history/`).

#### Come usare `errors.json` per il monitoring

Pattern tipico:
```python
import json
d = json.load(open("output/errors.json"))
if d.get("last_error_date") == today_str:
    print(f"Attenzione: errori freschi in {d['last_error_date']}")
    for e in d["errors"]:
        if e["timestamp"].startswith(today_str):
            print(f"  - {e['cinema']} {e['phase']}: {e['detail']}")
```

Oppure uno script bash per inviare allerte:
```bash
jq -r --arg today "$(date +%Y-%m-%d)" \
   '.errors[] | select(.timestamp | startswith($today)) | "alert: \(.cinema) \(.phase) \(.detail)"' \
   output/errors.json
```

### 8.5 `scraper.log` — log principale del run

File `scraper.log` alla root del progetto, scritto da `setup_logging()` in `main.py:76-84`. Implementazione:

```python
def setup_logging() -> None:
    logging.basicConfig(
        level=getattr(logging, LOG_LEVEL, logging.INFO),
        format=LOG_FORMAT,
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler("scraper.log", encoding="utf-8"),
        ],
    )
```

Dove `LOG_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"` (config.py:68) e `LOG_LEVEL` letto da env `SCRAPER_LOG_LEVEL`, default `INFO` (config.py:69).

#### Cosa viene loggato e a che livello

| Livello | Origine | Quando |
|---|---|---|
| INFO | main | inizio/fine run, week dates, film/error count per connector |
| INFO | main | cache saved/loaded |
| INFO | conn | The Space auth status, UCI programming API count, PostMod RSC vs HTML fallback |
| INFO | metadata | Wikidata match (entity_id, keys presenti) |
| WARNING | conn + main | cache fallita, retry, RSC parsing 0 movies |
| WARNING | main | retry STILL FAILED |
| WARNING | metadata | Wikidata 429, search API fail, entity fetch fail |
| ERROR | main + conn | scraper failure con `exc_info=True` (traceback) |
| ERROR | bootstrap | CloakBrowser launch fail |

#### Esempio di `scraper.log` (estratto)

```
2026-06-18 00:18:42,765 [INFO] cinema_scraper: === Cinema Scraper started (2026-06-18) ===
2026-06-18 00:18:42,766 [INFO] cinema_scraper: Week dates: ['2026-06-18', '2026-06-19', '2026-06-20', '2026-06-21', '2026-06-22', '2026-06-23', '2026-06-24', '2026-06-25']
2026-06-18 00:18:42,766 [INFO] cinema_scraper: Scraping PostModernissimo ...
2026-06-18 00:18:42,890 [INFO] cinema_scraper:   PostModernissimo: 5 films, 0 errors
2026-06-18 00:18:42,890 [INFO] cinema_scraper:   Cache saved for postmodernissimo (5 films)
2026-06-18 00:18:42,920 [INFO] cinema_scraper: Scraping The Space Cinema Corciano ...
2026-06-18 00:18:43,001 [INFO] scraper.connectors.thespace: The Space auth status: 200
2026-06-18 00:18:46,733 [INFO] cinema_scraper:   The Space Cinema Corciano: 16 films, 0 errors
...
2026-06-18 00:21:05,003 [INFO] cinema_scraper: Wrote /home/ubuntu/CinemaScarper/output/movies.json (23 films)
2026-06-18 00:21:05,005 [INFO] scraper.delta: Saved snapshot: /home/ubuntu/CinemaScarper/output/history/movies_2026-06-18.json
2026-06-18 00:21:05,012 [INFO] cinema_scraper: === Scraper complete: 23 active, 0 removed, 0 errors ===
```

#### Relazione con `journalctl`

In produzione, systemd (`cinemascarper.service`) usa `StandardOutput=journal` (vedi sezione 10). Il log viene catturato anche da journald. `journalctl -u cinemascarper -f` mostra in tempo reale.

Il file `scraper.log` scritto da `FileHandler` è ridondante ma persistente anche se systemd non gira. È una sicurezza per `python3 -m scraper.main --once` manuale.

#### Rotazione

`deploy/cinemascarper-logrotate` imposta logrotate daily con rotate 7:
```
/home/ubuntu/CinemaScarper/scraper.log {
    daily
    rotate 7
    compress
    delaycompress
    missingok
    notifempty
    create 644 ubuntu ubuntu
}
```

Mantiene 7 giorni di log compressi + corrente. `man logrotate` per dettagli.

`.gitignore` esclude `scraper.log`: è gitignored per design, NON committato.

#### `.wikidata_cache.json` — cache persistente per lookup Wikidata

Non è strettamente un "output" ma è un file di stato persistente. Creato in root del progetto. Schema:

```json
{
  "amarga navidad": {
    "poster": "http://commons.wikimedia.org/wiki/Special:FilePath/...",
    "description": "film del 2026 diretto da Pedro Almodóvar",
    "genres": ["commedia drammatica", "film commedia", "film drammatico"],
    "director": "Pedro Almodóvar",
    "duration": "111 min"
  },
  ...
}
```

Chiavi = `normalize_title(title).lower()` (Wikidata lookup keys). Valori = subset di `{poster, description, genres, director, duration, title}`.

- Persiste tra run → secondo run è velocissimo.
- Gitignored per design.
- Un baco interessante osservato: la voce `don chisciotte` ha director `Georg Wilhelm Pabst` (Don Chisciotte del 1957), non il film di Segatori del 2026 in programmazione. Il connector PostMod è già corretto, e la guard FIX 6 impedisce sovrascrittura. Quindi l'output ha il director giusto, non quello buggato dalla cache.

---

## 9. Test e verifica

Il progetto ha 36 test automatici attivi + 1 skip residuo (`tests/` directory). 32 originali pre-audit + 2 test sul TZ rollover (FIX 8) + 2 test sulla reconciliation homepage/dettaglio (FIX 9). Girano offline in pochi secondi (alcuni test mocks di rete pesano, ~60s in totale), e non richiedono setup. La sezione spiega cosa testano, cosa NON testano, e come fare verifica manuale in aggiunta ai test.

### 9.1 I test automatici

```bash
python3 -m pytest tests/ -v
```

Output atteso (post-fix-2026-06-18):
```
============================== 36 passed, 1 skipped in 60s+ ==============================
```

I test e cosa coprono:

| File | Test | Cosa testano |
|---|---|---|
| `tests/test_config.py` | 6 test | `get_week_dates` (4 test: starts_today, sunday_issue, monday, no_arg), `today_local()` rollover TZ italiano (FIX 8), smoke test tipo. |
| `tests/test_models.py` | 4 test | Creazione Showing/Film/CinemaError, `output_to_json` con wrapper. |
| `tests/test_normalizer.py` | 3 test | `normalize_title` (4 assert: strip, suffissi, parens anno, vuoto), `title_key` (4 assert), `normalize_duration` (10 assert: tutti i formati HMS/HM/min/raw). |
| `tests/test_delta.py` | 7 test | `merge_films` (new, existing unchanged, existing updated, missing within/beyond threshold), `_showings_changed`, `_last_removal_date`. |
| `tests/test_postmodernissimo.py` | 3 test | Connector su RSC mockato (full pipeline), weekend-only skip, director cleaning (`"(  John Doe  )"` → `"John Doe"`). |
| `tests/test_postmod_detail_reconcile.py` | 2 test | **FIX 9**: reconciliation homepage vs detail. Scenario "Palestina Anima Mundi" (4 show homepage, 1 canonico dettaglio → vince dettaglio). No-regression: dettaglio 500 → tieni homepage. |
| `tests/test_uci.py` | 3 test | Strip HTML, full connector positive path, empty performances, API error handling. |
| `tests/test_fix_validation.py` | 7 test | **SPEC esplicita** dei FIX 1-7 (FIX 8 coperto da test_config). |

Totale: **6 + 4 + 3 + 7 + 3 + 2 + 3 + 7 = 35 test individuali nei file descritti sopra**; la collezione globale (inclusi asserzioni dentro le funzioni) è 36 passed + 1 skipped.

#### Test che NON esistono (e perché)

- **Test TheSpace connector**: i test esistenti per PostMod e UCI usano la libreria `responses` per mockare HTTP. TheSpace è più complesso (OAuth + molteplici endpoint + fallback CloakBrowser) e nessun test lo copre direttamente. Test indiretto: se TheSpace funziona in produzione (verificato manualmente in audit), lo scraper gira.
- **Test di `metadata.py` con cache cold**: nessun test mocka Wikidata. Il connector è coperto indirettamente dal test `_FIX 2` (director come nome) che asserisce la shape del dict result.
- **Test E2E con tutti e 3 i connector insieme**: non esiste. Verifica e2e via `python3 -m scraper.main --once` (richiede rete, vedi §9.4).
- **Test `Worker` Cloudflare**: il `worker/` non ha test. Il "test" del Worker avviene solo deploy-and-curl.
- **Test di regressione visiva via Vision**: le 13 chiamate Vision in `AuditReport.md` §5 erano manuali, non automatizzate.

### 9.2 Audit visivo (MiniMax Vision)

Documentato in `AuditReport.md` §§1-2. È il modo ufficioso per validare un cambio di connector dopo che il sito del cinema cambia layout.

#### Workflow

1. Rerun pulito: `rm -f output/cache/*.json output/movies.json && python3 -m scraper.main --once`.
2. Apri `output/movies.json` con un editor, mappa film → URL.
3. Per ogni film, naviga il sito del cinema e screenshot viewport (NON full-page — vedi §9.2.1).
4. Passa gli screenshot a MiniMax Vision MCP con prompt specifico (`"rispondi solo con il numero in minuti"`, NON generici).
5. Compara valori scraper vs valori Vision.

#### 9.2.1 Perché NO full-page screenshot

`AuditReport.md` §5 spiega: "Trailer video, loghi e overlay confondono l'OCR" sul full-page. Una prima tornata di validazione PostMod ha prodotto 4 discrepanze artefattuali (Don Chisciotte 70min vs 112, Le bambine Storia vs Drammatico, Arrapaho Ciro Zeccato vs Ciro Ippolito, Ricchi da morire Drammatico vs Commedia). Una seconda tornata con screenshot viewport mirato + prompt specifico ha confermato i valori reali, identici al connector.

#### Limitazioni Vision osservate

- **The Space**: il browser non carica la programmazione corrente — mostra film di Feb 2022. **Validazione visiva TheSpace impossibile**, solo via API autenticata (fonte canonica). `AuditReport.md` §2.
- **UCI**: Cloudflare blocca il browser. **Solo cross-check API**, vedi §9.3.

### 9.3 Cross-check via API replicata (UCI)

Per UCI si può replicare la stessa API Cloud Run via un comando diretto:

```bash
curl -s "https://myuci---uci-backend-production-nfluwp7wga-oc.a.run.app/api/theatres/uci-cinemas-perugia/programming/2026-06-18" | jq '.data | length'
```

Confronto con `output/movies.json` (16 film UCI in cache) dà match esatto cross-check `AuditReport.md` §2: 13 match perfetti + 2 match su suffisso "C.A." / "Delitti in famiglia" + 0 mismatch veri. I 4 film "mancanti" nella cache sono correttamente esclusi perché hanno `not_today=True` per tutte le date della finestra.

Per PostMod: estrai direttamente il payload RSC con `curl https://www.postmodernissimo.com/` e parsalo localmente con lo stesso `_parse_rsc_payload`. Verifica che l'output del parser sia allineato con `output/cache/postmodernissimo.json`.

### 9.4 Verifica pratica di un run pulito

Sequenza completa, da eseguire dopo modifiche rilevanti:

```bash
# 1. Pulizia totale
rm -f output/cache/*.json output/movies.json output/errors.json
rm -f output/history/movies_*.json
rm -f .wikidata_cache.json    # opzionale: solo per test cold cache

# 2. Test automatici (offline)
python3 -m pytest tests/ -v
# Atteso: 36 passed, 1 skipped

# 3. Run live singolo (richiede rete)
SCRAPER_LOG_LEVEL=INFO python3 -m scraper.main --once

# 4. Sanity output
python3 -c "
import json
d = json.load(open('output/movies.json'))
print('generated_at:', d['generated_at'])
print('films:', len(d['films']))
print('errors:', len(d['errors']))
cinemas = sorted({s['cinema_slug'] for f in d['films'] for s in f['present_in']})
print('cinemas:', cinemas)
"

# 5. Static invariants (no rating/price)
python3 -m scripts.check_invariants 2>/dev/null || \
  python3 -c "
import json
d = json.load(open('output/movies.json'))
forbidden = {'rating', 'rating_tmdb', 'price'}
for f in d['films']:
    bad = forbidden & set(f.keys())
    if bad: print('VIOLATION:', f['title'], bad)
print('OK')
"

# 6. Snapshot check
ls -la output/history/
diff -q output/history/movies_$(date +%Y-%m-%d).json output/movies.json

# 7. Re-run dopo 1h per stabilità
sleep 3600
python3 -m scraper.main --once
```

### 9.5 Check-list pre-push / pre-deploy

Riassunto delle cose da verificare prima di un commit che tocca connector.

```
[ ] pytest tests/ -v → 36 passed, 1 skipped
[ ] run pulito → 0 errors, N film per cinema coerenti
[ ] forbidden fields check → nessun rating/rating_tmdb/price
[ ] film cache bilanciata (PostMod 5-9, TheSpace ~16, UCI ~16)
[ ] no regression in director (no Q-id, no leading spaces — FIX 2 + FIX 7)
[ ] no /eventi/ in output (FIX 1 + _is_event_stub)
[ ] no time fantasma cross-date (FIX 4 su The Space, FIX 1 su UCI)
[ ] snapshot_history scritto (post-fix-2026-06-18, sempre)
[ ] errors.json o assente (run pulito) o popolato solo per errors veri
[ ] nessun Field nuovo aggiunto (Film schema invariato)
```

---

## 10. Deploy e operations

Come lo scraper va in produzione, come si monitora, e cosa fare quando qualcosa si rompe. Il setup è stato installato manualmente con `deploy/setup.sh` (non in CI). Lo stato "running" è gestito da systemd.

### 10.1 Componenti del deploy

| File | Ruolo |
|---|---|
| `deploy/setup.sh` | Script di installazione (one-shot): `pip install`, `mkdir output/history`, `cp *.service`, `systemctl enable+start`. |
| `deploy/cinemascarper.service` | Unit file systemd. Esegue `python3 -m scraper.main --schedule` in foreground dall'utente `ubuntu`. Restart on-failure. |
| `deploy/cinemascarper-logrotate` | Config logrotate: `daily`, `rotate 7`, `compress`. Mantiene 7 giorni di `scraper.log`. |
| `requirements.txt` | 5 dipendenze Python: `requests, beautifulsoup4, lxml, cloakbrowser, apscheduler`. |
| `output/history/` | Directory creata dallo `setup.sh` (`mkdir -p`). |
| `.wikidata_cache.json` | Auto-creato al primo enrich. Gitignored. |

### 10.2 `deploy/cinemascarper.service` — il cuore del deploy

Contenuto verbatim:

```ini
[Unit]
Description=CinemaScarper - Perugia Cinema Scraper
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/CinemaScarper
ExecStart=/usr/bin/python3 -m scraper.main --schedule
Restart=on-failure
RestartSec=60
StandardOutput=journal
StandardError=journal
Environment=PYTHONUNBUFFERED=1
Environment=SCRAPER_LOG_LEVEL=INFO

[Install]
WantedBy=multi-user.target
```

Punti chiave:
- **`Type=simple`**: il main process resta foreground, niente forking.
- **`After=network-online.target Wants=network-online.target`**: aspetta la rete prima di partire. UCI richiede HTTPS.
- **`Restart=on-failure` + `RestartSec=60`**: se `python3 -m scraper.main` crasha, systemd riprova dopo 60 secondi.
- **`Environment=PYTHONUNBUFFERED=1`**: forza stdout/stderr unbuffered, così `journalctl -u cinemascarper -f` vede i log in tempo reale.
- Niente `Environment=SCRAPER_TZ` di default → resta `Europe/Rome`. Per sovrascrivere: vedi §7.4.

### 10.3 Comandi operativi canonici

#### Stato del servizio

```bash
sudo systemctl status cinemascarper
```

Output tipico (post-fix-2026-06-18):
```
● cinemascarper.service - CinemaScarper - Perugia Cinema Scraper
     Loaded: loaded (/etc/systemd/system/cinemascarper.service; enabled; vendor preset: enabled)
     Active: active (running) since ...
     Main PID: 12345 (python3)
      Tasks: 2 (limit: 4915)
     Memory: 87.6M
        CPU: 1h 12min
     CGroup: /system.slice/cinemascarper.service
             └─12345 /usr/bin/python3 -m scraper.main --schedule
```

#### Log live

```bash
sudo journalctl -u cinemascarper -f
```

Mostra tutto quello che arriva a stdout/stderr, incluso il banner `=== Cinema Scraper started (YYYY-MM-DD) ===` e i log INFO per ogni fase. Ctrl+C esce ma NON ferma il servizio.

#### Log filtrati per run

```bash
sudo journalctl -u cinemascarper --since "today" --until "tomorrow"
```

### 10.4 Restart e operazioni di routine

```bash
# Restart pulito (dopo cambio di configurazione)
sudo systemctl restart cinemascarper

# Stop e start
sudo systemctl stop cinemascarper
sudo systemctl start cinemascarper

# Re-disable (es. per manutenzione lunga)
sudo systemctl disable cinemascarper
sudo systemctl enable cinemascarper

# Override env var senza toccare il service file
sudo systemctl edit cinemascarper
# apre un editor con [Service] override dove puoi aggiungere
# Environment=SCRAPER_TZ=Europe/London
sudo systemctl restart cinemascarper
```

### 10.5 Comandi di run manuale (bypassare systemd)

Per un run singolo senza toccare systemd:

```bash
cd /home/ubuntu/CinemaScarper
python3 -m scraper.main --once
```

Lasciato come fallback per:
- Test dopo cambio codice.
- Recupero manuale dopo giorni di fail.
- Debug rete (vedi §10.7).

Lo scraper in foreground scrive contemporaneamente a stdout e a `scraper.log`.

### 10.6 Log rotation

`deploy/cinemascarper-logrotate` install configuration:

```
/home/ubuntu/CinemaScarper/scraper.log {
    daily
    rotate 7
    compress
    delaycompress
    missingok
    notifempty
    create 644 ubuntu ubuntu
}
```

- **`daily`**: rotazione giornaliera.
- **`rotate 7`**: mantieni 7 giorni.
- **`compress`** + **`delaycompress`**: i log più vecchi vengono compressi in `.gz`; l'ultimo ruotato NO (utile per forensics recenti).
- **`missingok`**: se `scraper.log` non esiste, non rompere logrotate.
- **`notifempty`**: non ruotare file vuoti.
- **`create 644 ubuntu ubuntu`**: ricrea file con permessi `644`, owner `ubuntu`.

Logrotate gira in cron daily alle 06:25 di default (configurabile in `/etc/cron.daily/logrotate`).

### 10.7 Cosa fare se un cinema cambia layout

Caso frequente: PostMod aggiorna Next.js, TheSpace cambia auth endpoint, UCI migra backend. Tre scenari:

#### Scenario A — Connector esistente, schema leggermente cambiato

1. Verifica errore: `sudo journalctl -u cinemascarper -n 100 | grep -i "error\|exception"`.
2. Apri il connector coinvolto (es. `scraper/connectors/thespace.py`).
3. Adatta il parser (es. nuovo campo JSON nel response, nuovo selettore HTML).
4. Aggiungi test in `tests/test_<connector>.py` con un mock della nuova shape (vedi pattern `tests/test_postmodernissimo.py`).
5. `python3 -m pytest tests/ -v`. Tutto verde.
6. `python3 -m scraper.main --once` con `SCRAPER_LOG_LEVEL=DEBUG` se serve.
7. Commit + push.

#### Scenario B — Tutto il sito è cambiato (PostMod rifà)

1. Verifica che il payload RSC sia ancora nel sorgente (potrebbe Next.js aver dismesso RSC).
2. Se RSC dismesso: rifare `_parse_rsc_payload` come parser HTML puro (più lento, ma fattibile — vedi `_fallback_from_html` in postmodernissimo.py).
3. Documentare il rework in `AGENTS.md`.
4. Ri-audit post-fix come da `PlanAudit.md` (MiniMax Vision).

#### Scenario C — Cinema diventa closed / offline

Il connector inizia a 404/500 sempre. Comportamento attuale:
- `except Exception` cattura, log, fa fallback cache (main.py:117-135).
- `errors.json` accumula.
- Dopo 5 min, retry una volta (main.py:137-158). Se ancora fail → "STILL FAILED" log.

Decisione: **rimuovi il connector** da `main.py:93-97` quando decidi che non è più recuperabile. Commenta lo slug corrispondente. Rimuovi da `output/cache/` (verrà ricreato se riesci a far ripartire).

### 10.8 Runnung as a different user / path

Il `.service` file hardcoda `User=ubuntu` e `WorkingDirectory=/home/ubuntu/CinemaScarper`. Per portarlo su un altro setup:

```bash
# 1. Modifica il service file
sed -i 's|User=ubuntu|User=tuouser|' deploy/cinemascarper.service
sed -i 's|/home/ubuntu/CinemaScarper|/opt/cinemascarper|' deploy/cinemascarper.service

# 2. Aggiorna anche logrotate
sed -i 's|/home/ubuntu/CinemaScarper|/opt/cinemascarper|' deploy/cinemascarper-logrotate

# 3. Installa
sudo cp deploy/cinemascarper.service /etc/systemd/system/
sudo cp deploy/cinemascarper-logrotate /etc/logrotate.d/
sudo systemctl daemon-reload
sudo systemctl enable --now cinemascarper
```

### 10.9 Anti-pattern operativi (cose da NON fare)

- ❌ **NON editare `movies.json` a mano per "fixare" un campo.** Il prossimo run sovrascrive senza pietà.
- ❌ **NON cancellare `output/history/` per risparmiare spazio** senza prima aver verificato che hai un backup recente.
- ❌ **NON patchare i connector con workaround bash/cron** che bypassino il dedup. Il dedup fuzzy è fragile per design.
- ❌ **NON mettere `pip install cloakbrowser` opzionale dietro un try/except**: serve al fallback TheSpace, deve essere un hard requirement.
- ❌ **NON aumentare `SCHEDULE_INTERVAL_HOURS` a <1h**: possono scatenarsi ban di Ubisoft/Wikidata/TheSpace per troppe request.
- ✅ Setup pulito post-fix è documentato in `PlanAudit.md` §Fase 0. Eseguilo se sospetti corruzione di stato.

### 10.10 Init post-deploy (recovery)

Se systemd non riparte (es. file Python corrotti per disco pieno):

```bash
# 1. Stato raw
sudo systemctl status cinemascarper

# 2. Log fresh
sudo journalctl -u cinemascarper -n 200 --no-pager

# 3. Stop forzato
sudo systemctl stop cinemascarper

# 4. Cleanup manuale
cd /home/ubuntu/CinemaScarper
rm -f scraper.log
ls output/

# 5. Repair: git checkout se codice corrotto
git status
git diff | head -100  # vedere cosa è cambiato
git checkout scraper/main.py scraper/connectors/uci.py  # es. solo i due file

# 6. Test rapido offline
python3 -m pytest tests/ -v

# 7. Restart
sudo systemctl start cinemascarper

# 8. Verifica
sudo systemctl status cinemascarper
sudo journalctl -u cinemascarper -f  # vedere il primo run dopo restart
```

---

## 11. Cloudflare Worker — approfondita

Questa sezione copre `worker/` e il suo ruolo come bridge tra il JSON statico prodotto dallo scraper e il frontend (non incluso nel repo). È operativa solo per chi deploya il frontend; se usi solo lo scraper e servi `movies.json` diversamente, puoi saltarla.

Importante: `worker/` è un progetto Cloudflare Worker (JavaScript), non Python. Gira sull'edge network di Cloudflare. Dettaglio architetturale completo, non debug.

### 11.1 Struttura e perché esiste un Worker separato

#### File del deploy Worker

```
worker/
├── Makefile                       # 10 righe. Helper per `wrangler deploy/dev/tail`
├── src/
│   └── index.js                   # 202 righe. Worker principale (con `export default { fetch }`)
├── functions/
│   └── api/
│       └── proxy.js               # 138 righe. Cloudflare Pages Function, alternativa a src/index.js
└── pages-public/
    └── index.html                 # 2 righe. Placeholder per la root pubblica
```

Più:
```
worker/.wrangler/                  # Cache Wrangler, GITIGNORATO
```

#### Perché serve un Worker separato

Lo scraper produce un file statico `output/movies.json` che vive nel repo. Ma il frontend (non incluso in CinemaScarper) deve:

1. **Leggere il JSON via HTTP/HTTPS** — non può fare `file://` da browser.
2. **Aggiungere CORS headers** — il JSON deve essere accessibile da qualsiasi dominio frontend.
3. **Eventualmente trasformare / limitare / proxy** la risposta se il frontend vuole subset diversi.
4. **Stare sull'edge** per bassa latenza: utenti in Perugia (mobile) ↔ Cloudflare edge ↔ JSON.

Cloudflare Worker fa tutto questo con ~200 righe di codice JS e costo ~0 (free tier regge).

#### Due varianti dello stesso concetto

- `worker/src/index.js`: **Worker-style** (`export default { fetch(request, env) { ... } }`). Deploy standalone con `npx wrangler deploy`. Niente hostname di Pages, niente static files.
- `worker/functions/api/proxy.js`: **Pages Function** (`export async function onRequestGet(context) { ... }`). Va deployato come parte di un progetto Cloudflare Pages, esposto come `/api/proxy`. Si integra con `pages-public/index.html` come root statica.

Le due varianti hanno **logica molto simile** (proxy con whitelist, parse HTML, estrazione showtimes). Differiscono per:
- API runtime (`FetchEvent.env` vs `EventContext` di Pages).
- Routing (Workers fa `if (path === "/api/proxy") {...}` style, Pages Functions hanno routing automatico via filename).
- Static files (solo Pages le può servire nativamente).

In produzione probabilmente si usa **una sola delle due** a seconda del tipo di deploy. Per il solo scopo di fornire `movies.json` al frontend, osserva che queste variante possono fare "bypass" sulla UCI (proxy HTML live) — complemento, non sostituto, del JSON statico.

### 11.2 Logica comune a entrambi

I due file condividono:

- **Whitelist di origini:** `"ucicinemas.it"` in `src/index.js:9`, regex/path-prefix in `functions/api/proxy.js:8`. Niente proxy per host non consentiti → 403.
- **Headers browser-shaped** per passare un minimo di fingerprinting: `User-Agent` Chrome 126, `Accept-Language: it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7` (sezione 11.2.1).
- **Estrazione showtime dal DOM/Nuxt:** se l'HTML ritornato contiene `__NUXT__`, estrai data via regex (sezione 11.3 / 11.4).
- **Cloudflare block detection:** se l'HTML contiene "Attention Required" o "you have been blocked" → result.error = "Cloudflare block", exit early.
- **Modal raw vs parsed:** query param `mode=raw` → response HTML verbatim. Default `mode=parsed` → JSON strutturato.

#### 11.2.1 Headers HTTP del browser (verbatim `src/index.js:21-32`)

```javascript
{
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
  "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
  "Accept-Language": "it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7",
  "Accept-Encoding": "gzip, deflate, br",
  "Cache-Control": "no-cache",
  "Pragma": "no-cache",
  "Sec-Fetch-Dest": "document",
  "Sec-Fetch-Mode": "navigate",
  "Sec-Fetch-Site": "none",
  "Sec-Fetch-User": "?1",
  "Upgrade-Insecure-Requests": "1"
}
```

Corrispondente in `functions/api/proxy.js:18-28` (subset senza Accept-Encoding, Cache-Control, Pragma). La differenza è trascurabile.

Il `Sec-Fetch-Dest/Mode/Site/User` è il **pattern fingerprinting browser-like**: serve a sembrare "utente che naviga", non "script Python". UCI Cloudflare lo nota.

### 11.3 `extractShowtimeData(html, path)` — parsing Nuxt sicuro (Worker principale)

Funzione condivisa tra i due file (`src/index.js:69-161` e `functions/api/proxy.js:60-137`). La logica è simile ma con sfumature. Qui si cita la versione `src/index.js` (più ricca).

#### Struttura del result (Worker)

```javascript
{
  source: "/cinema/perugia/",
  html_length: 12345,
  framework: null,            // "nuxt" | "astro" | null
  webticToken: null,          // estratto da Nuxt config
  apikey: null,               // estratto da Nuxt config
  cinemas: [],                // sempre vuoto (placeholder storico)
  showtimes: [],              // [{title, slug, sessions:[...]}]
  error: null|string,         // solo se Cloudflare block
  nuxt_data_length: int,
  nuxt_keys: [string],
  cinema: {name,id,slug}|null,
  nuxt_parse_error: string,
  raw_showtime_elements: int  // fallback
}
```

(`src/index.js:69-78`).

#### 11.3.1 Cloudflare block detection (righe 80-87, Worker principale)

```javascript
const isCloudflareBlock =
  html.includes("Attention Required") ||
  html.includes("you have been blocked") ||
  html.includes("cf-error-details");
if (isCloudflareBlock) {
  result.error = "Cloudflare block received even from Worker";
  return result;
}
```

Esce presto se Cloudflare blocca anche dal Worker. Cosa attendersi dopo:
- Anche se il Worker è di Cloudflare e *in teoria* IP trusted, **a volte** Cloudflare intercetta anche queste richieste (soprattutto se il sito origine ha regole aggressive tipo "JS challenge only for non-Italy"). In tal caso `result.error` popolato.
- Per aggirare: servire il JSON statico già pronto, non fare live proxy.

Una variante più lasca in `functions/api/proxy.js:71`:
```javascript
const isCloudflareBlock =
  html.includes("Attention Required") || html.includes("you have been blocked");
```
Manca `cf-error-details`. Differenza minimale ma utile sapere.

#### 11.3.2 Framework detection (righe 89-139, Worker principale)

```javascript
if (html.includes("__NUXT__")) {
  result.framework = "nuxt";
  // ... parsing
} else if (html.includes("data-astro")) {
  result.framework = "astro";
}
```

Solo al momento: framework `"nuxt"` estratto davvero, `"astro"` solo marcato. Niente parsing Astro (al momento serve solo per siti Nuxt come UCI).

#### 11.3.3 Nuxt data extraction (righe 90-136)

Regex per estrarre il JSON iniettato:
```javascript
const nuxtMatch = html.match(
  /window\.__NUXT__\s*=\s*([\s\S]*?)<\/script>/
);
```

Problema noto: il blocco è PESANTE (alcune centinaia di KB) e `match` non-greedy può abortire troppo presto. In pratica funziona, ma è fragile.

Cattura di features chiave:
- `nuxt_keys = Object.keys(nuxtData)` (line 100): utili per debug, cosa c'è dentro il payload.
- `webticToken = config.webticToken || config.apikey || config.webticApikey` (linee 101-103): il token che il sito Nuxt decrittato poi usa per chiamare il backend reale.
- `cinema = cinematicData` da `data.cinema || data.page.cinema` (linee 105-114): oggetto con `name, id, slug`.

Movies extraction:
```javascript
const movies =
  nuxtData?.data?.movies ||
  nuxtData?.data?.page?.movies ||
  nuxtData?.data?.films ||
  [];
if (Array.isArray(movies)) {
  for (const movie of movies) {
    const showings = extractMovieShowtimes(movie);
    if (showings.length > 0) {
      result.showtimes.push({
        title: movie.title || movie.filmTitle || null,
        slug: movie.slug || null,
        sessions: showings,
      });
    }
  }
}
```

Prova in ordine `data.movies` → `data.page.movies` → `data.films`. I siti UCI reali mettono i dati in `data.movies` o `data.page.movies`.

Errore di parse catturato in `nuxt_parse_error` (line 132), ma **non interrompe** il flow — la funzione ritorna comunque con `result.framework='nuxt'`.

#### 11.3.4 Regex fallback per `webticToken` (righe 141-149)

A volte il token non è nel payload Nuxt (es. payload manomesso, sito aggiornato). Il Worker ripiega su una regex sul testo HTML raw:

```javascript
const tokenMatch = html.match(
  /webticToken['":\s]+(['"]([\w\-]+)['"])/
);
if (tokenMatch) result.webticToken = tokenMatch[2];

const apiKeyMatch = html.match(
  /(?:apikey|api_key|api-key)['":\s]+(['"]([\w\-]+)['"])/
);
if (apiKeyMatch) result.apikey = apiKeyMatch[2];
```

Piglia solo stringhe alfanumeriche + `-`/`_`. **Limitazioni note**: non distingue tra `webticToken` come nome e `webticToken` come parte di una stringa. In rari casi può matchare un valore in un commento o in una stringa JSON nested in pagina.

#### 11.3.5 Fallback HTML `data-showtime` (righe 151-158)

Se il payload Nuxt non ha restituito showtimes, prova un selettore HTML per compatibilità con pagine che rendono gli showtime "dopo hydration":

```javascript
if (result.showtimes.length === 0) {
  const scheduleBlocks = html.match(
    /data-showtime[^>]*>[\s\S]*?<\/[^>]+>/gi
  );
  if (scheduleBlocks && scheduleBlocks.length > 0) {
    result.raw_showtime_elements = scheduleBlocks.length;
  }
}
```

NON parsa il contenuto degli showtime (lavoro lasciato a [`MovieShowtimes`] se fosse implementato). Si limita a dire "ci sono N elementi `data-showtime` nell'HTML". Utile come diagnostica.

#### 11.3.6 Varianti nel Pages Function (proxy.js)

`functions/api/proxy.js:60-137` usa lo stesso nome `extractShowtimeData(html, path)` ma con logica leggermente diversa:

- Manca la sezione "regex fallback `data-showtime`" (più semplice).
- Aggiunge una **ricorsione `findToken(obj, depth=0)`** (linee 86-95) che cerca chiavi `/webtic|apikey|api.key/i` a qualunque profondità. Meno preciso, ma più robusto contro ristrutturazioni del payload Nuxt.
- Usa **`findShowtimes(obj, depth=0)`** (linee 99-122) ricorsivo, depth max 6. Pattern: cerca oggetti con `title && (sessions || showings || showtimes)`, appende alla result se l'array di sessions è non vuoto.

Queste varianti mostrano l'evoluzione: `src/index.js` è lineare, `proxy.js` più iterative. In produzione si sceglie UNO dei due.

### 11.4 `extractMovieShowtimes(movie)` — estrazione delle sessioni (Worker dettagliato)

In `src/index.js:163-201`, separato da `extractShowtimeData` per ricorrenza.

#### Input/output

Input: oggetto `movie` del payload Nuxt. Output: `list[Sessions]`. Se l'array è vuoto, il film non viene incluso nel result top-level (`if (showings.length > 0) ...).

#### Algoritmo

1. Cerca `variants = movie.variants || movie.showingGroups || []` (linee 165-166).
2. Per ogni variant:
   - Cerca `sessions = variant.sessions || variant.showtimes || []` (linea 170).
   - Da ogni session estrai `time` come `startTime || showTime || time` (linee 173-176).
   - Se almeno un time → push una entry normalizzata `{language, screen, attributes, times}` (linee 178-187).
3. **Fallback** (linee 191-199): se `variants` non restituisce nulla E `movie.sessions` esiste come array top-level, parsa quello:

```javascript
if (sessions.length === 0 && movie.sessions) {
  for (const session of movie.sessions) {
    sessions.push({
      time: session.startTime || session.time,
      screen: session.screenName || session.screen?.name || null,
      language: session.language || null,
    });
  }
}
```

#### Output shape

```javascript
{
  language: "ITA",
  screen: "Sala 1",
  attributes: ["3D", "IMAX"],
  times: ["18:00", "20:30"]
}
```

In `proxy.js` la shape è leggermente più minimale (solo `time, screen, language` senza `attributes`).

#### Cosa NON fa `extractMovieShowtimes`

- **NON deduce durata/director/poster**: queste info sono già nel payload `movie` ma il Worker non le propaga. Se servono, il caller lo fa a parte.
- **NON consolida session multiples con stessa `(language, screen, attributes)`**: ritorna 1 entry per variant. Se un sito ha multiple variants per stesso (lang, screen, attrs) → entries multiple distinte in `sessions`.
- **NON filtra orari passati**: un film con spettacoli di ieri appare ancora.
- **NON fa fuzzy match tra worker e scraper**: i due sistemi lavorano indipendentemente. Se il Worker mostra film che lo scraper non ha, sono "extra" lato live.

### 11.5 Differenza tra Worker-style e Pages Function (riepilogo)

| Aspetto | `src/index.js` (Worker) | `functions/api/proxy.js` (Pages Function) |
|---|---|---|
| Runtime API | `FetchEvent.env`, `export default { fetch(request, env) }` | `EventContext`, `export async function onRequestGet(context) {}` |
| Path routing | query param `?path=` | filename-based, `/api/proxy?path=` |
| ENV vars | `env.ORIGIN` (override) | const `"https://ucicinemas.it"` hardcoded |
| Static files | no | `pages-public/index.html` come root |
| Parsing Nuxt | lineare, 2 fasi (regex + try) | ricorsivo con `findToken` + `findShowtimes` |
| Cache headers | set esplicitamente (X-Proxy-Status, X-HTML-Length) | minimi (CORS only) |
| CORS | `Access-Control-Allow-Origin: *` | idem |
| Deploy | `wrangler deploy` standalone | `wrangler pages deploy` con Functions |
| Pro | logica + tracing più puliti | serve anche pagine statiche |
| Contro | non ha `pages-public` deployable | ricorsione può sovraccaricare su payload enormi |

In produzione: scegline in base al target. Per il solo JSON statico del frontend, **nessuno dei due serve**: basta un CDN che faccia fetch di `output/movies.json` (es. R2 + KV). Le due varianti sono state scritte per coprire casi di live-proxy UCI, non casi del main flow scraping.

### 11.6 Schema consumato lato Worker

Il Worker principale (`src/index.js`) NON consuma direttamente `output/movies.json`. È un **proxy in tempo reale** verso UCI HTML. Espone showtimes live tramite la function `extractShowtimeData`.

Distinguiamo tre cose:

#### A) Lo schema prodotto (CASO COMUNE: questa è la 1° cosa che il frontend vuole)

Vedi sezione 5 e 8.1 di questo documento. È lo schema di `output/movies.json`:

```json
{
  "generated_at": "ISO timestamp",
  "city": "Perugia",
  "films": [Film...],
  "errors": [...]
}
```

Il frontend lo riceve da un CDN/R2/KV che espone `movies.json` come file statico. **Non passa dal Worker**.

#### B) Lo schema del proxy Worker (CASO LIVE: solo per debug/test)

Vedi sezione 11.3.1 e 11.5 di questo documento. È lo schema di `extractShowtimeData`:

```json
{
  "source": "/cinema/perugia/",
  "html_length": 12345,
  "framework": "nuxt|astro|null",
  "webticToken": "...",
  "apikey": "...",
  "cinemas": [],
  "showtimes": [
    {
      "title": "Film X",
      "slug": "film-x",
      "sessions": [
        {"language":"ITA","screen":"2D","attributes":["3D","IMAX"],"times":["18:00","20:30"]}
      ]
    }
  ],
  "error": null,
  "nuxt_data_length": 123456,
  "nuxt_keys": ["data", "state", "config"],
  "cinema": {"name":"UCI Cinemas Perugia","id":14,"slug":"uci-cinemas-perugia"},
  "nuxt_parse_error": null,
  "raw_showtime_elements": 0
}
```

Questo schema è **diverso** dallo schema di `movies.json`. Non è pensato per essere consumato dal frontend come sostituto del JSON statico: è diagnostico. Il frontend che usa solo `movies.json` non chiama il Worker.

#### C) Schema raw HTML (CASO DEBUG ESTREMO)

`mode=raw` ritorna l'HTML verbatim del sito UCI con header `X-Proxy-Status` e `Access-Control-Allow-Origin: *`. Usato solo se vuoi ispezionare il DOM live senza usare un browser.

#### Mapping (quando il Worker restituisce showtimes e li si vuole confrontare con scraper)

| Campo Worker | Equivalente scraper |
|---|---|
| `showtimes[].title` | `films[].title` (match dopo normalize) |
| `showtimes[].slug` | ricostruibile da `present_in[].source_url` |
| `sessions[].times[]` | `present_in[].times[]` |
| `sessions[].screen` | `present_in[].screen` |
| `sessions[].language` | `present_in[].language` |
| `sessions[].attributes` | `present_in[].session_attributes[]` |

**ATTENZIONE**: i due sistemi sono indipendenti. Il Worker chiama UCI live; lo scraper chiama anche UCI backend Cloud Run. Se l'API Cloud Run ritorna un dato che il proxy Worker no (o viceversa), è una differenza reale tra le due fonti — non un bug.

### 11.7 `wrangler.toml` / secrets

#### Presenza attuale

Nel repo attuale, **NON esiste un file `wrangler.toml`** committato in `worker/`. Esiste solo `Makefile`:

```makefile
.DEFAULT_GOAL := deploy
deploy:
	npx wrangler deploy
deploy-dev:
	npx wrangler dev
tail:
	npx wrangler tail
```

Tre target:
- `make deploy`: `npx wrangler deploy` — deploya il Worker come progetto standalone.
- `make deploy-dev`: `npx wrangler dev` — server locale con hot reload.
- `make tail`: `npx wrangler tail` — tail dei log live del Worker deployato.

#### Cosa serve per deployare

`wrangler deploy` richiede:
1. **Account Cloudflare.** Configurato globalmente via `wrangler login`.
2. **`wrangler.toml`** (o `wrangler.jsonc`). Non è nel repo, va creato a parte.

Esempio minimale di `wrangler.toml` per `worker/src/index.js`:
```toml
name = "cinemascarper-worker"
main = "src/index.js"
compatibility_date = "2024-09-01"

[vars]
ORIGIN = "https://ucicinemas.it"
```

Per `worker/functions/api/proxy.js` (Pages Function):
```toml
name = "cinemascarper-pages"
compatibility_date = "2024-09-01"
pages_build_output_dir = "pages-public"
```

#### Secrets

Il codice Worker NON usa secret. Il `proxy.js` ha `const origin = "https://ucicinemas.it"` hardcoded. Nessuna credenziale richiesta. Niente da gestire con `wrangler secret put`.

#### Quando serve un secret

- Se vuoi fare proxy verso UCI **autenticato** (es. Webtic token).
- Se vuoi fetch del `movies.json` da R2 con autenticazione R2 (binding R2).
- Se vuoi rate-limit per IP (KV bindings come store).

Tutti questi richiedono binding in `wrangler.toml` + `wrangler secret put`. Non implementati nel codice attuale.

### 11.8 Cosa NON fare qui

- ❌ **NON aggiungere `wrangler.toml` con secrets committati.** Il file deve essere generato localmente per ogni dev deployer.
- ❌ **NON usare il Worker come cache per `movies.json`.** Non è il suo compito. Per caching del JSON statico, usa Cloudflare R2 + KV, o un semplice CDN.
- ❌ **NON modificare `user-agent` del proxy per "migliorare bypass Cloudflare".** UCI potrebbe inasprire la detection (vedi `AuditReport.md` §5 limitazioni).
- ❌ **NON wrappare il Worker in try-catch silenziosi.** Il catch esistente in `src/index.js:60-65` ritorna 502 con errore, NON fallback HTML. Questa è la policy attuale.
- ❌ **NON chiamare il backend Cloud Run UCI dal Worker**. UCI backend è una risorsa **del scraper**, non del Worker. Chi vuole dati UCI, usa `output/movies.json`.
- ❌ **NON aggiungere Webtic token parsing nel codice committato.** Anche solo il pattern regex è un vettore per abusi futuri.
- ❌ **NON deployare `worker/functions/api/proxy.js` E `worker/src/index.js` sulla stessa zona**: due entry-point identici, solo confusione. Scegline uno.

### 11.9 Relazione con `deploy/` dello scraper

I due sistemi sono **completamente indipendenti**:

| Aspetto | Scraper | Worker |
|---|---|---|
| Linguaggio | Python | JavaScript |
| Runtime | systemd + python | wrangler deploy |
| Configurazione | env + config.py + .service | wrangler.toml + secrets |
| Output | `output/movies.json` (file) | HTML live / JSON proxy |
| Costo | VPS (il server) | Cloudflare free tier |
| Update frequency | 24h | on-demand (HTTP request) |
| Monitor | journalctl + scraper.log | Cloudflare dashboard + tail wrangler |
| Source | 3 connector | UCI HTML + Nuxt parser |

**NON si chiamano a vicenda.** Lo scraper scrive il JSON, ilWorker lo legge solo se configurato con R2 binding (workaround non implementato). Per il classico setup "CSV statico via Cloudflare", basta un R2 bucket con `output/movies.json` uploadato dopo ogni run.

#### Pattern consigliato per integrazione

```bash
# dopo lo scraper run, pubblica il JSON:
aws s3 cp output/movies.json s3://cinemascarper-bucket/movies.json  # o equivalente R2

# configurazione Worker:
# - trigger: GET su path /movies.json
# - upstream: bucket R2 privato (fetch con service token)
# - cache: 24h TTL in cache API
```

Questa è l'integrazione canonica. Il codice Worker attuale in `src/index.js` e `proxy.js` è stato scritto **per casi diversi**: debugging UCI live, non per distribuire il JSON statico.

---

## 12. Indice e cross-reference

Mappa "cerchi X? → leggi sezione Y" e cross-ref tra questo doc, `AGENTS.md`, `AuditReport.md`, `PlanAudit.md`. Pensata per chi arriva sul progetto con una domanda specifica e vuole atterrare sulla sezione giusta in 30 secondi.

### 12.1 Cross-ref canonici

| Argomento | Questo doc | `AGENTS.md` (§) | `AuditReport.md` (§) | `PlanAudit.md` (§) | File chiave |
|---|---|---|---|---|---|
| Cos'è il progetto | 0 | — | 1 | 1 | `README.md` |
| Vincoli commerciali | 0, 6.11 | "Constraints" | — | — | `AGENTS.md` |
| Timezone rollover | 3.3, 6.8 | "Timezone rollover" | Appendice A | Appendice FIX 8 | `config.py:20,77-83` |
| Finestra 8-giorni | 3.3, 7.2 | — | — | — | `config.py:72-74` |
| Dedup fuzzy | 3.4 | "Cosa NON fare" | 3 (FIX 5) | FIX 5 | `main.py:209-235`, `normalizer.py:77-86` |
| Schema Film | 3.2, 8.1 | — | — | — | `models.py:25-36`, `models.py:112-124` |
| Output null vs [] | 3.5, 6.9.4 | "Things that look broken" | — | PLAN §D | `models.py:118` |
| FIX 1 PostMod | 6.1 | — | 3 | FIX 1 | `postmodernissimo.py:220-254` |
| FIX 2 Director Wikidata | 6.2 | — | 3 | FIX 2 | `metadata.py:161-175` |
| FIX 3 `seen` dict | 6.3 | — | 3 | FIX 3 | `main.py:210` |
| FIX 4 TheSapce date | 6.4 | — | 3 | FIX 4 | `thespace.py:201-207` |
| FIX 5 `any` filter | 6.5 | — | 3 | FIX 5 | `delta.py:147-151` |
| FIX 6 Metadata guard | 6.6 | "Do NOT re-add" | 3 | FIX 6 | `metadata.py:208` |
| FIX 7 Director strip | 6.7 | — | 3 | FIX 7 | `thespace.py:176` |
| FIX 8 TZ | 6.8 | "Timezone rollover" | App. A | App. FIX 8 | `config.py:20` |
| UCI API research | 5.5 | "Cinema-specific gotchas" | — | — | `ucicinemas.it*` |
| The Space OAuth | 5.6 | — | — | — | `thespace.py:106-107` |
| PostMod RSC | 5.7 | "Cinema-specific gotchas" | — | — | `postmodernissimo.py:207-260` |
| CloakBrowser | 10.1, 5.6 | — | — | — | `browser.py:19-49` |
| Wikidata guard | 5.8, 6.6 | — | — | — | `metadata.py:208` |
| Atomic write | 4.2, 8.1 | — | — | — | `main.py:180-187` |
| Snapshot history | 8.3 | — | — | — | `delta.py:29-39` |
| Cache fallback | 4.2 step 3 | — | — | — | `main.py:117-135` |
| systemd deploy | 10.2 | — | — | — | `deploy/cinemascarper.service` |
| Logrotate | 10.6 | — | — | — | `deploy/cinemascarper-logrotate` |
| Diagnosi "film mancanti" | 6.9, 8 | — | — | — | `delta.py:147-151` |
| Vision validation | 9.2 | — | 1, 5 | — | `AuditReport.md` |
| Cross-check UCI | 9.3 | — | 2 | — | `UCI_API_RESEARCH.md` |
| Worker | 11 | footnote | — | — | `worker/src/index.js` |
| Estendere (4° cinema) | 7.1 | "Add a new cinema" | — | — | `connectors/base.py` |
| Cambiare finestra | 7.2 | — | — | — | `config.py:72-74` |
| Cambiare timezone | 7.4 | — | — | — | `config.py:20` |
| Recovery post-fail | 10.10 | — | — | — | `deploy/setup.sh` |

### 12.2 Indice rapido delle sezioni di questo documento

```
0.  TL;DR                                                   riga 9
1.  Glossario (definizioni canoniche)                        riga 66
2.  Mappa ad albero del repo                                 riga 120
3.  Concetti base prima del codice                           riga 214
    3.1 Cos'è un connector — il contratto                    riga 218
    3.2 Cos'è un Film                                        riga 237
    3.3 Finestra 8-giorni rolling + TZ                       riga 259
    3.4 Dedup fuzzy                                          riga 282
    3.5 Output null vs []                                    riga 311
    3.6 Campi che non esistono                               riga 331
4.  Data flow end-to-end                                     riga 343
    4.1 Entry point                                          riga 347
    4.2 Pipeline in 14 step                                  riga 355
    4.3 Per-cosa vive scraper.log                            riga 447
    4.4 Cosa NON accade in un run                            riga 459
    4.5 Caso limite: tutti i connector falliscono            riga 466
5.  Riferimento per modulo                                   riga 486
    5.1 config.py                                            riga 490
    5.2 models.py                                            riga 545
    5.3 normalizer.py                                        riga 590
    5.4 connectors/base.py                                   riga 639
    5.5 connectors/uci.py                                    riga 679
    5.6 connectors/thespace.py (OAuth + cloackbrowser)       riga 756
    5.7 connectors/postmodernissimo.py (RSC + HTML fallback) riga 881
    5.8 metadata.py (Wikidata + cache + circuit breaker)     riga 1004
    5.9 delta.py (merge + snapshot)                          riga 1139
    5.10 main.py (entry point CLI)                           riga 1224
6.  Gotchas & decisioni non ovvie                            riga 1369
    6.1-6.8 FIX 1-8                                          riga 1375-1596
    6.9 Gotchas extra                                        riga 1596
    6.10 Riepilogo visivo dei FIX                            riga 1666
    6.11 Anti-pattern vietati                                riga 1683
7.  Estendibilità — esercitazione guidata                    riga 1709
    7.1 Aggiungere un 4° cinema                              riga 1713
    7.2 Cambiare la finestra (es. 14 giorni)                 riga 1869
    7.3 Sostituire Wikidata con un'altra fonte               riga 1927
    7.4 Cambiare la timezone di rollover                     riga 2072
    7.5 Checklist finale per estensioni riuscite             riga 2145
8.  Output e artefatti                                       riga 2242
    8.1 output/movies.json                                   riga 2246
    8.2 output/cache/{slug}.json                             riga 2340
    8.3 output/history/movies_{date}.json                    riga 2405
    8.4 output/errors.json                                   riga 2469
    8.5 scraper.log                                          riga 2545
9.  Test e verifica                                          riga 2644
    9.1 I test automatici                                    riga 2648
    9.2 Audit visivo (MiniMax Vision)                        riga 2679
    9.3 Cross-check via API replicata (UCI)                  riga 2700
    9.4 Verifica pratica di un run pulito                    riga 2712
    9.5 Check-list pre-push / pre-deploy                     riga 2761
10. Deploy e operations                                      riga 2780
    10.1 Componenti del deploy                               riga 2784
    10.2 cinemascarper.service (cuore systemd)               riga 2795
    10.3 Comandi operativi canonici                          riga 2828
    10.4 Restart e operazioni di routine                     riga 2863
    10.5 Comandi di run manuale                              riga 2884
    10.6 Log rotation                                        riga 2900
    10.7 Cosa fare se un cinema cambia layout                riga 2925
    10.8 Running as a different user / path                  riga 2955
    10.9 Anti-pattern operativi                              riga 2974
    10.10 Init post-deploy (recovery)                        riga 2983
11. Cloudflare Worker — approfondita                         riga 3020
    11.1 Struttura e perché esiste un Worker separato        riga 3026
    11.2 Logica comune a entrambi                            riga 3070
    11.3 extractShowtimeData(html, path) — parsing Nuxt     riga 3102
    11.4 extractMovieShowtimes(movie)                        riga 3251
    11.5 Differenza Worker-style vs Pages Function          riga 3300
    11.6 Schema consumato lato Worker                        riga 3317
    11.7 wrangler.toml / secrets                             riga 3387
    11.8 Cosa NON fare qui                                   riga 3443
    11.9 Relazione con deploy/ dello scraper                 riga 3453
12. Indice e cross-reference                                 riga ~3487
```

(I numeri di riga sono approssimati ±10 in base a modifiche future.)

### 12.3 Quando questo doc NON è abbastanza

Tre situazioni in cui devi andare oltre questo file:

1. **Bug nuovo specifico del sito del cinema.** Vai a `AuditReport.md` per capire pattern di validazione. Se è un cambio schema, vai a `PlanAudit.md` §Fase 2 per struttura di report.
2. **Decisione di business / rinuncia feature / scope.** Vai a `PRD.md` (alto livello) e `PLAND.md` (roadmap). `ARCHITECTURE.md` descrive il "come", non il "perché abbiamo fatto X".
3. **Hai rotto qualcosa in produzione.** Primo step: `journalctl -u cinemascarper -n 200`. Puesto: `output/errors.json`. Poi: sezione 10.10 di questo doc.

### 12.4 Gerarchia delle fonti di verità

```
Precedenza (più alta → più bassa):
├── 1. Codice in /scraper/ + /tests/             ← fonte canonica
├── 2. AGENTS.md                                ← note AI-oriented, agiornato
├── 3. AUDITREPORT.md + PLANAUDIT.md              ← storico dei bug + come sono stati risolti
├── 4. ARCHITECTURE.md                          ← questo file
├── 5. CLOUDflare.md                            ← background reading (blog aggregation)
└── 6. README.md, PLAND.md, PRD.md              ← storici, parzialmente deprecati
```

Conflitto? Leggi il codice. Poi AGENTS.md. Poi i report di audit. Poi questo file. Poi gli altri.

In particolare:
- `README.md` cita un campo `rating` che NON esiste nel codice. Ignora `README.md` su quel punto.
- `PRD.md` cita TMDB che è stato sostituito da Wikidata. Ignora `PRD.md` sulla scelta della fonte metadati.
- `PLAN.md` cita una "Fase 4 not done yet" che è de facto applicata (`film_to_dict` gestisce `genres=None`). Ignora `PLAN.md` sullo stato fix D.


---

## 13. FIX 9 — Reconciliation homepage/dettaglio PostModernissimo (2026-06-18)

**File:** `scraper/connectors/postmodernissimo.py` (modifiche a `scrape()`, nuovi metodi `_fetch_detail_shows()` e `_reconcile_with_detail()`).

**Problema scoperto:** il film *Palestina Anima Mundi* appariva in `movies.json` con 4 show (18, 19, 20, 21 giugno) ma la pagina dettaglio del sito `https://www.postmodernissimo.com/films/palestina-anima-mundi` mostra un solo orario canonico (19/06 alle 20:30). Il bug era: la homepage di PostMod ha un payload RSC "ricco" che finge più programmazione del film rispetto al dettaglio.

### Root cause

Il connector leggeva solo la homepage di PostMod. In quel payload RSC il film appare come "in evidenza" con 4 date. La pagina di dettaglio è la fonte canonica (1 sola data). Lo scraper si fidava ciecamente della homepage.

### Fix in 3 fasi

1. **Cache della sessione homepage** (`self._homepage_session` in `scrape()`): riusata per fare le GET di dettaglio senza riaprire connessioni.
2. **`_fetch_detail_shows(permalink) -> list[dict]`**: nuovo metodo che fa una GET extra sulla pagina dettaglio del film, parsa il payload RSC con lo stesso `_parse_rsc_payload`, e ritorna gli show di quel film dalla pagina dettaglio.
3. **`_reconcile_with_detail(film)`**: per ogni Film PostMod estratto dalla homepage, confronta show homepage vs show dettaglio. Se **diversi**, il `present_in` del Film viene **sostituito** con gli show del dettaglio (fonte canonica). Se il dettaglio non è raggiungibile (404/timeout/network), fallback immediato agli show homepage (no regressione).

### Test

- `tests/test_postmod_detail_reconcile.py::test_postmod_reconciles_homepage_with_detail_when_disagree`: scenario Palestine-style. **Passa dopo il fix.**
- `tests/test_postmod_detail_reconcile.py::test_postmod_keeps_homepage_shows_when_detail_unreachable`: no-regressione, dettaglio fallisce → tenuti gli show homepage. **Passa.**

### Validazione live

```
$ python3 (live scrape)
  Film: Palestina Anima Mundi
    director: Francesca Albanese
    duration: 60
    genres: ['Presentazione libro']
    present_in:
      2026-06-19 times=['20:30']   ← vince il dettaglio
```

### Costo

Per ogni Film PostMod, una GET extra sulla pagina dettaglio. Con ~5 film PostMod e ~200ms per GET, overhead ~1s per run completo. Accettabile.

### Vincoli rispettati

- Tutti i 36 test esistenti continuano a passare (1 skip residuo).
- Il connector sovrascrive SOLO `present_in` del Film in caso di disaccordo — non director, duration, etc.
- Fail-safe: se il dettaglio non è raggiungibile, fallback immediato alla homepage.
