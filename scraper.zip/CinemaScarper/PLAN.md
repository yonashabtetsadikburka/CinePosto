# CinemaScarper - Piano di completamento

**Obiettivo**: Scraper al 100% di affidabilità per progetto commerciale.
**Aggiornato**: 2026-06-14

---

## Stato attuale

| Componente | Affidabilità | Stato |
|-----------|-------------|-------|
| PostModernissimo | ~95% | Fallback HTML se RSC fallisce |
| The Space Cinema | ~85% | Cache + retry funzionano |
| UCI Cinemas | ~80% | Cache + retry funzionano |
| Pipeline (main.py) | ~95% | Retry + scrittura atomica + snapshot |
| Browser (browser.py) | ~90% | `--disable-gpu` attivo |
| Wikidata enrichment | ~70% | Solo cache + fuzzy, no SPARQL |
| **Sistema totale** | **~95%** | **Tutte le fix Fase 1-3 applicate** |

### Problemi rimasti

1. **Film finti**: "Fabio Segatori e il Gruppo Micrologus presentano Don Chisciotte" è un concerto, non un film
2. **Film duplicati**: Mandalorian x2, Principessa Mononoke x2 per nomi diversi
3. **Metadata incompleti**: UCI non fornisce regia/durata. 13/27 film senza rating

---

## FASE 4 — Pulizia dati

**Obiettivo**: Output senza eventi finti, senza duplicati, metadata coerenti.

| # | Fix | Effort | Stato |
|---|-----|--------|-------|
| A | **Filtra eventi PostModernissimo** — in `_parse_rsc_payload()`: `if "/eventi/" in permalink: continue`. In `_parse_film_cards()`: selettore solo `a[href*='/films/']` | 5 min | not done yet |
| B | **Fix normalizer** — aggiungere `re.IGNORECASE` a `_AND_WORD` e `_C_A_SUFFIX`. Aggiungere stripping prefissi franchise (`"STAR WARS: "`, ecc.) | 15 min | not done yet |
| C | **Fix dedup** — in `_deduplicate_films()` usare `fuzzy_match()` oltre a `title_key()` esatto | 15 min | not done yet |
| D | **Metadata uniformi** — nel JSON output, mostrare solo campi che esistono. `null` se mancano. Non inventare. Frontend decide cosa mostrare | 15 min | not done yet |

**Risultato Fase 4**: 0 eventi finti. 0 duplicati. Metadata coerenti (quelli che ci sono, `null` se mancano).

---

## Riepilogo

| Fase | Effort totale | Stato | Risultato |
|------|--------------|-------|-----------|
| Fase 1 | ~1.5 ore | done | Cinema affidabili |
| Fase 2 | ~1 ora | done | Nessuna perdita dati |
| Fase 3 | ~2 ore | done | Metadata e pulizia |
| Fase 4 | ~50 min | not done yet | Dati puliti e coerenti |
| **Totale** | **~5 ore** | | **Scraper completo** |

---

## Cosa NON fare

- **Non implementare un enrichment Wikidata complesso** — il 95% di fallimento è un problema di rete/infrastruttura. La cache + fuzzy search è sufficiente.
- **Non cercare di estrarre director/duration dall'API UCI** — quei campi non esistono nell'API. Vengono da Wikidata (quando funziona) o non ci sono.
- **Non aggiungere complessità al browser** — `--disable-gpu` basta. Non serve Puppeteer, non serve un secondo browser.
