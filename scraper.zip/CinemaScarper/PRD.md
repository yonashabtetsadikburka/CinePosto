PRD: Scraper cinema Perugia
Questo prodotto è uno scraper Python che raccoglie la programmazione dei cinema di Perugia e zona, arricchisce i film con metadati da TMDb, e salva tutto in JSON con storico delta + merge. Le fonti iniziali sono i siti ufficiali di UCI Perugia, The Space Corciano e PostModernissimo Perugia; PostModernissimo è in via del Carmine 4 a Perugia, The Space Corciano è in zona Corciano, e UCI Perugia ha programmazione pubblica con orari e sale.

Obiettivo prodotto
L’obiettivo è permettere all’app di cercare un film e mostrare, per ogni cinema disponibile, titolo, orari, prezzo, copertina, rating e descrizione. Il sistema deve aggiornarsi automaticamente ogni 24 ore e mantenere un quadro storico delle variazioni di programmazione, non solo una fotografia del giorno.

Ambito iniziale
Il prodotto copre solo cinema in area Perugia:

UCI Cinemas Perugia.

The Space Cinema Corciano.

PostModernissimo Perugia.

Il bot deve estrarre tutti i film attualmente in programmazione da ciascun sito e ignorare sale fuori area, come UCI di altre città. La localizzazione è quindi un requisito chiave del sistema.

Fonti dati
Scraping cinema
Le fonti primarie sono HTML scraping dai siti ufficiali dei cinema. I dati disponibili includono film in programmazione, orari, informazioni sulle sale e spesso prezzo o range di prezzo; ad esempio ComingSoon mostra che UCI Perugia e The Space Corciano hanno programmazione locale con orari e sale pubbliche, mentre PostModernissimo pubblica la sua settimana di programmazione sul sito ufficiale.

Metadati film
Per poster, descrizione e rating, la fonte consigliata è TMDb. La documentazione TMDb indica che l’API è gratuita per uso non commerciale con attribuzione, ma per uso commerciale bisogna verificare la licenza/accordo.

Requisiti funzionali
Lo scraper deve visitare i tre siti e recuperare tutti i film attualmente disponibili.

Deve estrarre almeno: titolo, cinema, data, orari, prezzo se presente, URL sorgente.

Deve arricchire ogni film con: poster, descrizione, rating da TMDb.

Deve salvare il risultato in JSON.

Deve mantenere uno storico delle variazioni tramite delta + merge.

Deve creare un file errori separato se un sito fallisce o cambia struttura.

Deve eseguire una sincronizzazione automatica ogni 24 ore.

Deve permettere filtri per data, cinema, prezzo e valutazione lato app.

Requisiti non funzionali
Linguaggio: Python.

Parsing: solo HTML scraping, senza browser automation se i siti restano leggibili via requests/BeautifulSoup.

Robustezza: retry, timeout, logging e gestione errori.

Normalizzazione: titoli in italiano.

Output: JSON stabile e versionato.

Manutenibilità: connettori separati per ogni sito.

Modello dati
La struttura consigliata è centrata sul film:

json
{
  "generated_at": "2026-06-09T16:40:00+02:00",
  "city": "Perugia",
  "films": [
    {
      "title": "Backrooms",
      "title_normalized": "Backrooms",
      "rating_tmdb": 7.1,
      "poster": "https://image.tmdb.org/...",
      "description": "....",
      "genres": ["Horror"],
      "status": "in_programmazione",
      "present_in": [
        {
          "cinema": "UCI Cinemas Perugia",
          "cinema_slug": "uci-perugia",
          "date": "2026-06-09",
          "times": ["16:00", "19:00"],
          "price": "6.70",
          "source_url": "..."
        }
      ],
      "history": [
        {
          "date": "2026-06-08",
          "action": "added"
        }
      ]
    }
  ],
  "errors": []
}
Delta + merge
Il delta + merge funziona così:

il bot legge il JSON precedente;

confronta i film nuovi con quelli già presenti;

aggiunge i nuovi film;

aggiorna quelli ancora in sala con nuovi orari o prezzi;

marca come rimossi i film che non risultano più in programmazione;

conserva un piccolo storico degli eventi.

Questo è utile se vuoi una visione a 360 gradi, perché ti permette di capire non solo cosa è in sala oggi, ma anche quando un film è entrato o uscito dalla programmazione.

Pipeline del bot
Fetch HTML dei tre siti.

Parse dei blocchi film.

Estrazione di titolo, orari, prezzo, cinema.

Normalizzazione del titolo.

Lookup TMDb per poster, descrizione e rating.

Merge con JSON precedente.

Scrittura JSON aggiornato.

Scrittura log errori separato.

Scheduling ogni 24 ore.

Gestione errori
Se un sito non è disponibile o cambia layout:

salvare l’errore in errors.json o logs/errors_YYYY-MM-DD.json;

non bloccare gli altri siti;

salvare il parziale riuscito;

includere nel log: sito, timestamp, eccezione, fase di errore.

Filtri richiesti
L’app dovrà poter filtrare:

per data, usando present_in.date;

per cinema, usando present_in.cinema;

per prezzo, usando present_in.price;

per valutazione, usando rating_tmdb o rating scelto.

Assunzioni importanti
Tutti i titoli vengono salvati in italiano o comunque normalizzati in italiano.

TMDb sarà usato come fonte metadati principale finché la licenza resta compatibile col progetto.

Il sistema è pensato per aggiornare solo i cinema di Perugia e dintorni, non catene nazionali in generale.

Fuori ambito
Non fare scraping di cinema fuori area.

Non costruire il frontend dell’app.

Non implementare login, ticketing o acquisto biglietti.

Non fare crawling generale del web.

KPI di successo
95%+ dei film locali recuperati correttamente ogni giorno.

Aggiornamento completato entro pochi minuti.

Zero crash del job se un sito fallisce.

JSON utilizzabile direttamente dall’app per ricerca e filtri.

Rischi
Cambi di layout HTML dei siti.

Titoli non perfettamente allineati tra cinema e TMDb.

Limiti o cambi licenza di TMDb se l’app diventa commerciale.

Informazioni di prezzo non sempre uniformi tra i siti.

Output attesi
movies.json

errors.json

scraper.log
