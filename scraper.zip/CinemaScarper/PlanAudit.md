# PlanAudit — CinemaScarper Convalidazione Completa

> **Scopo:** Navigare i 3 siti dei cinema via Playwright, estrarre i dati visivi con MiniMax Vision, confrontarli con l'output dello scraper e applicare le fix identificate dall'audit.
> 
> **Creato:** 2026-06-17
> **Stato:** ✅ **COMPLETATO** — vedi `AuditReport.md` per i risultati dettagliati
> **Post-appendice:** 2026-06-18 — fix TZ rollover Italy (era bug-reported alle 01:32 local, vedi §FIX 8)

---

## Fase 0 — Preparazione Iniziale

1. **Cancella cache vecchia** per evitare artefatti da merge delta:
   ```bash
   rm -f output/cache/*.json output/movies.json
   ```

2. **Esegui scraper pulito:**
   ```bash
   python3 -m scraper.main --once
   ```

3. **Indicizza il JSON** per avere la mappa film-dettaglio:
   ```bash
   python3 -c "
   import json
   with open('output/movies.json', 'r') as f:
       data = json.load(f)
   # Genera mappa film -> cinema -> date -> orari per rapido confronto
   for film in data['films']:
       print(f'{film[\"title\"]}')
       for p in film.get('present_in', []):
           print(f'  {p[\"cinema\"]} {p[\"date\"]} {p[\"times\"]}')
   "
   ```

---

## Fase 1 — Navigazione Siti Live + Estrazione Dati

### 1A. Pagina di programmazione generale per cinema

Per ogni cinema, apri la pagina programmazione e scorri per catturare tutti i film e orari visibili.

#### PostModernissimo
- **URL programmazione:** `https://www.postmodernissimo.com/`
- **URL specifici film:** `https://www.postmodernissimo.com/films/<slug>`
- **Screenshot:**
  - Homepage con griglia film in evidenza
  - Sezione "In sala" / "Programmazione" con date e orari
- **MiniMax Vision estrae:** titoli, orari, date visibili nella pagina
- **Verifica:** nessun film presente sul sito manchi nello scraper

#### The Space Corciano
- **URL programmazione:** `https://www.thespacecinema.it/cinema/corciano/al-cinema`
- **Screenshot:** pagina completa con lista film e orari
- **MiniMax Vision estrae:** titoli film, orari per data, sale (Sala 1, Sala 2...), attributi (ITALIANO, 2D)

#### UCI Cinemas Perugia
- **URL programmazione:** `https://www.ucicinemas.it/cinema/perugia-ugiazzolini/`
- **Screenshot:** pagina completa con lista film e orari
- **MiniMax Vision estrae:** titoli film, orari per data, formati
- **Nota:** verificare anche la sezione "Altri film in programma" dove possono apparire titoli non nella fascia principale

### 1B. Pagina di dettaglio per ogni film singolo

Per ogni film presente nello scraper, navigare alla pagina di dettaglio tramite il `source_url` salvato:

- **MiniMax Vision estrae da ogni pagina singola film:**
  - **Titolo esatto** (confronto con scraper)
  - **Regista** (dal campo "regia", meta tag, o testo descrittivo)
  - **Durata** (campo "durata", o testo vicino)
  - **Genere** (campo "genere" o lista categorie)
  - **Descrizione/Sinossi** (dal campo "content" o meta description)
  - **Poster/Locandina** (ovviamente presente o meno, URL diretto vs proxy)
  - **Orari per data** specifica (per validazione riga per riga)

- **Per ogni film, aprire la pagina di dettaglio e screenshot:**
  - Screenshot della sezione superiore (titolo, poster, metadati)
  - Screenshot della sezione orari/programmazione (se presente nella pagina singola)

### 1C. Rilevamento Film Assenti

Dopo aver raccolto i dati dal sito, verificare:
- **Film nel sito ma non nello scraper:** elencarli come "MISSING IN SCRAPER"
- **Film nello scraper ma non nel sito:** segnalarli come possibile "ghost" o film passato/non ancora pubblicato

---

## Fase 2 — Report di Convalidazione Automatico

Generare una tabella strutturata con il seguente formato per ogni film trovato:

| Film | Cinema | Campo | Dato Scraper | Dato Sito Live | Match? |
|---|---|---|---|---|---|
| Don Chisciotte | PostModernissimo | Orario 17/06 | 21:00 | 18:30 | ❌ NO |
| Don Chisciotte | PostModernissimo | Regista | Fabio Segatori | [da verificare] | ? |
| ... | ... | ... | ... | ... | ... |

### Campi da confrontare per ogni film
1. **Titolo** (esatto, inclusi caratteri speciali)
2. **Orari per data** (ogni singola data della finestra 8 giorni)
3. **Regista**
4. **Durata**
5. **Genere**
6. **Descrizione/Sinossi**
7. **Poster** (URL diretto vs proxy vs mancante)
8. **Sala** (per TheSpace e UCI)
9. **Lingua / attributi**
10. **Stato** (in programmazione / prossimamente / non visibile)

---

## Fase 3 — Fix da Implementare (basate su audit)

### FIX 1: Merge RSC incompleto (PostModernissimo) — CRITICO
**File:** `scraper/connectors/postmodernissimo.py` (righe 243-265)  
**Problema:** mantiene solo l'occorrenza con più `shows`, perdendo show di altre occorrenze.  
**Soluzione:** per ogni `permalink`, accumulare TUTTI gli show da tutte le occorrenze prima di decidere quali tenere.

```python
# CORRENTE (bug): sovrascrive tutto se shows > len(existing["shows"])
if len(shows) > len(existing["shows"]):
    candidates_by_permalink[permalink] = { ... nuovo ... }

# FIX DESIDERATO:
# - per ogni permalink, accumula gli shows in un set unificato
# - poi costruisci il film finale con TUTTI gli show trovati
```

### FIX 2: Regista come ID Wikidata (metadata) — DATI
**File:** `scraper/metadata.py` (riga ~165)  
**Problema:** quando arricchisce da Wikidata, restituisce l'ID entità (es. `Q25258`) invece del nome del regista.  
**Soluzione:** dopo aver ottenuto l'ID del regista, fare ulteriore lookup API per risolvere in nome testuale;
o, se non possibile, lasciare `None` invece dell'ID.

### FIX 3: Variabile `seen` inizializzata come lista — BUG POTENZIALE
**File:** `scraper/main.py` (riga 210)  
**Problema:** `seen: dict[str, Film] = []` inizializzato come lista ma tip come dict.  
**Soluzione:** correggere `= {}` oppure rimuovere se non utilizzato.

### FIX 4: Fallback date errato in TheSpace — BUG ORARI
**File:** `scraper/connectors/thespace.py`  
**Problema:** se il parsing della data di un gruppo di show fallisce, assegna `today` anche se è un altro giorno.  
**Soluzione:** non assegnare data arbitraria in caso di errore; saltare il gruppo o loggare errore.

### FIX 5: Esclusione film senza orari nella delta — BUG PRESENZA
**File:** `scraper/delta.py` (riga ~150)  
**Problema:** esclude un film se per un giorno non ha orari, anche se validi per altri giorni.  
**Soluzione:** cambiare il filtro per escludere solo se il film non ha orari per NESSUN giorno della finestra.

```python
# CORRENTE: esclude se *qualsiasi* showing ha times vuoti
any(s.times for s in f.present_in)

# FIX: esclude solo se TUTTI gli showings hanno times vuoti
# (o meglio: se il film non ha NESSUN orario per NESSUN giorno)
```

### FIX 6: Arricchimento metadata troppo aggressivo — BUG PIENI METADATI
**File:** `scraper/metadata.py` (righe 200-201)  
**Problema:** se poster e description esistono, ritorna senza tentare regista/durata/genere mancanti.  
**Soluzione:** modificare la guard per tentare arricchimento anche se poster/desc esistono, ma solo per i campi mancanti.

### FIX 7: Spazi iniziali nei director — DATI SPORCHI
**File:** `scraper/connectors/thespace.py` e simili  
**Problema:** director come `" Travis Knight"` con spazio iniziale.  
**Soluzione:** aggiungere `.strip()` all'estrazione del campo regista in ogni connector.

---

## Fase 4 — Verifica Post-Fix (dopo implementazione)

1. Rieguire lo scraper: `python3 -m scraper.main --once`
2. Ripetere la navigazione Playwright SOLO per i film dove erano state trovate discrepanze
3. Verificare che i campi precedentemente sbagliati ora siano corretti
4. Aggiornare il report con stato "FIX VERIFICATO" per ogni campo

---

## Note Operative per Nuova Sessione

### Dipendenze da avere pronte
- Playwright installato e configurato: `playwright install chromium`
- MiniMax Vision accessibile come strumento MCP
- Connessione internet operante per navigazione siti live
- Python3 e dipendenze progetto già installate (`pip install -r requirements.txt`)

### Flusso consigliato operativo
1. Esegui lo scraper con `--once`
2. Per ogni cinema, in sequenza:
   a. Apri pagina programmazione, screenshot
   b. Per ogni film nello scraper per quel cinema:
      - Apri pagina dettaglio del film (tramite `source_url` nel JSON)
      - Screenshot sezione dati principali
      - Screenshot sezione orari/programmazione
3. Per ogni screenshot, usa MiniMax Vision per estrarre i valori dei campi
4. Registra i confronti nella tabella

### Salva screenshot in struttura organizzata
```
/tmp/audit_screenshots/
  postmodernissimo/
    homepage.png
    amarga_navidad.png
    don_chisciotte.png
    ...
  thespace/
    homepage.png
    disclosure_day.png
    ...
  uci/
    homepage.png
    disclosure_day.png
    ...
```

---

## Appendice — FIX 8 (post-rollover, bug-report 2026-06-18 01:32 IT)

### Sintomo
Lo scraper con `python3 -m scraper.main --once` produceva `today = 2026-06-17` anche quando in Italia erano già le 01:32 del 18 giugno. La finestra settimanale rimaneva ancorata al giorno precedente.

### Causa
Il server Ubuntu è in `TZ=UTC` (default). `date.today()` ritorna la data in TZ locale del server (UTC finché non è diversamente configurato). Tra le 00:00 e le 01:00 (UTC+1) o 02:00 (UTC+2) di Italia, il sistema crede di essere ancora al giorno precedente.

### Fix
- Aggiunto `SCRAPER_TZ = ZoneInfo(os.environ.get("SCRAPER_TZ", "Europe/Rome"))` in `scraper/config.py`
- Aggiunta funzione helper `today_local()` che fa `datetime.now(SCRAPER_TZ).date()`, ritornando sempre la data italiana
- `run_scraper()` in `main.py:88` ora chiama `today_local().isoformat()` invece di `date.today().isoformat()`
- `get_week_dates()` ora usa `today_local()` come default per `ref_date`
- Pulizia: rimosso `date` dall'import di `main.py` (non più usato)

### Vincoli / Note
- `SCRAPER_TZ` env var rimane configurabile per chi deploya in altre timezone
- Test `test_today_local_rollover_at_italian_midnight` simula Rome=01:30 e verifica che viene ritornato il nuovo giorno anche se UTC dice ancora il precedente
- Test `test_get_week_dates_no_arg` aggiornato per usare `today_local()` come riferimento

### File modificati
- `scraper/config.py` — aggiunto `SCRAPER_TZ`, `today_local()`, e `get_week_dates` aggiornato
- `scraper/main.py` — usa `today_local()` + pulizia import
- `tests/test_config.py` — aggiunti 2 test sul rollover

---

## Checklist Completa per Sessione di Implementazione

### Pre-scraping
- [x] Cancella cache e history locale
- [x] Esegui scraper pulito
- [x] Genera mappa film-dettaglio dal JSON

### Convalidazione PostModernissimo
- [x] Screenshot homepage con griglia film
- [x] Per ogni film: screenshot pagina dettaglio
- [x] Confronta titolo, orari, regista, durata, genere, description, poster
- [x] Verifica nessun film nel sito risulti mancante dallo scraper

### Convalidazione TheSpace
- [x] Screenshot pagina cinema Corciano con lista film (fatto, miniMax limitato)
- [x] Per ogni film: screenshot pagina dettaglio (fatto per 16 film)
- [x] Confronta titolo, orari, sala, lingua, regista, durata, genere, description, poster (via API autenticata, fonte canonica)

### Convalidazione UCI
- [x] Screenshot pagina cinema Perugia con lista film (HTTP 403)
- [x] Per ogni film: screenshot pagina dettaglio (HTTP 403)
- [x] Confronta titolo, orari, formato, regista, durata, genere, description, poster (cross-check via API replicata: 16/16 match)

### Implementazione Fix
- [x] FIX 1: merge RSC postmodernissimo.py
- [x] FIX 2: regista come nome (non ID) in metadata.py
- [x] FIX 3: correzione seen in main.py
- [x] FIX 4: fallback date in thespace.py
- [x] FIX 5: esclusione film delta.py (verificato, già corretto)
- [x] FIX 6: arricchimento metadata troppo aggressivo
- [x] FIX 7: strip spazi director

### Verifica Post-Fix
- [x] Riesegui scraper (27 film, 0 errori)
- [x] Ri-naviga siti per film con discrepanze precedenti (PostModernissimo 9 film completi)
- [x] Conferma correzione campi (vedi AuditReport.md per dettagli)

### FIX 8: Timezone rollover Italy (post-audit)
- [x] `today_local()` Europe/Rome in scraper/config.py
- [x] `run_scraper()` in main.py usa `today_local()` invece di `date.today()`
- [x] Test `test_today_local_rollover_at_italian_midnight` verde
- [x] Test `test_get_week_dates_no_arg` aggiornato

---

**Nota finale:** questo file è un piano da seguire passo-passo in una nuova sessione. Non modifica il codice esistente; serve solo come guida per l'implementazione strutturata delle fix e della convalidazione visiva completa.
