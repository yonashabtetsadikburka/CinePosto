# CinemaScarper

Scraper per gli orari cinematografici della zona di Perugia.

## Cinema supportati

| Cinema | Metodo | Note |
|--------|--------|------|
| PostModernissimo | requests + BeautifulSoup | Piatto €5.00 |
| The Space Cinema Corciano | API interna | Via browser fallback |
| UCI Cinemas Perugia | Backend API programming | Endpoint pubblico |

## Installazione

```bash
pip install -r requirements.txt
```

## Utilizzo

### Esecuzione singola
```bash
python -m scraper.main --once
```

### Con scheduling (ogni 24h)
```bash
python -m scraper.main --schedule
```

### Test
```bash
python -m pytest tests/ -v
```

## Output

I dati vengono salvati in:
- `output/movies.json` — Film e orari aggiornati
- `output/errors.json` — Errori dello scraping
- `output/history/` — Snapshot storici giornalieri

### Struttura `movies.json`
```json
{
  "generated_at": "2026-06-12T10:58:08",
  "city": "Perugia",
  "films": [
    {
      "title": "Film Title",
      "poster": "https://...",
      "description": "Trama del film",
      "rating": 8.5,
      "genres": ["Drama", "Thriller"],
      "present_in": [
        {
          "cinema": "UCI Cinemas Perugia",
          "times": ["18:00", "20:30"],
          "screen": "2D",
          "language": "ITA"
        }
      ],
      "history": [
        {"date": "2026-06-12", "action": "added"}
      ],
      "status": "in_programmazione"
    }
  ]
}
```

## Funzionalità

- **Deduplicazione** film tra i diversi cinema
- **Delta/merge** con history (added/updated/removed)
- **Enrichment** metadata da Wikidata (regista, durata, genere)
- **Circuit breaker** per Wikidata (max 3 fallimenti consecutivi)
- **Rate limiting** per evitare ban su Wikidata

## Architettura

```
scraper/
├── main.py              # Entry point e scheduler
├── config.py            # Costanti e configurazione
├── models.py            # Modelli Film, Showing, CinemaError
├── delta.py             # Merge storico e snapshot
├── errors.py            # Gestione errori
├── metadata.py          # Enrichment Wikidata
├── normalizer.py        # Normalizzazione titoli
├── browser.py           # CloakBrowser (fallback The Space)
└── connectors/
    ├── base.py          # Interfaccia BaseConnector
    ├── postmodernissimo.py
    ├── thespace.py
    └── uci.py
```

## API UCI

Il connettore UCI utilizza l'endpoint pubblico:
```
GET /api/theatres/uci-cinemas-perugia/programming/{date}
```

Questo endpoint restituisce film e orari senza bisogno di autenticazione.

## Note tecniche

- **Wikidata**: le query SPARQL complesse (CONTAINS) causano timeout. Usa la Search API per lookup fuzzy.
- **UCI**: il sito principale blocca il nostro IP. L'endpoint backend funziona direttamente.
- **The Space**: necessita di token OAuth per l'API.
- **PostModernissimo**: nessun anti-bot, richieste dirette.

## Deploy

### Setup automatico
```bash
./deploy/setup.sh
```

### Setup manuale
```bash
# Installa dipendenze
pip install -r requirements.txt

# Installa servizio systemd
sudo cp deploy/cinemascarper.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable cinemascarper
sudo systemctl start cinemascarper

# Configura log rotation
sudo cp deploy/cinemascarper-logrotate /etc/logrotate.d/
```

### Comandi utili
```bash
# Stato servizio
sudo systemctl status cinemascarper

# Visualizza log
sudo journalctl -u cinemascarper -f

# Esecuzione manuale
python3 -m scraper.main --once
```
