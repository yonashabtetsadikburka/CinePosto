# UCI Cinemas Italy - API Research Findings

## Executive Summary

**The Cloudflare protection on ucicinemas.it CAN be completely bypassed.** The UCI website is a Nuxt.js SPA that communicates with multiple backend APIs hosted on Google Cloud Run. These backend APIs are **directly accessible without Cloudflare protection** and return full JSON data with no authentication required.

---

## 1. Cloudflare-Protected Endpoints (ALL return 403)

All direct requests to `ucicinemas.it` are blocked by Cloudflare, regardless of User-Agent:

| URL | Status | Notes |
|-----|--------|-------|
| `https://ucicinemas.it/` | 403 | Cloudflare "Attention Required" |
| `https://ucicinemas.it/robots.txt` | 403 | Blocked |
| `https://ucicinemas.it/sitemap.xml` | 403 | Blocked |
| `https://ucicinemas.it/api/` | 403 | Blocked |
| `https://ucicinemas.it/api/v1/` | 403 | Blocked |
| `https://ucicinemas.it/api/v2/` | 403 | Blocked |
| `https://ucicinemas.it/graphql` | 403 | Blocked |
| `https://ucicinemas.it/_nuxt/*.js` | 403 | JS bundles blocked |
| `https://backend.ucicinemas.it/` | 403 | Cloudflare protected |
| `https://login.ucicinemas.it/` | 403 | Cloudflare protected |
| `https://shop.ucicinemas.it/` | 403 | Cloudflare protected |

**User-Agent tests**: Mobile app UAs (`UCI Cinemas/1.0`, `okhttp/4.9.3`, `Dalvik/2.1.0`, mobile Safari) all return 403.

**DNS**: All subdomains resolve to same Cloudflare IPs (104.18.37.211, 172.64.150.45).

---

## 2. BYPASS: Nuxt Backend API on Google Cloud Run (FULLY WORKING)

### Primary API - No Auth Required, No Cloudflare

**Base URL**: `https://myuci---uci-backend-production-nfluwp7wga-oc.a.run.app`

This is the **main API** used by the Nuxt.js frontend. It is completely open.

| Endpoint | Method | Status | Description |
|----------|--------|--------|-------------|
| `/api/movies` | GET | **200** | All movies with full metadata (39 movies as of Jun 2026) |
| `/api/movies?theatre=16` | GET | **200** | Movies filtered by theatre ID |
| `/api/movies?category=in-uscita` | GET | **200** | Movies by category |
| `/api/theatres` | GET | **200** | All UCI cinemas (locations, screens, coordinates) |
| `/api/theatres/{slug}` | GET | **200** | Single theatre detail (e.g., `uci-cinemas-bicocca-milano`) |
| `/api/variants` | GET | **200** | Movie variants (language/screen combos) - 1.3MB response |
| `/api/config` | GET | **200** | Site config (categories, programs/offers) |
| `/` | GET | **302** | Redirects to ucicinemas.it |
| `/api/eone/*` | GET | **302** | Redirects to ucicinemas.it (EONE auth routes) |

### Movie Data Structure (from `/api/movies`)

```json
{
  "id": 7157,
  "title": "Toy Story 5",
  "slug": "toy-story-5",
  "topMovie": true,
  "is_new_release": false,
  "is_presale": true,
  "rating": {"name": "T", "description": "Film per tutte"},
  "first_performance": "2026-06-18",
  "last_performance": "2026-06-24",
  "poster": "https://storage.googleapis.com/uci-infrastructure-bucket/...",
  "screens": ["IMAX", "ISENSE", "XL", "3D", "2D"],
  "genres": ["Animazione", "Famiglia"],
  "languages": ["ITA", "ENG"],
  "categories": ["film-in-evidenza", "pre-vendite-aperte"],
  "theatres": [{"id": 16, "name": "UCI Cinemas Bicocca | Milano", "slug": "uci-cinemas-bicocca-milano", ...}],
  "variants": [{"id": 3769, "title": "Toy Story 5", "language": "ITA", "screen": "2D", ...}]
}
```

### Movie Categories Found
- `in-uscita` (now showing)
- `film-in-evidenza` (featured)
- `pre-vendite-aperte` (pre-sale open)
- `anime`, `cinefilm`, `film-evento`, `kids-club`, `terrore-e-suspensee`, `ricomincio-da-tre`

### Theatre Data Structure (from `/api/theatres`)

```json
{
  "id": 16,
  "name": "UCI Cinemas Bicocca | Milano",
  "slug": "uci-cinemas-bicocca-milano",
  "is_luxe": false,
  "latitude": "45.5217995",
  "longitude": "9.2161435",
  "address": "Viale Sarca, n. 336...",
  "city": "Milano",
  "region": "Lombardia",
  "screens": ["XL", "3D", "2D"],
  "unlimited_enabled": false
}
```

---

## 3. BYPASS: Webtic Proxy API on Google Cloud Run (Needs Auth)

**Base URL**: `https://uci-website-webtic-proxy-production-1042268733238.europe-west8.run.app/Api2/`

This is the **showtimes/booking API** proxy. It's accessible but requires a Webtic token.

| Endpoint | Status | Response |
|----------|--------|----------|
| `/Api2/` | **200** | `{"Status":{"Success":false,"Message":"invalid api /api2/"}}` |
| `/Api2/GetCinemas` | **200** | `{"Status":{"Success":false,"Message":"Unauthorized ..."}}` |
| `/Api2/GetFilms` | **200** | Same "Unauthorized" |
| `/Api2/GetShowtimes` | **200** | Same "Unauthorized" |
| `/Api2/{any-path}` | **200** | All return "Unauthorized" with GET, "invalid api" with POST |

The proxy adds CORS headers (`access-control-allow-origin: *`), confirming it's designed for cross-origin API calls.

**Token found in Nuxt config** (in `webticToken` field - encrypted/tokenized value). The proxy expects this token to authenticate requests to the underlying Webtic cinema management system.

---

## 4. Direct Webtic API (Needs API Key)

**Base URL**: `https://ucisecure.webtic.it/Api2/`

This is the **raw Webtic cinema management API** (IIS/10.0 server). No Cloudflare.

| Endpoint | Status | Response |
|----------|--------|----------|
| `/Api2/` | **200** | `{"Status":{"Success":false,"Message":"apikey missing"}}` |
| `/Api2/GetCinemas` | **200** | `{"Status":{"Success":false,"Message":"apikey missing"}}` |
| `/Api2/GetFilms` | **200** | Same |
| `/Api2/GetShowtimes` | **200** | Same |

The `apikey` parameter is required. POST with `application/x-www-form-urlencoded` changes error to "Payload Error" (parsing body). The apikey is different from the webticToken - it's likely a per-cinema or per-partner key.

**Webtic** is a major Italian cinema management/ticketing platform. The `LocalGroupId=2378` is UCI's group ID.

---

## 5. `/rest/` Endpoint (Nuxt SSR catch-all)

**URL**: `https://ucicinemas.it/rest/`

This is NOT a real API - it's the Nuxt.js server-side rendering catch-all returning 404 JSON for all paths. However, it **bypasses the Cloudflare JS challenge** because it's served by the App Engine backend directly when the request doesn't trigger the Cloudflare bot check.

Response format:
```json
{"error":true,"url":"https://ucicinemas.it/rest/","statusCode":404,"statusMessage":"Page not found: /rest/","message":"Page not found: /rest/","data":{"path":"/rest/"}}
```

---

## 6. ComingSoon.it API

| URL | Status | Notes |
|-----|--------|-------|
| `https://api.comingsoon.it/` | **200** | Admin login page ("CSCOMMUNITY ADMIN") |
| `https://www.comingsoon.it/` | **403** | Cloudflare protected |

The ComingSoon.it API subdomain has an exposed admin panel but it requires login credentials.

---

## 7. EONE API (Cloudflare Protected)

**URL**: `https://backend.ucicinemas.it/api/eone/v2/`

This is the EONE (film distribution) API, but it's behind Cloudflare (403). The Nuxt backend proxies requests to this via `/api/eone/*` (which returns 302 redirect to main site, likely requiring session cookies).

---

## 8. Infrastructure Summary

| Component | URL | Cloudflare | Auth | Data |
|-----------|-----|------------|------|------|
| **Nuxt Frontend** | `ucicinemas.it` | YES | No | HTML/JS |
| **Nuxt Backend API** | `myuci---uci-backend-production-nfluwp7wga-oc.a.run.app` | NO | No | Movies, Theatres, Variants, Config |
| **Webtic Proxy** | `uci-website-webtic-proxy-production-1042268733238.europe-west8.run.app/Api2/` | NO | Token | Showtimes, Booking |
| **Direct Webtic** | `ucisecure.webtic.it/Api2/` | NO | API Key | Showtimes, Booking |
| **EONE API** | `backend.ucicinemas.it/api/eone/v2/` | YES | Yes | Film distribution |
| **Login/Auth** | `login.ucicinemas.it/` | YES | Yes | User auth |
| **Legacy Site** | `legacy.ucicinemas.it` | YES | No | Old film pages |

### Technology Stack
- **Frontend**: Nuxt.js (Vue.js SSR)
- **Backend**: Node.js on Google Cloud Run (App Engine)
- **Cinema Management**: Webtic (Italian cinema platform, IIS/.NET)
- **Image Storage**: Google Cloud Storage (`storage.googleapis.com/uci-infrastructure-bucket/`)
- **CDN/DDoS**: Cloudflare
- **Analytics**: GTM (GTM-MHC4F8NK), Google Analytics, Facebook Pixel, TikTok, Snapchat
- **Consent**: OneTrust
- **Android App**: `it.creaweb.ucicinemas` (by Creaweb)

---

## 9. Recommended Scraping Strategy

### For Movies + Theatres + Metadata (No auth needed)
```
GET https://myuci---uci-backend-production-nfluwp7wga-oc.a.run.app/api/movies
GET https://myuci---uci-backend-production-nfluwp7wga-oc.a.run.app/api/theatres
GET https://myuci---uci-backend-production-nfluwp7wga-oc.a.run.app/api/theatres/{slug}
GET https://myuci---uci-backend-production-nfluwp7wga-oc.a.run.app/api/variants
GET https://myuci---uci-backend-production-nfluwp7wga-oc.a.run.app/api/config
```

### For Showtimes (requires solving Webtic auth)
The Webtic proxy on Cloud Run needs the `webticToken` from the Nuxt config. The token in the config is encrypted - the Nuxt frontend decrypts it before sending. You'd need to:
1. Analyze the Nuxt JS bundle to find the token decryption logic, OR
2. Intercept the actual requests via a headless browser that solves the Cloudflare challenge

### For Images (directly accessible)
```
https://storage.googleapis.com/uci-infrastructure-bucket/Common/Movies/Posters/{id}.jpg
https://storage.googleapis.com/uci-infrastructure-bucket/Common/Movies/Ratings/{id}.png
https://storage.googleapis.com/uci-infrastructure-bucket/Common/Theatres/HeroImages/{id}.png
```
