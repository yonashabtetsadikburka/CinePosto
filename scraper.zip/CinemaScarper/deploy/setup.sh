#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
SERVICE_NAME="cinemascarper"

echo "=== CinemaScarper Setup ==="

# Install dependencies
echo "Installing dependencies..."
pip install -r "$PROJECT_DIR/requirements.txt" --quiet

# Create output directories
mkdir -p "$PROJECT_DIR/output/history"

# Copy systemd service
echo "Installing systemd service..."
sudo cp "$SCRIPT_DIR/$SERVICE_NAME.service" /etc/systemd/system/
sudo systemctl daemon-reload

# Enable and start
echo "Enabling service..."
sudo systemctl enable "$SERVICE_NAME"
sudo systemctl start "$SERVICE_NAME"

echo ""
echo "Service installed and started!"
echo ""
echo "Commands:"
echo "  sudo systemctl status $SERVICE_NAME   # Check status"
echo "  sudo systemctl restart $SERVICE_NAME  # Restart"
echo "  sudo journalctl -u $SERVICE_NAME -f   # View logs"
echo ""
echo "Manual run:"
echo "  cd $PROJECT_DIR && python3 -m scraper.main --once"
