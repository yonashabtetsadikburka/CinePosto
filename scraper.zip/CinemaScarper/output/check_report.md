# CinemaScarper — Visual / Data Quality Check

**Run date:** 2026-06-16
**Window:** oggi + prossimi 7 giorni (8 giorni totali)
**Metodo:**
- Fresh run `python3 -m scraper.main --once`
- Navigazione live dei 3 siti via Playwright (Chromium headless bundled, stealth headers) per replicare il payload Next.js RSC di PostModernissimo e le stesse API micro‑service che UCI/TheSpace usano dietro la SPA.
- Vision degli 8 screenshot utente (`/home/ubuntu/screenshotss/screen/*.png`) con `minimax-vision` per conferma visiva.
- Confronto finale vs `output/cache/{slug}.json` (cache per‑cinema ottenuta dal run fresco, **prima** della dedup).

## Sintesi incongruenze

| Cinema | # diff | Gravità | Sintomo |
|-------|--------|---------|---------|
| PostModernissimo | 1 schema-wide | 🟠 medio | Lo scraper include slot `opzioni="noprog"` come se fossero programmazione reale (es. Amarga Navidad mostra 3 orari su 16/06 ma solo 1 è realmente attivo). |
| The Space Corciano | 4 | 🟠 medio | Slot 16:10 e 16:15 su 16/06 inesistenti sul sito (probabile cross‑data o replica da data diversa). |
| UCI Perugia | ≥ 6 | 🔴 alto | Cache Scrapata per film non in programmazione quel giorno (4 film su 16/06 e Scary Movie con orario fantasma 16:45). |

Inoltre: HTML entities `&#8211;` / `&#8230;` / `&#8217;` rimaste raw nei titoli finali post‑dedup di PostModernissimo (es. `"Still Walking &#8211; Camminando"`, `"Ricchi&#8230;da morire"`).

## 1. PostModernissimo

### Bug: slot fantasma `opzioni="noprog"`

Il payload RSC embedded contiene tutti gli slot storici + futuri, e ogni slot ha `opzioni ∈ {off, vost, dub, noprog}`. `noprog = "non in programmazione"` ma il connettore (`scraper/connectors/postmodernissimo.py:111‑118`) accetta *qualsiasi orario non vuoto*, senza controllare `opzioni`.

| Film | Data | Cache JSON | Sito reale (programmati) | Sito totale (incl. noprog) |
|------|------|------------|--------------------------|----------------------------|
| Amarga Navidad | 2026-06-16 | 16:45, 19:00, 21:15 | solo **19:00** (vost) | 16:45 (noprog), 19:00 (vost), 21:15 (noprog) |
| Amarga Navidad | 2026-06-17 | 16:45, 19:00, 21:15 | solo **19:00** (vost) | 16:45 (noprog), 19:00 (vost), 21:15 (noprog) |
| Diaz – Non pulire questo sangue | 16‑23/06 | 18:45, 21:30 (tutte le 8 date) | alcuni giorni hanno solo 18:45 o 21:30, non entrambi | sovrabbondante |
| Disclosure Day | 16‑23/06 | 18:45, 21:30 su tutte le 8 date | specchiare PostMod vs UCI/Thespace non combacia | sovrabbondante |

**Fix consigliato**: filtrare `if s.get("opzioni") != "noprog"` in `_extract_shows`/match‑target di `postmodernissimo.py`.

### Bug: HTML entities grezze nei titoli PostMod post‑dedup

| Film veduto in finale JSON | Versione pulita attesa |
|----|----|
| `Still Walking &#8211; Camminando in un giorno d&#8217;estate` | `Still Walking – Camminando in un giorno d'estate` |
| `Ricchi&#8230;da morire &#8211; Delitti in famiglia` (PostMod) | `Ricchi…da morire – Delitti in famiglia` |
| `Ricchi... DA MORIRE - DELITTI IN FAMIGLIA` (TheSpace) | (già pulito) |

Il `_decode_html_entities` in `postmodernissimo.py:158` viene applicato al `title` del Film *PostMod*, ma in dedup con TheSpace il `fuzzy_match` vede titoli *puliti* da Thespace vs *encoded* da PostMod → chiavi diverse → il Film PostMod sopravvive con HTML entities raw nel JSON finale.

**Fix**: in `main.py:_deduplicate_films` normalizzare / `html.unescape` su entrambi i lati prima del match, oppure decodificare su `film_to_dict`.

## 2. The Space Corciano

| Data | Film | Cache scraper | Live API (TheSpace) |
|------|------|---------------|---------------------|
| 2026‑06‑16 | BACKROOMS | 16:15, 19:50, 22:10 | 19:50, 22:10 ⚠️ 16:15 spurio |
| 2026‑06‑16 | SCARY MOVIE | 16:10, 18:35, 20:45, 21:50, 22:30 | 18:35, 20:45, 21:50, 22:30 ⚠️ 16:10 spurio |
| 2026‑06‑16 | RUFUS IL DRAGHETTO… | 16:10 | (non in programmazione 16/06) ❌ |
| 2026‑06‑16 | SAVAGE HOUSE | 16:10 | (non in programmazione 16/06) ❌ |

Vision screenshot 16/06 conferma assenza di quei film sull'header Thespace per quel giorno.

**Causa probabile**: il connettore Thespace (`connectors/thespace.py:120‑141`) chiama la API per ogni data del loop e usa `seen_titles` per evitare duplicati. Problema: lo stesso film visto per la data 17/06 viene *anche* parsato per la data 16/06 prendendo slot dalle session `showingGroups` di **altre** date se la response non filtra per date a livello server.

## 3. UCI Perugia

### 3a. Film che il 16/06 non sono in programmazione ma compaiono in cache

| Data | Film | Cache scraper | Live API | Note |
|------|------|----------------|----------|------|
| 2026-06-16 | Pecore sotto copertura | 16:00 | (no screens) | ❌ |
| 2026-06-16 | Principessa Mononoke C.A. | 16:30 | (no screens) | ❌ |
| 2026-06-16 | Rufus - Il draghetto marino che non sapeva nuotare | 16:10, 16:50 | (no screens) | ❌ |
| 2026-06-16 | Savage House | 16:20 | (no screens) | ❌ |
| 2026-06-17 | Disclosure Day | +19:30 VOSE + orari ITA 16:00/17:00/18:10/18:45/19:10/19:30/20:20/21:30/22:00/22:20 | OK ✓ | bug su 16/06 |
| 2026-06-16 | Scary Movie | 16:45, 19:20, 20:40, 21:45, 23:00 | 19:20, 20:40, 21:45, 23:00 ⚠️ **16:45 spurio** | — |
| 2026-06-16 | Disclosure Day | +16:00 (ITA) | (ITA live = 17:00–22:20, no 16:00) ⚠️ **16:00 spurio** | — |

Vision screenshot `Screenshot 2026-06-16 alle 15.07.02.png` conferma Scary Movie UCI 16/06 = 16:45/19:20/20:40/21:45/23:00 quindi l'utente vede 5 orari; UCI live API dice 4. La pagina UCI mostrata agli utenti **non** corrisponde alla API che lo scraper chiama (probabile: l'app UCI legge da un endpoint cache differente, mentre l'API per il backend Cloud Run mostra una schedule diversa).

### 3b. Film "da uscire" non ancora in programmazione

L'API UCI `/programming/{date}` restituisce l'intero catalogo di film (~24) per ogni data, popolando `performances` **solo per la data richiesta**. Il connettore UCI pare accettare `performances` vuote per tutti gli altri film e produrre film con array orari vuoto. Comunque tutti i film nel JSON finale hanno almeno 1 showing reale nel range di date, quindi il warning dell'utente sull'Odissea (esce 16/07/2026 ma segnato oggi) non è **direttamente** verificabile dal JSON odierno, ma la UI / cache UCI potrebbe esporlo ugualmente. Indagare su quale endpoint live usa l'app UCI Perugia.

## 4. Vision degli screenshot

| File | Cinema | Film confermati vs cache | Match |
|------|--------|--------------------------|-------|
| 15.07.02.png | UCI Perugia | Scary Movie 16:45,19:20,20:40,21:45,23:00 | ✅ identico |
| 15.07.11.png | UCI Perugia | Masters of the Universe 19:00 | ✅ identico |
| 15.07.21.png | UCI Perugia | Il bacio della donna ragno 16:20,19:40 (18/06) | ✅ identico |
| 15.07.27.png | PostModernissimo | Le bambine 18:30, Disclosure Day 18:45+21:30, Amarga Navidad 19:00 (solo 1!), Don Chisciotte 21:00, Still Walking 21:15 | ⚠️ **Amarga Navidad cache=3 orari ma sito mostra 1** |
| 15.07.32 | PostModernissimo | 17/06: Don Chisciotte **18:30**, Disclosure Day 18:45+21:30, Amarga Navidad **19:00 (solo 1)**, Le bambine **21:00**, Still Walking 21:15 / 18/06: Diaz **18:30** | 🔴 **cache 17/06 ha Don Chisciotte 21:00 invece di 18:30, Le bambine 18:30 invece di 21:00, Amarga Navidad 3 orari invece di 1, Diaz 18:45 invece di 18:30** |
| 15.07.42 | PostModernissimo | Still Walking 21:15 su 16/06 e 17/06 | ✅ identico |
| 15.07.58 | UCI Perugia (Backrooms) | (vision confabulated; backend API vero 16/06 = solo 22:45) | ✅ un solo orario 22:45 conferma |
| 15.08.05 | The Space Corciano (Disclosure Day 16/06) | 16:30, 17:50, 18:30, 20:00, 21:00, 22:00 | ✅ identico |

## Priorità fix

1. 🔴 **UCI scraper** – investigare perché per data 16/06 ha orari che l'end point backend non restituisce. Possibile: cache request stale, oppure `_build_showings_from_screens` non filtra per `current_day` quando l'array `performances` ha più performance con `day` field eterogenei.
2. 🔴 **UCI scraper** – escludere film con `performances` vuoti o non appartenenti al `current_day`.
3. 🟠 **Thespace scraper** – stessa verifica(_session.date_ vs group.date_), escludere showingGroups con `date` diversa da quella richiesta.
4. 🟠 **PostMod scraper** – filtrare `opzioni != "noprog"`.
5. 🟡 **PostMod** – unescape HTML nel titolo *dopo* dedup (`film_to_dict` o normalizzare in `main.py:_deduplicate_films`).

## File di prova
- `/tmp/opencode/visual_check/live_playwright_postmod.json` (dati PostMod estratti dal payload RSC reale)
- `/tmp/opencode/visual_check/live_playwright_thespace.json`
- `/tmp/opencode/visual_check/live_playwright_uci.json`
