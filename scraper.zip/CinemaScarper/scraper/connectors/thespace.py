from __future__ import annotations

import logging
import re
import time
from datetime import date, datetime
from typing import Optional
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

from scraper.config import (
    REQUEST_RETRY,
    REQUEST_TIMEOUT,
    RETRY_BACKOFF,
    THE_SPACE_API_BASE,
    THE_SPACE_AUTH_URL,
    THE_SPACE_CINEMA_ID,
    THE_SPACE_CINEMA_NAME,
    THE_SPACE_CINEMA_SLUG,
    THE_SPACE_CINEMA_URL,
    THE_SPACE_FILMS_URL,
    THE_SPACE_BASE_URL,
)
from scraper.models import CinemaError, Film, ScrapeResult, Showing
from scraper.connectors.base import BaseConnector

logger = logging.getLogger(__name__)


def _retry_request(method: str, url: str, session: requests.Session, **kwargs) -> requests.Response:
    last_exc = None
    for attempt in range(1, REQUEST_RETRY + 1):
        try:
            resp = getattr(session, method)(url, timeout=REQUEST_TIMEOUT, **kwargs)
            if resp.status_code == 403:
                logger.error("THESPACE 403 Forbidden for %s — not retrying (permanent block)", url)
                resp.raise_for_status()
            resp.raise_for_status()
            return resp
        except requests.HTTPError as exc:
            last_exc = exc
            if exc.response is not None and exc.response.status_code == 403:
                raise
            logger.warning(
                "THESPACE retry %d/%d for %s: %s", attempt, REQUEST_RETRY, url, exc
            )
            if attempt < REQUEST_RETRY:
                time.sleep(RETRY_BACKOFF**attempt)
        except requests.RequestException as exc:
            last_exc = exc
            logger.warning(
                "THESPACE retry %d/%d for %s: %s", attempt, REQUEST_RETRY, url, exc
            )
            if attempt < REQUEST_RETRY:
                time.sleep(RETRY_BACKOFF**attempt)
    raise last_exc


class TheSpaceConnector(BaseConnector):
    @property
    def cinema_name(self) -> str:
        return THE_SPACE_CINEMA_NAME

    @property
    def cinema_slug(self) -> str:
        return THE_SPACE_CINEMA_SLUG

    def scrape(self, today: str, dates: list[str] | None = None) -> ScrapeResult:
        target_dates = dates or [today]
        try:
            return self._scrape_via_api(today, target_dates)
        except Exception as exc:
            logger.warning("The Space API failed, falling back to CloakBrowser: %s", exc)
            try:
                return self._scrape_via_browser(today)
            except Exception as browser_exc:
                logger.error("The Space CloakBrowser fallback also failed: %s", browser_exc, exc_info=True)
                return ScrapeResult(
                    errors=[
                        CinemaError(
                            cinema=self.cinema_name,
                            timestamp=datetime.now().isoformat(),
                            exception=type(browser_exc).__name__,
                            phase="scrape_fallback",
                            url=THE_SPACE_CINEMA_URL,
                            detail=f"API failed: {exc}; Browser failed: {browser_exc}",
                        )
                    ]
                )

    def _scrape_via_api(self, today: str, dates: list[str]) -> ScrapeResult:
        films: list[Film] = []
        errors: list[CinemaError] = []
        session = requests.Session()
        session.headers.update(
            {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
                "Accept": "application/json",
                "Referer": THE_SPACE_CINEMA_URL,
            }
        )

        try:
            auth_resp = _retry_request("post", THE_SPACE_AUTH_URL, session, json={})
            logger.info("The Space auth status: %s", auth_resp.status_code)

            seen_titles: dict[str, Film] = {}

            for target_date in dates:
                films_url = f"{THE_SPACE_FILMS_URL}?showingDate={target_date}&includesSession=true&includeSessionAttributes=true"
                resp = _retry_request("get", films_url, session)
                data = resp.json()

                api_films = data.get("result") or data.get("films") or []
                if isinstance(api_films, dict):
                    api_films = api_films.get("films") or api_films.get("items") or []

                for film_data in api_films:
                    try:
                        film = self._parse_api_film(film_data, target_date)
                        if not film:
                            continue
                        key = film.title_normalized
                        if key in seen_titles:
                            seen_titles[key].present_in.extend(film.present_in)
                        else:
                            seen_titles[key] = film
                            films.append(film)
                    except Exception as exc:
                        logger.warning("The Space parse film error: %s", exc)
                        errors.append(
                            CinemaError(
                                cinema=self.cinema_name,
                                timestamp=datetime.now().isoformat(),
                                exception=type(exc).__name__,
                                phase="parse_api_film",
                                detail=str(exc),
                            )
                        )

        except Exception as exc:
            logger.error("The Space API scrape failed: %s", exc, exc_info=True)
            raise

        return ScrapeResult(films=films, errors=errors)

    def _parse_api_film(self, data: dict, today: str) -> Optional[Film]:
        title = data.get("filmTitle") or data.get("title") or ""
        if not title:
            return None

        detail_url = data.get("filmUrl") or ""
        if detail_url and not detail_url.startswith("http"):
            detail_url = urljoin(THE_SPACE_BASE_URL, detail_url)
        if not detail_url:
            film_id = data.get("filmId") or ""
            slug = data.get("filmUrl", "").rstrip("/").split("/")[-1] if data.get("filmUrl") else film_id
            detail_url = f"{THE_SPACE_BASE_URL}/film/{slug}" if slug else THE_SPACE_CINEMA_URL

        poster = data.get("posterImageSrc") or data.get("panelImageUrl") or ""
        if poster and not poster.startswith("http"):
            poster = urljoin(THE_SPACE_BASE_URL, poster)

        description = data.get("synopsisShort") or data.get("synopsis") or ""
        running_time = data.get("runningTime")
        duration = f"{running_time} min" if running_time and not data.get("isDurationUnknown") else None

        genres = data.get("genres") or []
        if isinstance(genres, str):
            genres = [g.strip() for g in genres.split(",") if g.strip()]
        elif isinstance(genres, list):
            genres = [g if isinstance(g, str) else g.get("name", "") for g in genres if g]

        director = (data.get("director") or "").strip() or None
        cast = data.get("cast") or None

        showings = self._parse_api_showing_groups(data, today, detail_url)

        return Film(
            title=title,
            title_normalized=title.lower().strip(),
            present_in=showings,
            poster=poster if poster else None,
            description=description or None,
            genres=genres,
            duration=duration,
            director=director,
            source_poster=poster if poster else None,
        )

    def _parse_api_showing_groups(self, film_data: dict, today: str, detail_url: str) -> list[Showing]:
        showings: list[Showing] = []
        showing_groups = film_data.get("showingGroups") or []

        for group in showing_groups:
            if not isinstance(group, dict):
                continue

            group_date = group.get("date", "")
            try:
                from datetime import datetime as dt
                parsed_date = dt.fromisoformat(str(group_date).replace("Z", "+00:00"))
                date_str = parsed_date.strftime("%Y-%m-%d")
            except Exception:
                logger.warning("TheSpace failed to parse date %s, skipping group", group_date)
                continue

            sessions = group.get("sessions") or []

            for session in sessions:
                if not isinstance(session, dict):
                    continue

                show_time = session.get("startTime") or session.get("showTime") or ""
                time_str = ""
                if show_time:
                    try:
                        from datetime import datetime as dt
                        parsed = dt.fromisoformat(str(show_time).replace("Z", "+00:00"))
                        time_str = parsed.strftime("%H:%M")
                    except Exception:
                        if isinstance(show_time, str) and re.match(r"\d{1,2}:\d{2}", show_time[:5]):
                            time_str = show_time[:5]

                if not time_str:
                    continue

                screen = session.get("screenName") or None

                language = None
                attrs: list[str] = []
                for attr in session.get("attributes") or []:
                    if isinstance(attr, dict):
                        name = attr.get("name") or attr.get("value") or ""
                        attr_type = attr.get("attributeType", "")
                        if name:
                            attrs.append(name)
                        if attr_type == "Language" and name and not language:
                            language = name

                showing = Showing(
                    cinema=self.cinema_name,
                    cinema_slug=self.cinema_slug,
                    date=date_str,
                    times=[time_str],
                    screen=screen,
                    source_url=detail_url,
                    language=language,
                    session_attributes=attrs,
                )
                showings.append(showing)

        if not showings and film_data.get("hasSessions"):
            showings.append(
                Showing(
                    cinema=self.cinema_name,
                    cinema_slug=self.cinema_slug,
                    date=today,
                    times=[],
                    source_url=detail_url,
                )
            )

        return showings

    def _scrape_via_browser(self, today: str) -> ScrapeResult:
        from scraper.browser import fetch_page_html

        html = fetch_page_html(THE_SPACE_CINEMA_URL, wait_for=".showing-listing")
        soup = BeautifulSoup(html, "lxml")
        films: list[Film] = []
        errors: list[CinemaError] = []

        for card in soup.select(".showing-listing__list > li, .film-card, [data-test*='film']"):
            try:
                title_el = card.select_one("h2, h3, .film-title, [data-test*='title']")
                title = title_el.get_text(strip=True) if title_el else ""
                if not title:
                    continue

                link_el = card.select_one("a[href*='/film/']")
                detail_url = link_el["href"] if link_el and link_el.get("href") else ""
                if detail_url and not detail_url.startswith("http"):
                    detail_url = urljoin(THE_SPACE_BASE_URL, detail_url)

                poster = None
                img = card.select_one("img")
                if img and img.get("src"):
                    poster = img["src"]
                    if not poster.startswith("http"):
                        poster = urljoin(THE_SPACE_BASE_URL, poster)

                times: list[str] = []
                for time_el in card.select("[data-test*='time'], .session-time, .showtime"):
                    t = time_el.get_text(strip=True)
                    if re.match(r"\d{1,2}:\d{2}", t):
                        times.append(t)

                showing = Showing(
                    cinema=self.cinema_name,
                    cinema_slug=self.cinema_slug,
                    date=today,
                    times=times,
                    source_url=detail_url or THE_SPACE_CINEMA_URL,
                )

                film = Film(
                    title=title,
                    title_normalized=title.lower().strip(),
                    present_in=[showing],
                    source_poster=poster,
                )
                films.append(film)

            except Exception as exc:
                logger.warning("The Space browser parse error: %s", exc)

        return ScrapeResult(films=films, errors=errors)

    def fetch_film_detail(self, film_url: str) -> Optional[dict]:
        session = requests.Session()
        session.headers.update(
            {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Accept": "text/html",
            }
        )
        try:
            resp = _retry_request("get", film_url, session)
            soup = BeautifulSoup(resp.text, "lxml")
            result: dict = {}

            desc = soup.select_one("[data-test*='synopsis'], .synopsis, .film-description")
            if desc:
                result["description"] = desc.get_text(strip=True)

            return result
        except Exception:
            try:
                from scraper.browser import fetch_page_html

                html = fetch_page_html(film_url)
                soup = BeautifulSoup(html, "lxml")
                result: dict = {}
                desc = soup.select_one("[data-test*='synopsis'], .synopsis, .film-description")
                if desc:
                    result["description"] = desc.get_text(strip=True)
                return result
            except Exception as exc:
                logger.warning("The Space detail fetch failed for %s: %s", film_url, exc)
                return None
