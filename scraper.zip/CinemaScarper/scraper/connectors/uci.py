from __future__ import annotations

import html
import logging
import re
import time
from datetime import date, datetime
from typing import Optional

import requests

from scraper.config import (
    REQUEST_RETRY,
    REQUEST_TIMEOUT,
    RETRY_BACKOFF,
    UCI_BASE_URL,
    UCI_CINEMA_NAME,
    UCI_CINEMA_SLUG,
    UCI_PROGRAMMING_URL,
)
from scraper.models import CinemaError, Film, ScrapeResult, Showing
from scraper.connectors.base import BaseConnector

logger = logging.getLogger(__name__)


def _retry_request(method: str, url: str, session: requests.Session, **kwargs) -> requests.Response:
    last_exc = None
    for attempt in range(1, REQUEST_RETRY + 1):
        try:
            resp = getattr(session, method)(url, timeout=REQUEST_TIMEOUT, **kwargs)
            if resp.status_code == 403:
                logger.error("UCI 403 Forbidden for %s — not retrying (permanent block)", url)
                resp.raise_for_status()
            resp.raise_for_status()
            return resp
        except requests.HTTPError as exc:
            last_exc = exc
            if exc.response is not None and exc.response.status_code == 403:
                raise
            logger.warning(
                "UCI retry %d/%d for %s: %s", attempt, REQUEST_RETRY, url, exc
            )
            if attempt < REQUEST_RETRY:
                time.sleep(RETRY_BACKOFF**attempt)
        except requests.RequestException as exc:
            last_exc = exc
            logger.warning(
                "UCI retry %d/%d for %s: %s", attempt, REQUEST_RETRY, url, exc
            )
            if attempt < REQUEST_RETRY:
                time.sleep(RETRY_BACKOFF**attempt)
    raise last_exc


def _strip_html(text: str) -> str:
    return re.sub(r"<[^>]+>", "", html.unescape(text)).strip()


class UCIConnector(BaseConnector):
    @property
    def cinema_name(self) -> str:
        return UCI_CINEMA_NAME

    @property
    def cinema_slug(self) -> str:
        return UCI_CINEMA_SLUG

    def scrape(self, today: str, dates: list[str] | None = None) -> ScrapeResult:
        target_dates = dates or [today]
        return self._scrape_via_programming(today, target_dates)

    def _scrape_via_programming(self, today: str, dates: list[str]) -> ScrapeResult:
        films: list[Film] = []
        seen_titles: dict[str, Film] = {}
        errors: list[CinemaError] = []
        session = requests.Session()
        session.headers.update(
            {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
                "Accept": "application/json",
            }
        )

        for target_date in dates:
            url = UCI_PROGRAMMING_URL.format(date=target_date)
            try:
                resp = _retry_request("get", url, session)
                data = resp.json()
                api_movies = data.get("data", [])
                logger.info("UCI programming API returned %d movies for %s", len(api_movies), target_date)

                for movie_data in api_movies:
                    try:
                        if movie_data.get("not_today") is True:
                            continue
                        film = self._parse_programming_movie(movie_data, target_date)
                        if film:
                            key = film.title_normalized
                            if key in seen_titles:
                                seen_titles[key].present_in.extend(film.present_in)
                            else:
                                seen_titles[key] = film
                                films.append(film)
                    except Exception as exc:
                        logger.warning("UCI parse programming movie error: %s", exc)
                        errors.append(
                            CinemaError(
                                cinema=self.cinema_name,
                                timestamp=datetime.now().isoformat(),
                                exception=type(exc).__name__,
                                phase="parse_programming_movie",
                                detail=str(exc),
                            )
                        )

            except Exception as exc:
                logger.error("UCI programming API scrape failed for %s: %s", target_date, exc, exc_info=True)
                errors.append(
                    CinemaError(
                        cinema=self.cinema_name,
                        timestamp=datetime.now().isoformat(),
                        exception=type(exc).__name__,
                        phase="scrape",
                        url=url,
                        detail=str(exc),
                    )
                )

        return ScrapeResult(films=films, errors=errors)

    def _parse_programming_movie(self, data: dict, today: str) -> Optional[Film]:
        title = data.get("title") or ""
        if not title:
            return None

        slug = data.get("slug") or ""
        detail_url = f"{UCI_BASE_URL}/film/{slug}/" if slug else UCI_BASE_URL

        poster = data.get("poster") or data.get("top_image") or ""
        if poster and not poster.startswith("http"):
            poster = ""

        genres = []
        for g in data.get("genres") or []:
            if isinstance(g, dict):
                name = g.get("name")
                if name:
                    genres.append(name)
            elif isinstance(g, str):
                genres.append(g)

        description = data.get("description") or ""
        if description:
            description = _strip_html(description)

        showings = self._build_showings_from_screens(data.get("screens", []), today, detail_url)

        if not showings:
            return None

        return Film(
            title=title,
            title_normalized=title.lower().strip(),
            present_in=showings,
            poster=poster or None,
            description=description or None,
            genres=genres,
            duration=None,
            director=None,
            source_poster=poster or None,
        )

    def _build_showings_from_screens(
        self, screens: list, today: str, detail_url: str
    ) -> list[Showing]:
        showings: list[Showing] = []

        for screen_group in screens:
            if not isinstance(screen_group, dict):
                continue

            for fmt, variants in screen_group.items():
                if not isinstance(variants, list):
                    continue

                for variant in variants:
                    if not isinstance(variant, dict):
                        continue

                    lang_obj = variant.get("language") or {}
                    language = lang_obj.get("name") if isinstance(lang_obj, dict) else None

                    screen_obj = variant.get("screen") or {}
                    screen_name = screen_obj.get("name") if isinstance(screen_obj, dict) else fmt

                    performances = variant.get("performances") or []
                    times = []
                    for perf in performances:
                        if not isinstance(perf, dict):
                            continue
                        perf_day = perf.get("day", "")
                        if perf_day and perf_day != today:
                            continue
                        start = perf.get("actual_start_at") or ""
                        if start:
                            times.append(start)

                    times.sort()

                    showings.append(
                        Showing(
                            cinema=self.cinema_name,
                            cinema_slug=self.cinema_slug,
                            date=today,
                            times=times,
                            screen=screen_name,
                            source_url=detail_url,
                            language=language,
                            session_attributes=[fmt] if fmt and fmt != screen_name else [],
                        )
                    )

        return showings

    def fetch_film_detail(self, film_url: str) -> Optional[dict]:
        return {}
