from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path

from scraper.config import ERRORS_JSON
from scraper.models import CinemaError

logger = logging.getLogger(__name__)


def write_errors(errors: list[CinemaError], today: str) -> None:
    if not errors:
        if ERRORS_JSON.exists():
            try:
                with open(ERRORS_JSON, "r", encoding="utf-8") as f:
                    existing = json.load(f)
            except Exception:
                existing = {"errors": []}

            existing["errors"] = [
                e for e in existing.get("errors", [])
                if not (e.get("date") == today or e.get("timestamp", "").startswith(today))
            ]
            existing["last_clean_date"] = today

            with open(ERRORS_JSON, "w", encoding="utf-8") as f:
                json.dump(existing, f, ensure_ascii=False, indent=2)
        return

    try:
        if ERRORS_JSON.exists():
            with open(ERRORS_JSON, "r", encoding="utf-8") as f:
                existing = json.load(f)
        else:
            existing = {"errors": []}

        new_errors = [e.to_dict() for e in errors]
        existing["errors"] = [
            e
            for e in existing.get("errors", [])
            if not (e.get("date") == today or e.get("timestamp", "").startswith(today))
        ] + new_errors
        existing["last_error_date"] = today
        existing["last_error_timestamp"] = datetime.now().isoformat()

        with open(ERRORS_JSON, "w", encoding="utf-8") as f:
            json.dump(existing, f, ensure_ascii=False, indent=2)

        logger.info("Wrote %d errors to %s", len(new_errors), ERRORS_JSON)
    except Exception as exc:
        logger.error("Failed to write errors.json: %s", exc, exc_info=True)
