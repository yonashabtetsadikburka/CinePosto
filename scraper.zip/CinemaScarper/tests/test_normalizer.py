from __future__ import annotations

from scraper.normalizer import normalize_duration, normalize_title, title_key


def test_normalize_title():
    assert normalize_title("  Hello   World  ") == "Hello World"
    assert normalize_title("FILM: The Beginning") == "FILM: The Beginning"
    assert normalize_title("Film (2024)") == "Film"
    assert normalize_title("") == ""


def test_title_key():
    assert title_key("hello world") == "helloworld"
    assert title_key("Hello World") == "helloworld"
    assert title_key("  Hello   World  ") == "helloworld"
    assert title_key("") == ""


def test_normalize_duration():
    assert normalize_duration(None) is None
    assert normalize_duration("") is None
    assert normalize_duration("120") == "120 min"
    assert normalize_duration("96 min") == "96 min"
    assert normalize_duration(" 134 min  ") == "134 min"
    assert normalize_duration("100 minuti") == "100 min"
    assert normalize_duration("01:45") == "105 min"
    assert normalize_duration("1:45:30") == "106 min"
    assert normalize_duration("1h 30m") == "90 min"
    assert normalize_duration("2h") == "120 min"
